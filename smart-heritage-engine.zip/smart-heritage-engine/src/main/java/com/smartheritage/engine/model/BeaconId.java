package com.smartheritage.engine.model;

import java.util.Locale;

/**
 * Định danh duy nhất của một iBeacon = UUID + Major + Minor.
 * Dùng làm key trong Map (record tự có equals/hashCode).
 */
public record BeaconId(String uuid, int major, int minor) {

    public BeaconId {
        if (uuid == null || uuid.isBlank()) {
            throw new IllegalArgumentException("uuid must not be blank");
        }
        if (major < 0 || major > 65535 || minor < 0 || minor > 65535) {
            throw new IllegalArgumentException("major/minor must be in range 0..65535");
        }
        uuid = uuid.toUpperCase(Locale.ROOT);   // chuẩn hoá để so sánh
    }

    @Override
    public String toString() {
        return uuid + "/" + major + "/" + minor;
    }
}
