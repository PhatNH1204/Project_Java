package com.smartheritage.engine.model;

/**
 * Thiết bị beacon đã đăng ký trong hệ thống (sau này map sang bảng Beacon / JPA Entity).
 * Tuần 1: POJO thuần, tuần 2-3 sẽ thêm annotation @Entity.
 */
public class Beacon {
    private Long id;
    private String name;
    private BeaconId beaconId;
    private int txPower;        // RSSI chuẩn tại 1m
    private boolean active;

    public Beacon(Long id, String name, BeaconId beaconId, int txPower, boolean active) {
        this.id = id;
        this.name = name;
        this.beaconId = beaconId;
        this.txPower = txPower;
        this.active = active;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public BeaconId getBeaconId() { return beaconId; }
    public int getTxPower() { return txPower; }
    public boolean isActive() { return active; }

    public void setName(String name) { this.name = name; }
    public void setTxPower(int txPower) { this.txPower = txPower; }
    public void setActive(boolean active) { this.active = active; }

    @Override
    public String toString() {
        return "Beacon{" + name + ", " + beaconId + ", active=" + active + "}";
    }
}
