package com.smartheritage.engine.proximity;

import com.smartheritage.engine.model.BeaconId;
import com.smartheritage.engine.model.BeaconSignal;
import com.smartheritage.engine.model.ProximityZone;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Chuyển RSSI thô -> khoảng cách ước lượng -> ProximityZone.
 *
 * 1. Làm mượt RSSI bằng trung bình trượt (moving average) vì RSSI rất nhiễu.
 * 2. Ước lượng khoảng cách theo mô hình log-distance path loss:
 *        d = 10 ^ ((txPower - rssi) / (10 * n))     (n = 2.0 ngoài trời/không gian mở)
 * 3. Phân vùng: IMMEDIATE < 0.5m <= NEAR < 3m <= FAR.
 * 4. Hysteresis: chỉ đổi vùng khi vượt ngưỡng thêm một biên nhỏ, tránh nhấp nháy
 *    NEAR <-> IMMEDIATE khi đứng sát ranh giới.
 *
 * Chỉ trả về ProximityUpdate khi vùng THAY ĐỔI.
 */
public class ProximityManager {

    private static final double PATH_LOSS_EXPONENT = 2.0;

    private final double immediateMax;   // m
    private final double nearMax;        // m
    private final double hysteresis;     // m
    private final int windowSize;

    private final Map<BeaconId, Deque<Integer>> rssiWindows = new HashMap<>();
    private final Map<BeaconId, ProximityZone> currentZones = new HashMap<>();

    public ProximityManager() {
        this(0.5, 3.0, 0.1, 5);
    }

    public ProximityManager(double immediateMax, double nearMax, double hysteresis, int windowSize) {
        if (immediateMax <= 0 || nearMax <= immediateMax || windowSize < 1) {
            throw new IllegalArgumentException("invalid proximity configuration");
        }
        this.immediateMax = immediateMax;
        this.nearMax = nearMax;
        this.hysteresis = hysteresis;
        this.windowSize = windowSize;
    }

    /** Xử lý 1 tín hiệu; trả về update nếu vùng của beacon đó đổi. */
    public Optional<ProximityUpdate> process(BeaconSignal signal) {
        BeaconId id = signal.id();

        Deque<Integer> window = rssiWindows.computeIfAbsent(id, k -> new ArrayDeque<>());
        window.addLast(signal.rssi());
        if (window.size() > windowSize) {
            window.removeFirst();
        }

        double smoothedRssi = window.stream().mapToInt(Integer::intValue).average().orElse(signal.rssi());
        double distance = estimateDistance(smoothedRssi, signal.txPower());

        ProximityZone previous = currentZones.getOrDefault(id, ProximityZone.OUT_OF_RANGE);
        ProximityZone next = classify(distance, previous);

        if (next == previous) {
            return Optional.empty();
        }
        currentZones.put(id, next);
        return Optional.of(new ProximityUpdate(id, previous, next, distance));
    }

    /** Gọi khi beacon không còn được thấy (timeout) -> OUT_OF_RANGE. */
    public Optional<ProximityUpdate> markLost(BeaconId id) {
        ProximityZone previous = currentZones.remove(id);
        rssiWindows.remove(id);
        if (previous == null || previous == ProximityZone.OUT_OF_RANGE) {
            return Optional.empty();
        }
        return Optional.of(new ProximityUpdate(id, previous, ProximityZone.OUT_OF_RANGE, Double.NaN));
    }

    public ProximityZone getZone(BeaconId id) {
        return currentZones.getOrDefault(id, ProximityZone.OUT_OF_RANGE);
    }

    /** Công thức log-distance path loss. */
    public static double estimateDistance(double rssi, int txPower) {
        return Math.pow(10.0, (txPower - rssi) / (10.0 * PATH_LOSS_EXPONENT));
    }

    private ProximityZone classify(double d, ProximityZone previous) {
        // Hysteresis: muốn VÀO vùng gần hơn phải vượt ngưỡng sâu hơn một chút,
        // muốn RỜI vùng hiện tại phải vượt ngưỡng ra xa thêm một chút.
        double immediateLimit = previous == ProximityZone.IMMEDIATE ? immediateMax + hysteresis : immediateMax - hysteresis;
        double nearLimit = previous.isAtLeast(ProximityZone.NEAR) ? nearMax + hysteresis : nearMax - hysteresis;

        if (d < immediateLimit) return ProximityZone.IMMEDIATE;
        if (d < nearLimit) return ProximityZone.NEAR;
        return ProximityZone.FAR;
    }
}
