package com.smartheritage.engine.model;

/** Vùng khoảng cách giữa visitor và beacon. Thứ tự: xa nhất -> gần nhất. */
public enum ProximityZone {
    OUT_OF_RANGE,   // mất tín hiệu / quá xa
    FAR,            // > 3 m
    NEAR,           // 0.5 m .. 3 m
    IMMEDIATE;      // < 0.5 m

    /** true nếu vùng này đủ gần để kích hoạt nội dung hiện vật. */
    public boolean isAtLeast(ProximityZone other) {
        return this.ordinal() >= other.ordinal();
    }
}
