package com.smartheritage.engine.scanner;

import com.smartheritage.engine.model.BeaconId;
import com.smartheritage.engine.model.BeaconSignal;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;

/**
 * Giả lập visitor đi trong bảo tàng: phát lại một "kịch bản" gồm các bước
 * (beacon nào, RSSI trung bình, số lần scan), có thêm nhiễu ngẫu nhiên +-3 dBm
 * để giống tín hiệu BLE thật.
 *
 * Chạy đồng bộ (không thread) để dễ demo và dễ test.
 */
public class SimulatedBeaconScanner implements BeaconScanner {

    private record Step(BeaconId id, int meanRssi, int repeat) { }

    private final List<Step> script = new ArrayList<>();
    private final Random random;
    private final int txPower;
    private boolean scanning;

    public SimulatedBeaconScanner(long seed, int txPower) {
        this.random = new Random(seed);
        this.txPower = txPower;
    }

    /** Thêm 1 bước vào kịch bản. */
    public SimulatedBeaconScanner addStep(BeaconId id, int meanRssi, int repeat) {
        script.add(new Step(id, meanRssi, repeat));
        return this;
    }

    @Override
    public void start(Consumer<BeaconSignal> listener) {
        scanning = true;
        for (Step step : script) {
            for (int i = 0; i < step.repeat() && scanning; i++) {
                int noise = random.nextInt(7) - 3;   // -3 .. +3 dBm
                listener.accept(new BeaconSignal(step.id(), step.meanRssi() + noise, txPower));
            }
        }
        scanning = false;
    }

    @Override
    public void stop() { scanning = false; }

    @Override
    public boolean isScanning() { return scanning; }
}
