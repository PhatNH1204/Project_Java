package com.smartheritage.engine.model;

import java.time.Instant;

/**
 * Một lần scan BLE đọc được từ 1 beacon (dữ liệu thô).
 *
 * @param id        UUID + Major + Minor
 * @param rssi      cường độ tín hiệu nhận được (dBm, thường -30 .. -100)
 * @param txPower   RSSI đo ở khoảng cách 1m (calibrated, nằm trong gói iBeacon, thường ~ -59)
 * @param timestamp thời điểm scan
 */
public record BeaconSignal(BeaconId id, int rssi, int txPower, Instant timestamp) {

    public BeaconSignal(BeaconId id, int rssi, int txPower) {
        this(id, rssi, txPower, Instant.now());
    }
}
