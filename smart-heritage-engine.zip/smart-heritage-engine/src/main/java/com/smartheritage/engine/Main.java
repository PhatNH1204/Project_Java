package com.smartheritage.engine;

import com.smartheritage.engine.model.Beacon;
import com.smartheritage.engine.model.BeaconId;
import com.smartheritage.engine.proximity.ProximityManager;
import com.smartheritage.engine.scanner.BeaconScanner;
import com.smartheritage.engine.scanner.SimulatedBeaconScanner;

import java.util.Map;

/** Demo Tuần 1: visitor đi từ xa -> gần beacon A, rồi sang beacon B. */
public class Main {

    private static final String UUID = "E2C56DB5-DFFB-48D2-B060-D0F5A71096E0";
    private static final int TX_POWER = -59;

    public static void main(String[] args) {
        BeaconId a = new BeaconId(UUID, 1, 1);
        BeaconId b = new BeaconId(UUID, 1, 2);

        Map<BeaconId, Beacon> registry = Map.of(
                a, new Beacon(1L, "Trống đồng Đông Sơn", a, TX_POWER, true),
                b, new Beacon(2L, "Bảo kiếm thời Nguyễn", b, TX_POWER, true));

        // RSSI -80 ~ 9m (FAR) | -68 ~ 2.8m (NEAR) | -55 ~ 0.6m->IMMEDIATE | ...
        BeaconScanner scanner = new SimulatedBeaconScanner(42L, TX_POWER)
                .addStep(a, -80, 6)
                .addStep(a, -68, 6)
                .addStep(a, -50, 8)
                .addStep(b, -82, 5)
                .addStep(b, -65, 8);

        ProximityManager proximity = new ProximityManager();

        scanner.start(signal -> {
            proximity.process(signal).ifPresent(u -> System.out.printf(
                    "[%s] %-22s %-12s -> %-12s (~%.2f m)%n",
                    u.beaconId().minor() == 1 ? "A" : "B",
                    registry.get(u.beaconId()).getName(),
                    u.previousZone(), u.currentZone(), u.distanceMeters()));
        });
    }
}
