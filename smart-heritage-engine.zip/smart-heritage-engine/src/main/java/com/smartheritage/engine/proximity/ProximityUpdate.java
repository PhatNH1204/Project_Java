package com.smartheritage.engine.proximity;

import com.smartheritage.engine.model.BeaconId;
import com.smartheritage.engine.model.ProximityZone;

/** Kết quả khi vùng khoảng cách của 1 beacon thay đổi. */
public record ProximityUpdate(BeaconId beaconId,
                              ProximityZone previousZone,
                              ProximityZone currentZone,
                              double distanceMeters) {
}
