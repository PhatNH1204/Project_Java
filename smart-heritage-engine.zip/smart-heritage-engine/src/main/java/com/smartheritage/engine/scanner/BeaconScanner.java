package com.smartheritage.engine.scanner;

import com.smartheritage.engine.model.BeaconSignal;

import java.util.function.Consumer;

/**
 * Trừu tượng hoá việc scan BLE.
 * - Bản mô phỏng (SimulatedBeaconScanner) dùng để demo/test trên máy tính.
 * - Bản thật (Android BluetoothLeScanner) sẽ implement cùng interface này.
 */
public interface BeaconScanner {

    /** Bắt đầu scan; mỗi tín hiệu đọc được sẽ gọi listener. */
    void start(Consumer<BeaconSignal> listener);

    /** Dừng scan. */
    void stop();

    boolean isScanning();
}
