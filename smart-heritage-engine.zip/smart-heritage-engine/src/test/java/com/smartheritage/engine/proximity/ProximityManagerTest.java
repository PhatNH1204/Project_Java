package com.smartheritage.engine.proximity;

import com.smartheritage.engine.model.BeaconId;
import com.smartheritage.engine.model.BeaconSignal;
import com.smartheritage.engine.model.ProximityZone;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProximityManagerTest {

    private static final BeaconId A = new BeaconId("e2c56db5-dffb-48d2-b060-d0f5a71096e0", 1, 1);

    private void feed(ProximityManager pm, int rssi, int times) {
        for (int i = 0; i < times; i++) {
            pm.process(new BeaconSignal(A, rssi, -59));
        }
    }

    @Test
    void distanceAtTxPowerIsOneMeter() {
        assertEquals(1.0, ProximityManager.estimateDistance(-59, -59), 0.001);
    }

    @Test
    void uuidIsNormalizedToUpperCase() {
        assertEquals("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0", A.uuid());
    }

    @Test
    void farThenNearThenImmediate() {
        ProximityManager pm = new ProximityManager();
        feed(pm, -85, 5);
        assertEquals(ProximityZone.FAR, pm.getZone(A));
        feed(pm, -68, 5);
        assertEquals(ProximityZone.NEAR, pm.getZone(A));
        feed(pm, -50, 5);
        assertEquals(ProximityZone.IMMEDIATE, pm.getZone(A));
    }

    @Test
    void sameZoneProducesNoRepeatedUpdate() {
        ProximityManager pm = new ProximityManager();
        assertTrue(pm.process(new BeaconSignal(A, -68, -59)).isPresent());   // OUT_OF_RANGE -> NEAR
        for (int i = 0; i < 10; i++) {
            assertTrue(pm.process(new BeaconSignal(A, -68, -59)).isEmpty());
        }
    }

    @Test
    void markLostReturnsOutOfRange() {
        ProximityManager pm = new ProximityManager();
        feed(pm, -68, 3);
        var update = pm.markLost(A);
        assertTrue(update.isPresent());
        assertEquals(ProximityZone.OUT_OF_RANGE, update.get().currentZone());
        assertTrue(pm.markLost(A).isEmpty());
    }
}
