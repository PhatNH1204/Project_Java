# Đặc Tả Yêu Cầu Phần Mềm (SRS) & Kiến Trúc Điều Hướng Phân Hệ Mobile (TV2)

**Phân hệ:** TV2 — Ứng dụng Di động Khách tham quan (*Visitor Mobile Application*)  
**Phiên bản:** 1.0 (Tuần 6–7: Ổn định & Nghiệm thu)

---

## 1. Bối cảnh người dùng (User Context & Personas)

Ứng dụng di động **Heritage Guide (TV2)** phục vụ khách tham quan trực tiếp tại các khu di sản văn hóa, bảo tàng và di tích lịch sử (như *Hoàng thành Thăng Long*, *Văn Miếu – Quốc Tử Giám*, *Bảo tàng Lịch sử Quốc gia*).

### Các nhóm người dùng chính
1. **Khách tham quan trong nước (`vi`):**
   - Muốn tìm hiểu nhanh thông tin các điểm di tích, xem bản đồ vị trí các khu vực trưng bày và nghe thuyết minh tiếng Việt tự động khi đi bộ tới gần hiện vật có gắn thiết bị phát sóng **BLE Beacon**.
2. **Du khách quốc tế (`en`):**
   - Cần giao diện và toàn bộ nội dung thuyết minh (văn bản, âm thanh) tự động chuyển sang tiếng Anh (`Accept-Language: en`) ngay khi chọn ngôn ngữ ưu tiên trong hồ sơ hoặc màn hình đăng nhập.
3. **Bối cảnh di chuyển thực tế tại khu di sản:**
   - Sóng mạng 4G/Wi-Fi hoặc sóng Bluetooth Beacon trong các phòng trưng bày đá/tường thành dày có thể chập chờn hoặc mất tín hiệu đột ngột khi khách di chuyển vài bước chân. Do đó, ứng dụng **bắt buộc không được làm gián đoạn** trải nghiệm đọc/nghe thuyết minh khi khách rời vùng phủ sóng Beacon hoặc mất mạng tạm thời.

---

## 2. Yêu cầu Chức năng (Functional Requirements) & Phi chức năng (Non-Functional Requirements)

### 2.1. Yêu cầu Chức năng (FR)
- **FR-01 (Xác thực & Quản lý phiên - Phối hợp TV1):** Hỗ trợ Đăng nhập (`POST /api/auth/login`), Đăng ký (`POST /api/auth/register`), Tự động làm mới Access Token khi gặp `401` (`POST /api/auth/refresh`), và Đăng xuất (`POST /api/auth/logout`).
- **FR-02 (Hồ sơ & Đa ngôn ngữ - Phối hợp TV1 & TV4):** Xem/cập nhật thông tin cá nhân và ngôn ngữ ưu tiên (`GET/PUT /api/users/me`). Khi đổi ngôn ngữ (`vi` <-> `en`), toàn bộ giao diện và dữ liệu API tự động đồng bộ theo ngôn ngữ mới.
- **FR-03 (Khám phá Địa điểm - Phối hợp TV4):** Hiển thị danh sách `HeritageSite` (`GET /api/sites`), tìm kiếm theo tên/khu vực (hỗ trợ cả tiếng Việt không dấu) và lọc theo danh mục (`ALL`, `CITADEL`, `TEMPLE`, `MUSEUM`) với đủ 4 trạng thái (`Loading`, `Success`, `Empty`, `Error + Retry`).
- **FR-04 (Bản đồ Di sản):** Hiển thị các Marker địa điểm theo tọa độ `latitude`/`longitude`, kiểm tra quyền GPS trước khi định vị người dùng, và cho phép bấm vào Marker để xem danh sách `Artifact` thuộc địa điểm đó ngay cả khi từ chối quyền GPS.
- **FR-05 (Chi tiết Hiện vật & Đa phương tiện - Phối hợp TV4):** Hiển thị văn bản thuyết minh (`ContentTranslation` khớp `languageCode`, tự động fallback sang ngôn ngữ mặc định nếu thiếu bản dịch), thư viện ảnh (có ảnh dự phòng khi lỗi URL), trình phát Audio & Video (Play/Pause/Seek, cô lập lỗi từng file media) và tự động lưu vào `ArtifactCache` để xem Offline.
- **FR-06 (Yêu thích, Lịch sử & Đánh giá - Phối hợp TV5 & TV3):**
  - Nút Yêu thích áp dụng **Optimistic UI** (đổi trạng thái ngay, tự động hoàn tác khi lỗi mạng).
  - Tab 3 gồm 2 sub-tab **Yêu thích** và **Lịch sử tham quan** (hiển thị theo thời gian gần nhất, gắn nhãn phân biệt nguồn mở `MANUAL` vs `BEACON_BLE`, bấm vào mở lại `ArtifactDetail`).
  - Gửi đánh giá sao (`1..5`) và nhận xét (`POST /api/feedback`) có kiểm tra hợp lệ bắt buộc trước khi gửi.
- **FR-07 (Tích hợp BLE Bridge - Phối hợp TV3):** Nhận sự kiện từ TV3 qua `BleBridgeListener` (`onBeaconTriggered`, `onBeaconOutOfRange`, `onBleError`) và `Tv3BleAdapter` (chống lặp mở màn hình, báo thời lượng xem qua `InteractionCallback` để không ghi trùng `Interaction`).

### 2.2. Yêu cầu Phi chức năng (NFR)
- **NFR-01 (Bền bỉ khi mất sóng / mất mạng - Resilience):** Khi `onBeaconOutOfRange` xảy ra trong lúc khách đang xem `ArtifactDetail`, tuyệt đối không đóng màn hình, không xóa dữ liệu UI, không dừng Audio/Video đang phát.
- **NFR-02 (Bất đồng bộ & Mượt mà):** Toàn bộ tác vụ mạng và đĩa chạy trên luồng nền (`AppExecutors.io()`), cập nhật giao diện trên luồng chính (`AppExecutors.main()` / Swing EDT).
- **NFR-03 (Bảo mật & Tách biệt cấu hình):** Token được quản lý tập trung qua `SessionStorage` & `AuthInterceptor` (tự động redact header `Authorization` trong log HTTP); chuyển đổi môi trường `mock` <-> `dev-backend` qua biến môi trường hoặc file cấu hình mà không cần biên dịch lại.

---

## 3. Sơ đồ Điều hướng Ứng dụng (Mermaid Navigation Flow)

```mermaid
flowchart TD
    Splash["SplashScreen<br/>(Kiểm tra phiên SessionStorage)"]
    Login["LoginScreen<br/>(POST /api/auth/login)"]
    Register["RegisterScreen<br/>(POST /api/auth/register)"]
    Main["MainScreen (Bottom Navigation 4 Tabs)"]

    Tab1["Tab 1: Khám phá<br/>(GET /api/sites • Tìm kiếm & Lọc • 4 States)"]
    Tab2["Tab 2: Bản đồ Di sản<br/>(Markers Lat/Lng • Kiểm tra quyền GPS)"]
    Tab3["Tab 3: Yêu thích & Lịch sử<br/>(Sub-tab Yêu thích | Sub-tab Lịch sử)"]
    Tab4["Tab 4: Hồ sơ & Ngôn ngữ<br/>(GET/PUT /api/users/me • Đổi VI/EN • Logout)"]

    BlePrompt["Banner / BottomSheet Gợi ý Beacon<br/>(onBeaconTriggered: Xem ngay / Bỏ qua)"]
    Detail["ArtifactDetailScreen<br/>(Văn bản • Ảnh • Audio/Video • Yêu thích • Đánh giá • ArtifactCache)"]

    Splash -->|"Có phiên hợp lệ"| Main
    Splash -->|"Chưa đăng nhập / Hết phiên"| Login
    Login <-->|"Chuyển đổi"| Register
    Login -->|"Đăng nhập thành công"| Main
    Register -->|"Đăng ký thành công"| Main

    Main --> Tab1
    Main --> Tab2
    Main --> Tab3
    Main --> Tab4

    Tab1 -->|"Chọn Hiện vật"| Detail
    Tab2 -->|"Bấm Marker -> Chọn Hiện vật"| Detail
    Tab3 -->|"Nhấn mục Yêu thích / Lịch sử"| Detail
    Detail -->|"← Quay lại (Giữ nguyên Tab & Bộ lọc)"| Main

    BlePrompt -->|"Bấm 'Xem ngay'<br/>GET /api/beacons/{id}/content?lang="| Detail
    Tab4 -->|"Đăng xuất / 401 Refresh thất bại"| Login
```

---

## 4. Ma trận Xử lý Trạng thái (State & Exception Handling Matrix)

| Tình huống / Trạng thái | Tầng phát hiện | Hành vi xử lý tại Repository / ViewModel | Hiển thị trên Giao diện (UI) |
| :--- | :--- | :--- | :--- |
| **1. Đang tải dữ liệu (`LOADING`)** | `MainViewModel`, `ArtifactDetailViewModel` | Phát `UiState.loading()` trước khi chạy tác vụ trên `AppExecutors.io()`. | Hiển thị thanh tiến trình `JProgressBar` và các khung Shimmer/Skeleton card. |
| **2. Tìm kiếm / Lọc không có kết quả (`EMPTY`)** | `MainViewModel.applySiteFilters()` | Khi `HeritageRepository.filterSites(...)` trả về danh sách rỗng -> phát `UiState.empty()`. | Hiển thị thẻ **Empty State** (*"Không tìm thấy điểm di sản phù hợp"*) kèm nút **"Xóa bộ lọc"**. |
| **3. Lỗi kết nối mạng khi tải danh sách (`ERROR`)** | `ApiCaller` -> `ErrorMapper` | Bắt `IOException` / `SocketTimeoutException` -> phát `UiState.error(message)`. | Hiển thị thẻ **Error State** màu đỏ kèm thông điệp lỗi và nút **"↻ Thử lại"** (`retryLoadSites()`). |
| **4. Thiếu bản dịch theo ngôn ngữ đang chọn** | `Content.findTranslation(lang, defaultLang)` | Tìm bản dịch khớp `languageCode`; nếu không có sẽ tự động lấy bản dịch `AppConfig.DEFAULT_LANGUAGE` (`vi`). | Hiển thị đầy đủ văn bản thuyết minh bằng ngôn ngữ mặc định kèm nhãn thông báo fallback. |
| **5. Lỗi 1 file Ảnh / Audio / Video đơn lẻ** | `ArtifactDetailViewModel` & `ArtifactDetailScreen` | Kiểm tra độc lập từng URL media (`isImageBroken`, `isAudioBroken`, `isVideoBroken`). | - Ảnh lỗi: Vẽ **Ảnh dự phòng (Fallback Image)**.<br>- Audio/Video lỗi: Chỉ khung player đó hiện hộp báo lỗi + nút **↻ Thử lại tải Media**, **không làm trắng trang văn bản**. |
| **6. Từ chối quyền Vị trí (GPS Denied)** | `MainViewModel.locationPermissionGranted` | Đặt `locationPermissionGranted = false`, tắt tính khoảng cách từ vị trí người dùng. | Hiện thẻ hướng dẫn cấp quyền GPS + nút *Cấp quyền vị trí*; **Bản đồ và các Marker di sản vẫn bấm xem hiện vật bình thường**. |
| **7. Tắt Bluetooth / Từ chối quyền BLE** | `BlePermissionHelper` & `BleBridgeCoordinator.onBleError` | Cập nhật `BleErrorCode` (`BLUETOOTH_OFF` / `PERMISSION_DENIED`), phát `warningBannerMessage`. | Hiện Banner cảnh báo vàng ở đầu khung điện thoại kèm nút **"Bật BT / Cấp quyền"**; khách vẫn dùng toàn bộ tính năng thủ công bình thường. |
| **8. Rời vùng phủ sóng Beacon (`onBeaconOutOfRange`)** | `BleBridgeCoordinator` -> `ArtifactDetailViewModel` | Chuyển cờ `fromOfflineCache = true`, lấy dữ liệu dự phòng từ `ArtifactCache`, phát `beaconOutOfRangeNotice`. | **Không đóng màn hình, không xóa dữ liệu, không dừng Audio/Video đang phát**; hiện nhãn nhỏ: *"Bạn đã rời khỏi vùng beacon — vẫn có thể tiếp tục xem nội dung"*. |
| **9. Lỗi mạng khi bấm nút Yêu thích (Optimistic UI)** | `ArtifactDetailViewModel.toggleFavorite()` | Đổi `favoriteState` ngay khi chạm (`prev -> !prev`); khi API lỗi thì gán lại `favoriteState = prev`. | Nút Tim hoàn tác ngay về trạng thái ban đầu và hiển thị Toast: *"Lỗi kết nối: Đã hoàn tác trạng thái Yêu thích"*. |
| **10. Access Token hết hạn (`HTTP 401`)** | `AuthInterceptor` & `RetrofitTokenRefresher` | Đồng bộ hóa (`synchronized`), gọi `POST /api/auth/refresh`. Nếu thành công: lưu token mới & retry request. Nếu thất bại: xóa session. | - Nếu refresh thành công: hoàn toàn trong suốt với người dùng.<br>- Nếu refresh thất bại: tự động chuyển về màn hình `Login` kèm Toast báo hết phiên. |
