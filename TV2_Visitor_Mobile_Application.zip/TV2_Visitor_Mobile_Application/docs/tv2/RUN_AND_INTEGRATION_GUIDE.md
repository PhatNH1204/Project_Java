# Hướng Dẫn Cài Đặt, Chạy Ứng Dụng & Tích Hợp Hệ Thống (TV2)

**Phân hệ:** TV2 — Ứng dụng Di động Khách tham quan (*Visitor Mobile Application*)  
**Nhánh hoàn thiện:** `feature/mobile-docs-qa` (Tuần 6–7: Ổn định & Nghiệm thu)  
**Môi trường triển khai:** Maven Java 17 + Swing giả lập khung điện thoại chuẩn `390x844` (Retrofit2 + OkHttp3 + Gson + JUnit 5)

---

## 1. Yêu cầu môi trường & Cấu trúc thư mục

### 1.1. Yêu cầu công cụ
- **JDK:** Java 17 trở lên (tương thích hoàn toàn với JDK 17 / 21 / 25, biên dịch với cờ `--release 17`).
- **IDE khuyến nghị:** Eclipse IDE for Java Developers (đã cấu hình sẵn `.project`, `.classpath`, `.settings/`) hoặc IntelliJ IDEA / VS Code.
- **Thư viện phụ thuộc (đã khai báo trong `pom.xml`):**
  - `com.squareup.retrofit2:retrofit:2.11.0` & `converter-gson:2.11.0`
  - `com.squareup.okhttp3:okhttp:4.12.0` & `logging-interceptor:4.12.0`
  - `com.google.code.gson:gson:2.11.0`
  - `org.junit.jupiter:junit-jupiter:5.11.4` & `com.squareup.okhttp3:mockwebserver:4.12.0` (scope `test`)

### 1.2. Cấu trúc package `com.heritage.tv2`
```text
src/main/java/com/heritage/tv2/
├── Tv2App.java                         # Điểm khởi chạy ứng dụng (GUI 390x844 & --smoke-test)
├── config/
│   ├── AppConfig.java                  # Cấu hình môi trường (mock / dev-backend, BASE_URL, BLE Simulator)
│   └── AppContainer.java               # Dependency Injection container
├── model/                              # Bộ Entity / DTO khớp 100% Swagger (@SerializedName + alternate)
│   ├── User.java, Role.java, AuthTokens.java, Language.java, ApiResponse.java
│   ├── HeritageSite.java, Artifact.java, Content.java, ContentTranslation.java, Media.java, MediaType.java
│   ├── Favorite.java, VisitHistory.java, Feedback.java, FeedbackRequest.java
│   ├── BeaconSignalEvent.java
│   └── request/ (LoginRequest, RegisterRequest, RefreshTokenRequest, UpdateProfileRequest)
├── api/
│   ├── HeritageApiService.java         # Retrofit2 API Contract (14 endpoints: TV1, TV3, TV4, TV5)
│   ├── AuthInterceptor.java            # Tự gắn Bearer token + Accept-Language, tự refresh khi 401
│   ├── RetrofitTokenRefresher.java     # Client riêng gọi POST /api/auth/refresh
│   ├── ApiClient.java, ApiCaller.java, ErrorMapper.java
│   └── mock/ (MockBackendInterceptor.java, MockDataSource.java)
├── ble/
│   ├── BleBridgeListener.java          # Cổng giao tiếp bàn giao cho TV3 gọi vào
│   ├── InteractionCallback.java        # Hook báo thời điểm mở & thời lượng xem sang TV3
│   ├── BleBridgeCoordinator.java       # Điều phối Banner gợi ý Beacon & Out-of-Range Resilience
│   ├── Tv3BleAdapter.java              # Adapter nối module BLE thật của TV3 (chống lặp màn hình & Interaction)
│   ├── BlePermissionHelper.java        # Kiểm tra quyền Bluetooth/GPS theo SDK
│   ├── BleDebugSimulator.java          # Giả lập 4 kịch bản BLE chuẩn phối hợp TV3 & TV6
│   └── BleErrorCode.java, BeaconScanner.java, SimulatedBeaconScanner.java
├── cache/
│   ├── SessionStorage.java             # Lưu Access/Refresh Token, User & Ngôn ngữ ưu tiên
│   ├── ArtifactCache.java              # Lưu bản sao Artifact + ContentTranslation + Media xem Offline
│   └── KeyValueStore.java, FileKeyValueStore.java, InMemoryKeyValueStore.java, MemoryCache.java
├── repository/
│   ├── AuthRepository.java, UserRepository.java, LanguageRepository.java
│   ├── HeritageRepository.java, FavoriteRepository.java, FeedbackRepository.java
│   └── VisitHistoryRepository.java, VisitHistoryDataSource.java
├── ui/
│   ├── PhoneFrame.java                 # Khung điện thoại 390x844, Status Bar, Toast, BLE BottomSheet & Simulator
│   ├── Navigator.java                  # Điều hướng SPLASH -> LOGIN/REGISTER -> MAIN (4 Tabs) <-> ARTIFACT_DETAIL
│   ├── base/ (Screen.java, ViewModel.java, LiveData.java, Event.java, UiState.java)
│   ├── theme/ (UiTheme.java)
│   ├── splash/ (SplashScreen.java, SplashViewModel.java)
│   ├── auth/ (LoginScreen.java, LoginViewModel.java, RegisterScreen.java, RegisterViewModel.java)
│   ├── main/ (MainScreen.java, MainViewModel.java)
│   └── detail/ (ArtifactDetailScreen.java, ArtifactDetailViewModel.java)
└── util/
    └── I18n.java, AppExecutors.java, JsonProvider.java, Result.java, Validators.java
```

---

## 2. Cấu hình `BASE_URL` nối vào môi trường chung của TV6 (`mock` <-> `dev-backend`)

Ứng dụng TV2 hỗ trợ 2 chế độ vận hành trong [`AppConfig.java`](../../src/main/java/com/heritage/tv2/config/AppConfig.java):
1. **`mock` (Mặc định):** Mọi request Retrofit2 vẫn đi qua đầy đủ `AuthInterceptor` và `GsonConverterFactory`, sau đó được `MockBackendInterceptor` phản hồi bằng bộ dữ liệu đa ngôn ngữ (`vi`, `en`) mà không cần mạng.
2. **`dev-backend` (Tích hợp Docker/Server của TV6):** Gửi HTTP request thật tới máy chủ Spring Boot do TV6 dựng.

### Cách 1: Cấu hình qua file `src/main/resources/application.properties` (hoặc `~/.heritage-tv2/tv2-config.properties`)
```properties
# Đổi từ "mock" sang "dev-backend" khi nối vào Docker của TV6
tv2.env=dev-backend

# Địa chỉ Backend (luôn tự động chuẩn hóa dấu '/' ở cuối)
tv2.baseUrl=http://localhost:8080/

# Bật log HTTP và BLE Debug Simulator
tv2.httpLog=true
tv2.bleSim=true
```

### Cách 2: Cấu hình qua Biến môi trường Hệ điều hành (không cần sửa file)
```powershell
$env:TV2_ENV = "dev-backend"
$env:TV2_BACKEND_URL = "http://192.168.1.50:8080/"
$env:TV2_BLE_SIM = "true"
```

### Cách 3: Cấu hình qua Tham số dòng lệnh JVM (`-D`)
```powershell
java "-Dtv2.env=dev-backend" "-Dtv2.baseUrl=http://localhost:8080/" "-Dtv2.httpLog=true" -jar target/tv2-visitor-app.jar
```

> **Thứ tự ưu tiên cấu hình:** Tham số JVM (`-Dtv2.env`, `-Dtv2.baseUrl`) > Biến môi trường (`TV2_ENV`, `TV2_BACKEND_URL`) > File cấu hình ngoài (`~/.heritage-tv2/tv2-config.properties`) > File `src/main/resources/application.properties`.

---

## 3. Hướng dẫn bật/tắt và sử dụng Debug BLE Simulator (Phối hợp TV3 & TV6)

Panel **🛠 BLE Debug Simulator (TV3 & TV6)** nằm ở cạnh dưới khung điện thoại `PhoneFrame`, dùng để kiểm thử trực quan cầu nối `BleBridgeListener` mà không cần phần cứng Beacon vật lý.

### 3.1. Cách bật / tắt
- **Bật (Mặc định trong bản Debug/QA):**
  - Trong `application.properties`: `tv2.bleSim=true`
  - Hoặc JVM flag: `-Dtv2.bleSim=true` (hoặc `-Dtv2.debug=true`)
- **Tắt (Khi đóng gói bản trình diễn sản phẩm không muốn hiện thanh công cụ test):**
  - Truyền cờ JVM: `-Dtv2.bleSim=false -Dtv2.debug=false`

### 3.2. Ý nghĩa 4 nút kịch bản trên BLE Debug Simulator
| Nút trên Simulator | Sự kiện gọi vào `BleBridgeListener` | Hành vi kiểm tra trên TV2 |
| :--- | :--- | :--- |
| **`(1) Beacon vào vùng`** | `onBeaconTriggered(ENTER, B-101, -58 dBm)` | Hiện BottomSheet không gây gián đoạn: *"Phát hiện hiện vật gần bạn — Xem ngay / Bỏ qua"*. Bấm **Xem ngay** gọi `GET /api/beacons/B-101/content?lang={lang}` và mở `ArtifactDetail`. |
| **`(2) Rời vùng phủ sóng`** | `onBeaconOutOfRange(currentBeaconId)` | Nếu đang mở `ArtifactDetail` của beacon đó: **Không đóng màn hình, không xóa dữ liệu, không dừng Audio/Video**, chuyển nguồn dự phòng sang `ArtifactCache` và hiện nhãn vàng: *"Bạn đã rời khỏi vùng beacon — vẫn có thể tiếp tục xem nội dung"*. |
| **`(3) Chuyển Beacon khác`** | `onBeaconTriggered(SWITCH, B-102 -> B-103 -> B-104)` | Luân chuyển sang mã Beacon kế tiếp và hiển thị gợi ý cho hiện vật mới. |
| **`(4) Tắt BT / Từ chối quyền`** | `onBleError(BLUETOOTH_OFF / PERMISSION_DENIED)` | Hiện Banner cảnh báo ở đầu màn hình kèm nút **"Bật BT / Cấp quyền"**, nhưng khách vẫn thao tác tìm kiếm/xem bản đồ/xem hiện vật thủ công bình thường. |

---

## 4. Hướng dẫn Biên dịch, Chạy Ứng dụng & Chạy Kiểm thử (JUnit 5)

### 4.1. Chạy từ Eclipse IDE
1. Mở Eclipse -> `File` -> `Open Projects from File System...` -> Chọn thư mục `TV2_Visitor_Mobile_Application`.
2. Nhấp chuột phải vào [`Tv2App.java`](../../src/main/java/com/heritage/tv2/Tv2App.java) -> `Run As` -> `Java Application` để mở khung điện thoại Swing `390x844`.
3. Để chạy toàn bộ Unit & Integration Test: Nhấp chuột phải vào [`TestSuiteRunner.java`](../../src/test/java/com/heritage/tv2/TestSuiteRunner.java) -> `Run As` -> `Java Application` (hoặc `Run As` -> `JUnit Test` trên từng lớp `*Test.java` trong `src/test/java`).

### 4.2. Chạy bằng Maven (khi máy có cài `mvn`)
```powershell
# Chạy toàn bộ bộ JUnit 5 Test
mvn test

# Đóng gói JAR và chạy ứng dụng
mvn package
java -cp "target/tv2-visitor-app.jar;..." com.heritage.tv2.Tv2App
```

### 4.3. Chạy trực tiếp bằng JDK (`javac` / `java`) trên PowerShell (không cần `mvn` trên PATH)
```powershell
$m2 = "$env:USERPROFILE\.m2\repository"
$mainJars = @(
  "target\classes",
  "$m2\com\google\code\gson\gson\2.11.0\gson-2.11.0.jar",
  "$m2\com\squareup\okhttp3\okhttp\4.12.0\okhttp-4.12.0.jar",
  "$m2\com\squareup\okhttp3\logging-interceptor\4.12.0\logging-interceptor-4.12.0.jar",
  "$m2\com\squareup\okio\okio\3.6.0\okio-3.6.0.jar",
  "$m2\com\squareup\okio\okio-jvm\3.6.0\okio-jvm-3.6.0.jar",
  "$m2\com\squareup\retrofit2\retrofit\2.11.0\retrofit-2.11.0.jar",
  "$m2\com\squareup\retrofit2\converter-gson\2.11.0\converter-gson-2.11.0.jar",
  "$m2\org\jetbrains\kotlin\kotlin-stdlib\1.8.21\kotlin-stdlib-1.8.21.jar",
  "$m2\org\jetbrains\kotlin\kotlin-stdlib-common\1.9.10\kotlin-stdlib-common-1.9.10.jar",
  "$m2\org\jetbrains\kotlin\kotlin-stdlib-jdk7\1.8.21\kotlin-stdlib-jdk7-1.8.21.jar",
  "$m2\org\jetbrains\kotlin\kotlin-stdlib-jdk8\1.8.21\kotlin-stdlib-jdk8-1.8.21.jar",
  "$m2\org\jetbrains\annotations\13.0\annotations-13.0.jar"
) -join ";"

# 1. Mở giao diện khung điện thoại 390x844
java "-Dfile.encoding=UTF-8" -cp $mainJars com.heritage.tv2.Tv2App

# 2. Chạy Smoke Test tự động kiểm tra 9 bước từ Đăng nhập -> BLE -> Đăng xuất
java "-Dfile.encoding=UTF-8" -cp $mainJars com.heritage.tv2.Tv2App --smoke-test
```
