# Hướng Dẫn Sử Dụng Ứng Dụng Heritage Guide (Dành Cho Khách Tham Quan)

Chào mừng bạn đến với **Heritage Guide** — ứng dụng thuyết minh di sản văn hóa đa ngôn ngữ thông minh. Tài liệu này hướng dẫn từng bước cách sử dụng ứng dụng trong suốt hành trình tham quan.

---

## Bước 1: Đăng nhập, Đăng ký & Chọn ngôn ngữ ban đầu

1. Khi mở ứng dụng, màn hình **Splash** sẽ tự động kiểm tra phiên đăng nhập của bạn.
2. Tại màn hình **Đăng nhập**:
   - **Đổi ngôn ngữ nhanh:** Ở mục *"Ngôn ngữ giao diện"*, bạn có thể chọn ngay **Tiếng Việt (vi)** hoặc **English (en)**.
   - **Đăng nhập:** Nhập Email và Mật khẩu của bạn rồi bấm **Đăng nhập** (hoặc chọn nhanh nút tài khoản mẫu **Khách Việt (vi)** / **Tourist (en)** trong chế độ trải nghiệm).
   - **Tạo tài khoản mới:** Nếu chưa có tài khoản, bấm **Đăng ký ngay**, điền Họ tên, Email, Mật khẩu (tối thiểu 6 ký tự) và bấm **Đăng ký**.

---

## Bước 2: Tìm kiếm & Khám phá các Điểm Di sản (Tab 1 — 🏛 Khám phá)

1. Tại thanh điều hướng dưới cùng, chọn tab **🏛 Khám phá**.
2. **Tìm kiếm theo tên hoặc khu vực:** Nhập tên di tích hoặc quận/khu vực (ví dụ: *"Hoàng thành"*, *"Ba Đình"*, *"Văn Miếu"*) vào ô tìm kiếm và bấm **🔍 Tìm**.
3. **Lọc theo danh mục:** Chọn danh mục từ hộp chọn (*Tất cả danh mục*, *Hoàng thành / Thành cổ*, *Đền / Văn Miếu*, *Bảo tàng*).
4. Trên mỗi thẻ khu di sản, ứng dụng liệt kê các **Hiện vật thuộc địa điểm đó**. Bấm nút **Xem thuyết minh & Media →** cạnh hiện vật bất kỳ để mở màn hình thuyết minh chi tiết.

---

## Bước 3: Xem Bản đồ Di sản & Định vị GPS (Tab 2 — 🗺 Bản đồ)

1. Chọn tab **🗺 Bản đồ** ở thanh điều hướng dưới cùng.
2. **Quyền định vị GPS:**
   - Nếu bạn **Cấp quyền vị trí**, bản đồ hiển thị chấm xanh **GPS** tại vị trí của bạn và cho biết khoảng cách (`~km`) tới khu di sản đang chọn.
   - Nếu bạn **Từ chối quyền vị trí**, ứng dụng hiển thị hướng dẫn bật quyền ở đầu màn hình, nhưng bạn **vẫn có thể xem bản đồ và chạm vào bất kỳ điểm di sản nào bình thường**.
3. **Chạm vào Marker địa điểm trên bản đồ:** Thông tin tọa độ GPS, địa chỉ và **Danh sách hiện vật tại địa điểm đó** sẽ hiện ra ngay bên dưới bản đồ. Bấm **Xem thuyết minh & Media →** để xem chi tiết hiện vật.

---

## Bước 4: Nhận thông báo tự động khi đến gần Beacon BLE

1. Khi bạn bật Bluetooth và đi bộ tới gần một hiện vật có gắn thiết bị **BLE Beacon**, một thanh thông báo nhỏ sẽ xuất hiện nhẹ nhàng ở cạnh dưới màn hình:
   > **📡 Phát hiện hiện vật gần bạn** — *[Xem ngay]* *[Bỏ qua]*
2. Bấm **Xem ngay** để mở ngay bài thuyết minh của hiện vật trước mặt bạn (hoặc bấm **Bỏ qua** nếu bạn muốn tiếp tục xem màn hình hiện tại).
3. **Di chuyển ra khỏi vùng phủ sóng Beacon:**
   - Ngay cả khi bạn đi xa khỏi hiện vật hoặc vào khu vực mất sóng/mất mạng, ứng dụng **vẫn giữ nguyên bài thuyết minh và tiếp tục phát âm thanh/video** nhờ bộ nhớ đệm thông minh (`ArtifactCache`), kèm dòng thông báo nhỏ: *"Bạn đã rời khỏi vùng beacon — vẫn có thể tiếp tục xem nội dung"*.

---

## Bước 5: Xem Văn bản, Thư viện Ảnh, Nghe Audio & Xem Video 360°

Trên màn hình **Chi tiết Hiện vật**:
1. **📖 Văn bản thuyết minh:** Đọc toàn bộ lịch sử, niên đại và câu chuyện của hiện vật bằng ngôn ngữ bạn đã chọn (nếu hiện vật chưa có bản dịch ngôn ngữ của bạn, ứng dụng sẽ tự động hiển thị bản ngôn ngữ mặc định để bạn không bị bỏ lỡ thông tin).
2. **🖼 Thư viện hình ảnh:** Bấm **◀ Ảnh trước** / **Ảnh sau ▶** để xem các góc chụp của hiện vật.
3. **🎧 Thuyết minh Âm thanh (Audio Guide) & 🎬 Video Tư liệu 360°:**
   - Bấm **▶ Phát** / **⏸ Tạm dừng** để nghe hoặc xem.
   - Kéo thanh trượt để tua (**Seek**) tới bất kỳ thời điểm nào.

---

## Bước 6: Lưu Yêu thích, Gửi Đánh giá & Xem lại Lịch sử tham quan

1. **♥ Lưu Yêu thích:**
   - Trên màn hình **Chi tiết Hiện vật**, bấm nút **♥ Thêm yêu thích**. Trạng thái nút sẽ đổi ngay lập tức (và tự động hoàn tác nếu mạng bị gián đoạn).
2. **⭐ Đánh giá hiện vật / Gửi phản hồi:**
   - Cuộn xuống mục **⭐ Đánh giá hiện vật / Gửi phản hồi** ở cuối màn hình Chi tiết Hiện vật.
   - Chọn số sao từ **1 ★** đến **5 ★** và nhập nhận xét của bạn vào ô văn bản, sau đó bấm **Gửi đánh giá**.
3. **Xem lại Yêu thích & Lịch sử tham quan (Tab 3 — ♥ Yêu thích & Lịch sử):**
   - Mở tab **♥ Yêu thích & Lịch sử** ở thanh điều hướng dưới cùng.
   - Chuyển giữa 2 tab con:
     - **Yêu thích:** Danh sách các hiện vật bạn đã đánh dấu tim.
     - **Lịch sử tham quan:** Danh sách các hiện vật bạn đã xem được sắp xếp theo **thời gian gần nhất**, có nhãn ghi rõ bạn đã mở hiện vật đó bằng cách **`🖐 Mở thủ công`** hay **`📡 Từ Beacon BLE`**.
   - Bấm **Xem lại hiện vật →** ở bất kỳ mục nào để mở lại ngay màn hình thuyết minh chi tiết.

---

## Bước 7: Quản lý Hồ sơ & Đổi ngôn ngữ (Tab 4 — 👤 Hồ sơ & Ngôn ngữ)

1. Mở tab **👤 Hồ sơ & Ngôn ngữ**.
2. **Cập nhật thông tin cá nhân:** Chỉnh sửa Họ tên, Số điện thoại và bấm **Lưu hồ sơ**.
3. **Đổi ngôn ngữ thuyết minh & giao diện:** Chọn **Tiếng Việt (vi)** hoặc **English (en)**. Toàn bộ ứng dụng và nội dung thuyết minh sẽ chuyển sang ngôn ngữ mới ngay lập tức.
4. **Đăng xuất:** Bấm nút **Đăng xuất** ở cuối trang khi kết thúc phiên sử dụng.
