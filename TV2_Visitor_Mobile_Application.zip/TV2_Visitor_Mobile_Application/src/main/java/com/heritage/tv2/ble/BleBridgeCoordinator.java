package com.heritage.tv2.ble;

import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.repository.HeritageRepository;
import com.heritage.tv2.ui.base.LiveData;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * Bo dieu phoi BLE phia TV2, trien khai {@link BleBridgeListener} de nhan su kien tu TV3.
 *
 * <p>Chuc nang chinh:</p>
 * <ol>
 *     <li>Khi nhan {@link #onBeaconTriggered(BeaconSignalEvent)}: phat su kien hien thi
 *     Banner/BottomSheet khong gay gian doan (<i>"Phat hien hien vat gan ban — Xem ngay / Bo qua"</i>).</li>
 *     <li>Khi nguoi dung bam <b>"Xem ngay"</b> ({@link #acceptBeaconPrompt(BiConsumer)}):
 *     goi {@code GET /api/beacons/{id}/content?lang={lang}}, luu vao {@code ArtifactCache},
 *     thong bao {@link InteractionCallback#onContentOpened(String, long, long)} cho TV3 va mo {@code ArtifactDetail}.</li>
 *     <li>Khi nhan {@link #onBeaconOutOfRange(String)}: thong bao cho man hinh {@code ArtifactDetail}
 *     chuyen sang nguon du phong {@code ArtifactCache} va hien nhan trang thai nho ma KHONG dong man hinh,
 *     KHONG xoa du lieu, KHONG dung Audio/Video dang phat.</li>
 *     <li>Khi nhan {@link #onBleError(BleErrorCode, String)}: cap nhat {@link BlePermissionHelper}
 *     va hien banner canh bao ro rang (nhung van cho phep dung app thu cong binh thuong).</li>
 * </ol>
 */
public class BleBridgeCoordinator implements BleBridgeListener {

    /** Ban ghi log hook Interaction da gui sang TV3 (phuc vu kiem thu &amp; debug). */
    public static final class InteractionRecord {
        private final String beaconId;
        private final long artifactId;
        private final long openedAtEpochMs;
        private final int durationSeconds;
        private final boolean completed;

        public InteractionRecord(String beaconId, long artifactId, long openedAtEpochMs,
                                 int durationSeconds, boolean completed) {
            this.beaconId = beaconId;
            this.artifactId = artifactId;
            this.openedAtEpochMs = openedAtEpochMs;
            this.durationSeconds = durationSeconds;
            this.completed = completed;
        }

        public String getBeaconId() {
            return beaconId;
        }

        public long getArtifactId() {
            return artifactId;
        }

        public long getOpenedAtEpochMs() {
            return openedAtEpochMs;
        }

        public int getDurationSeconds() {
            return durationSeconds;
        }

        public boolean isCompleted() {
            return completed;
        }
    }

    private final HeritageRepository heritageRepository;
    private final AppExecutors executors;
    private final BlePermissionHelper permissionHelper;

    private final LiveData<BeaconSignalEvent> pendingBeaconPrompt = new LiveData<>();
    private final LiveData<String> outOfRangeBeaconId = new LiveData<>();
    private final LiveData<String> warningBannerMessage = new LiveData<>();

    private final List<InteractionRecord> recordedInteractions = Collections.synchronizedList(new ArrayList<>());
    private volatile InteractionCallback interactionCallback;
    private volatile String activeBeaconId;

    public BleBridgeCoordinator(HeritageRepository heritageRepository,
                                AppExecutors executors,
                                BlePermissionHelper permissionHelper) {
        this.heritageRepository = heritageRepository;
        this.executors = executors;
        this.permissionHelper = permissionHelper;
    }

    public BlePermissionHelper permissionHelper() {
        return permissionHelper;
    }

    /** Su kien Beacon dang cho nguoi dung bam "Xem ngay" hoac "Bo qua" tren Banner/BottomSheet. */
    public LiveData<BeaconSignalEvent> pendingBeaconPrompt() {
        return pendingBeaconPrompt;
    }

    /** Ma beacon vua roi khoi vung phu song. */
    public LiveData<String> outOfRangeBeaconId() {
        return outOfRangeBeaconId;
    }

    /** Thong diep banner canh bao khi Bluetooth tat hoac thieu quyen BLE (null neu binh thuong). */
    public LiveData<String> warningBannerMessage() {
        return warningBannerMessage;
    }

    public String getActiveBeaconId() {
        return activeBeaconId;
    }

    /** Dang ky hook de TV2 bao cho TV3 khi khach thuc su mo va xem noi dung hien vat. */
    public void setInteractionCallback(InteractionCallback interactionCallback) {
        this.interactionCallback = interactionCallback;
    }

    public List<InteractionRecord> getRecordedInteractions() {
        return List.copyOf(recordedInteractions);
    }

    // ==================================================== BleBridgeListener

    @Override
    public void onBeaconTriggered(BeaconSignalEvent event) {
        if (event == null || event.getBeaconId() == null) {
            return;
        }
        if (!permissionHelper.isBleReady()) {
            refreshWarningBanner();
            return;
        }
        this.activeBeaconId = event.getBeaconId();
        executors.main().execute(() -> {
            // Neu beacon nay vua bao out-of-range truoc do, xoa trang thai out-of-range
            if (event.getBeaconId().equalsIgnoreCase(outOfRangeBeaconId.getValue())) {
                outOfRangeBeaconId.setValue(null);
            }
            pendingBeaconPrompt.setValue(event);
        });
    }

    @Override
    public void onBeaconOutOfRange(String beaconId) {
        if (beaconId == null || beaconId.isBlank()) {
            return;
        }
        executors.main().execute(() -> {
            // Neu prompt cua beacon nay dang hien ma khach chua bam, an prompt
            BeaconSignalEvent pending = pendingBeaconPrompt.getValue();
            if (pending != null && beaconId.equalsIgnoreCase(pending.getBeaconId())) {
                pendingBeaconPrompt.setValue(null);
            }
            outOfRangeBeaconId.setValue(beaconId);
        });
    }

    @Override
    public void onBleError(BleErrorCode code, String message) {
        permissionHelper.applyBleError(code);
        executors.main().execute(() -> {
            pendingBeaconPrompt.setValue(null);
            String banner = permissionHelper.getWarningBannerMessage();
            if (message != null && !message.isBlank() && banner == null) {
                banner = message;
            }
            warningBannerMessage.setValue(banner);
        });
    }

    // =============================================== User Prompt Actions

    /** Nguoi dung bam "Bo qua" tren Banner/BottomSheet goi y beacon. */
    public void dismissBeaconPrompt() {
        executors.main().execute(() -> pendingBeaconPrompt.setValue(null));
    }

    /**
     * Nguoi dung bam "Xem ngay" tren Banner/BottomSheet goi y beacon:
     * Goi {@code GET /api/beacons/{id}/content?lang={lang}}, luu {@code ArtifactCache},
     * goi hook {@link InteractionCallback#onContentOpened(String, long, long)} va dieu huong sang {@code ArtifactDetail}.
     *
     * @param onOpenArtifactDetail callback nhan {@code (artifact, beaconId)} tren main thread
     */
    public void acceptBeaconPrompt(BiConsumer<Artifact, String> onOpenArtifactDetail) {
        BeaconSignalEvent event = pendingBeaconPrompt.getValue();
        if (event == null || event.getBeaconId() == null) {
            return;
        }
        String beaconId = event.getBeaconId();
        pendingBeaconPrompt.setValue(null);

        executors.io().execute(() -> {
            Result<Artifact> res = heritageRepository.getBeaconContent(beaconId);
            executors.main().execute(() -> {
                if (res.isSuccess() && res.getData() != null) {
                    Artifact artifact = res.getData();
                    notifyContentOpened(beaconId, artifact.getId());
                    if (onOpenArtifactDetail != null) {
                        onOpenArtifactDetail.accept(artifact, beaconId);
                    }
                }
            });
        });
    }

    /** Thong bao cho module TV3 thoi diem khach thuc su mo noi dung hien vat tu beacon. */
    public void notifyContentOpened(String beaconId, long artifactId) {
        if (beaconId == null || beaconId.isBlank()) {
            return;
        }
        long now = System.currentTimeMillis();
        recordedInteractions.add(new InteractionRecord(beaconId, artifactId, now, 0, false));
        InteractionCallback cb = this.interactionCallback;
        if (cb != null) {
            cb.onContentOpened(beaconId, artifactId, now);
        }
    }

    /** Thong bao cho module TV3 thoi luong khach da xem noi dung hien vat mo tu beacon. */
    public void notifyContentViewed(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds) {
        if (beaconId == null || beaconId.isBlank()) {
            return;
        }
        int safeDuration = Math.max(1, durationSeconds);
        recordedInteractions.add(new InteractionRecord(beaconId, artifactId, openedAtEpochMs, safeDuration, true));
        InteractionCallback cb = this.interactionCallback;
        if (cb != null) {
            cb.onContentViewed(beaconId, artifactId, openedAtEpochMs, safeDuration);
        }
    }

    /** Nguoi dung bam "Bat Bluetooth / Cap quyen" tren banner canh bao. */
    public void resolveBlePermissionsAndEnableBluetooth() {
        permissionHelper.enableBluetoothAndGrantPermissions();
        refreshWarningBanner();
    }

    public void refreshWarningBanner() {
        executors.main().execute(() ->
                warningBannerMessage.setValue(permissionHelper.getWarningBannerMessage()));
    }

    public String formatPromptMessage(BeaconSignalEvent event) {
        if (event == null) {
            return "";
        }
        return I18n.tr("ble.prompt_message", event.getBeaconId(), event.getRssi());
    }
}
