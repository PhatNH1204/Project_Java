package com.heritage.tv2.ui.auth;

import com.heritage.tv2.model.User;
import com.heritage.tv2.repository.AuthRepository;
import com.heritage.tv2.ui.base.Event;
import com.heritage.tv2.ui.base.LiveData;
import com.heritage.tv2.ui.base.ViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Validators;

/**
 * ViewModel man hinh Dang ky ({@code POST /api/auth/register} -> {@code GET /api/users/me}).
 */
public class RegisterViewModel extends ViewModel {

    private final AuthRepository authRepository;

    private final LiveData<Boolean> loading = new LiveData<>(false);
    private final LiveData<Event<String>> errorEvent = new LiveData<>();
    private final LiveData<Event<User>> registerSuccess = new LiveData<>();

    public RegisterViewModel(AuthRepository authRepository, AppExecutors executors) {
        super(executors);
        this.authRepository = authRepository;
    }

    public LiveData<Boolean> loading() {
        return loading;
    }

    public LiveData<Event<String>> errorEvent() {
        return errorEvent;
    }

    public LiveData<Event<User>> registerSuccess() {
        return registerSuccess;
    }

    public void register(String fullName, String email, String password, String confirmPassword) {
        if (!Validators.isNotBlank(fullName)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.invalid_name")));
            return;
        }
        if (!Validators.isValidEmail(email)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.invalid_email")));
            return;
        }
        if (!Validators.isValidPassword(password)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.invalid_password")));
            return;
        }
        if (!password.equals(confirmPassword)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.password_mismatch")));
            return;
        }
        loading.setValue(true);
        launch(() -> authRepository.register(email, password, fullName), result -> {
            loading.setValue(false);
            if (result.isSuccess()) {
                registerSuccess.setValue(new Event<>(result.getData()));
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(result)));
            }
        });
    }
}
