package com.heritage.tv2.cache;

import java.util.HashMap;
import java.util.Map;

/**
 * Kho key-value don gian (tuong duong {@code SharedPreferences} tren Android).
 * Gia tri {@code null} trong {@link #putAll(Map)} nghia la xoa key.
 */
public interface KeyValueStore {

    String get(String key);

    /** Ghi nhieu key trong mot lan (atomic tren cung instance). */
    void putAll(Map<String, String> values);

    default void put(String key, String value) {
        Map<String, String> m = new HashMap<>();
        m.put(key, value);
        putAll(m);
    }

    default void remove(String key) {
        put(key, null);
    }
}
