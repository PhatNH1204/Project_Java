package com.heritage.tv2.ble;

import com.heritage.tv2.model.BeaconSignalEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Adapter ket noi su kien that tu module BLE cua TV3 vao {@link BleBridgeListener}
 * ({@link BleBridgeCoordinator}) cua TV2 (Tich hop Tuan 5-6).
 *
 * <p>Dam bao 2 quy tac an toan tich hop:</p>
 * <ol>
 *     <li><b>Chong vong lap mo man hinh (No Screen-Opening Loop)</b>:
 *     Neu khach tham quan dang mo man hinh {@code ArtifactDetail} cua chinh beacon {@code B-xxx}
 *     (hoac Banner goi y cua {@code B-xxx} dang hien thi), cac su kien {@code ENTER/SWITCH} lap lai
 *     cung ma {@code B-xxx} tu TV3 se bi chan lai, khong kich hoat mo lai man hinh.</li>
 *     <li><b>Chong ghi trung {@code Interaction} (No Duplicate Interaction Logging)</b>:
 *     Moi phien xem noi dung {@code (beaconId, artifactId)} chi gui duy nhat 1 su kien
 *     {@code onContentOpened} va 1 su kien {@code onContentViewed} sang module TV3.</li>
 * </ol>
 */
public class Tv3BleAdapter implements InteractionCallback {

    /**
     * Hop dong module TV3 nhan thong tin Interaction thuc te tu TV2.
     */
    public interface Tv3InteractionSink {
        void recordInteractionStart(String beaconId, long artifactId, long openedAtEpochMs);

        void recordInteractionEnd(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds);
    }

    private final BleBridgeCoordinator bridgeCoordinator;
    private volatile Tv3InteractionSink tv3Sink;

    /** Ma beacon cua man hinh ArtifactDetail dang mo (null neu khach khong o ArtifactDetail). */
    private volatile String currentlyViewingBeaconId;
    private volatile Long currentlyViewingArtifactId;

    /** Cac phien Interaction (beaconId:artifactId) da bao OPEN sang TV3 va chua ket thuc. */
    private final Set<String> openInteractionSessions = ConcurrentHashMap.newKeySet();
    /** Cac phien Interaction (beaconId:artifactId:openedAt) da bao VIEWED hoan tat sang TV3. */
    private final Set<String> completedInteractionSessions = ConcurrentHashMap.newKeySet();

    private final AtomicInteger suppressedLoopTriggerCount = new AtomicInteger();
    private final AtomicInteger suppressedDuplicateInteractionCount = new AtomicInteger();
    private final List<String> forwardedTv3Events = Collections.synchronizedList(new ArrayList<>());

    public Tv3BleAdapter(BleBridgeCoordinator bridgeCoordinator) {
        this(bridgeCoordinator, null);
    }

    public Tv3BleAdapter(BleBridgeCoordinator bridgeCoordinator, Tv3InteractionSink tv3Sink) {
        this.bridgeCoordinator = bridgeCoordinator;
        this.tv3Sink = tv3Sink;
        this.bridgeCoordinator.setInteractionCallback(this);
    }

    public void setTv3InteractionSink(Tv3InteractionSink tv3Sink) {
        this.tv3Sink = tv3Sink;
    }

    /**
     * Navigator / ArtifactDetailViewModel bao cho Adapter biet hien vat &amp; beacon nao dang hien thi tren man hinh.
     */
    public void notifyScreenViewingBeacon(String beaconId, Long artifactId) {
        this.currentlyViewingBeaconId = normalizeBeaconId(beaconId);
        this.currentlyViewingArtifactId = artifactId;
    }

    /** Goi khi khach thoat khoi man hinh ArtifactDetail. */
    public void notifyScreenClosed() {
        this.currentlyViewingBeaconId = null;
        this.currentlyViewingArtifactId = null;
    }

    public String getCurrentlyViewingBeaconId() {
        return currentlyViewingBeaconId;
    }

    public int getSuppressedLoopTriggerCount() {
        return suppressedLoopTriggerCount.get();
    }

    public int getSuppressedDuplicateInteractionCount() {
        return suppressedDuplicateInteractionCount.get();
    }

    public List<String> getForwardedTv3Events() {
        return List.copyOf(forwardedTv3Events);
    }

    // ========================================= Entrypoints for TV3 BLE Module

    /**
     * Nhan su kien phat hien/chuyen vung beacon that tu module TV3.
     */
    public void onTv3BeaconDetected(String beaconId,
                                    String uuid,
                                    int major,
                                    int minor,
                                    int filteredRssi,
                                    String transitionType,
                                    long timestampEpochMs) {
        BeaconSignalEvent.EventType type = parseEventType(transitionType);
        if (type == BeaconSignalEvent.EventType.EXIT) {
            onTv3BeaconLost(beaconId);
            return;
        }
        BeaconSignalEvent event = new BeaconSignalEvent(
                beaconId, uuid, major, minor, filteredRssi, type,
                timestampEpochMs > 0 ? timestampEpochMs : System.currentTimeMillis());
        onTv3BeaconEvent(event);
    }

    /**
     * Nhan truc tiep {@link BeaconSignalEvent} tu TV3 va kiem tra chong vong lap mo man hinh.
     *
     * @return {@code true} neu su kien duoc chuyen tiep sang TV2, {@code false} neu bi chan do trung man hinh dang mo
     */
    public boolean onTv3BeaconEvent(BeaconSignalEvent event) {
        if (event == null || event.getBeaconId() == null || event.getBeaconId().isBlank()) {
            return false;
        }
        if (event.getEventType() == BeaconSignalEvent.EventType.EXIT) {
            onTv3BeaconLost(event.getBeaconId());
            return true;
        }

        String incomingId = normalizeBeaconId(event.getBeaconId());

        // 1. Chong vong lap mo man hinh: neu khach DANG XEM dung beacon nay tren ArtifactDetail -> bo qua
        if (incomingId.equals(currentlyViewingBeaconId)) {
            suppressedLoopTriggerCount.incrementAndGet();
            return false;
        }

        // 2. Neu Banner goi y cho chinh beacon nay dang hien thi tren man hinh -> khong phat lap lai
        BeaconSignalEvent pending = bridgeCoordinator.pendingBeaconPrompt().getValue();
        if (pending != null && incomingId.equals(normalizeBeaconId(pending.getBeaconId()))) {
            suppressedLoopTriggerCount.incrementAndGet();
            return false;
        }

        forwardedTv3Events.add("TRIGGER:" + incomingId + ":" + event.getEventType());
        bridgeCoordinator.onBeaconTriggered(event);
        return true;
    }

    /**
     * Nhan su kien mat song beacon tu module TV3.
     */
    public void onTv3BeaconLost(String beaconId) {
        if (beaconId == null || beaconId.isBlank()) {
            return;
        }
        String norm = normalizeBeaconId(beaconId);
        forwardedTv3Events.add("OUT_OF_RANGE:" + norm);
        bridgeCoordinator.onBeaconOutOfRange(beaconId);
    }

    /**
     * Nhan su kien thay doi trang thai Bluetooth / Quyen tu module TV3.
     */
    public void onTv3BleStatusError(BleErrorCode errorCode, String detailMessage) {
        forwardedTv3Events.add("ERROR:" + errorCode);
        bridgeCoordinator.onBleError(errorCode, detailMessage);
    }

    // =============================== InteractionCallback (Deduplication Guard)

    @Override
    public void onContentOpened(String beaconId, long artifactId, long openedAtEpochMs) {
        String normBeacon = normalizeBeaconId(beaconId);
        notifyScreenViewingBeacon(normBeacon, artifactId);

        String sessionKey = normBeacon + ":" + artifactId;
        if (!openInteractionSessions.add(sessionKey)) {
            // Phien nay da duoc ghi nhan OPEN truoc do va chua dong -> chan ghi trung Interaction!
            suppressedDuplicateInteractionCount.incrementAndGet();
            return;
        }

        Tv3InteractionSink sink = this.tv3Sink;
        if (sink != null) {
            sink.recordInteractionStart(normBeacon, artifactId, openedAtEpochMs);
        }
    }

    @Override
    public void onContentViewed(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds) {
        String normBeacon = normalizeBeaconId(beaconId);
        String sessionKey = normBeacon + ":" + artifactId;
        String completedKey = sessionKey + ":" + openedAtEpochMs;

        openInteractionSessions.remove(sessionKey);
        if (normBeacon.equals(currentlyViewingBeaconId)) {
            notifyScreenClosed();
        }

        if (!completedInteractionSessions.add(completedKey)) {
            // Luot xem nay da duoc bao ket thuc truoc do -> chan ghi trung Interaction!
            suppressedDuplicateInteractionCount.incrementAndGet();
            return;
        }

        Tv3InteractionSink sink = this.tv3Sink;
        if (sink != null) {
            sink.recordInteractionEnd(normBeacon, artifactId, openedAtEpochMs, Math.max(1, durationSeconds));
        }
    }

    private static BeaconSignalEvent.EventType parseEventType(String raw) {
        if (raw == null || raw.isBlank()) {
            return BeaconSignalEvent.EventType.ENTER;
        }
        try {
            return BeaconSignalEvent.EventType.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return BeaconSignalEvent.EventType.ENTER;
        }
    }

    private static String normalizeBeaconId(String beaconId) {
        return beaconId == null ? "" : beaconId.trim().toUpperCase(Locale.ROOT);
    }
}
