package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

/**
 * Nguoi dung - khop Entity {@code User} cua TV1.
 * Tra ve tu {@code GET /api/users/me} va {@code PUT /api/users/me}.
 */
public class User {

    @SerializedName(value = "id", alternate = {"userId", "user_id"})
    private Long id;

    @SerializedName(value = "email", alternate = {"username"})
    private String email;

    @SerializedName(value = "fullName", alternate = {"full_name", "name", "displayName", "display_name"})
    private String fullName;

    @SerializedName(value = "phone", alternate = {"phoneNumber", "phone_number"})
    private String phone;

    @SerializedName(value = "avatarUrl", alternate = {"avatar_url", "avatar"})
    private String avatarUrl;

    @SerializedName(value = "role", alternate = {"userRole", "user_role"})
    private Role role;

    /** Ma ngon ngu uu tien (vi/en) - cap nhat qua {@code PUT /api/users/me}. */
    @SerializedName(value = "preferredLanguage", alternate = {"preferred_language", "languageCode", "language_code", "lang"})
    private String preferredLanguage;

    /** ISO-8601, vd: 2026-11-19T12:00:00Z. */
    @SerializedName(value = "createdAt", alternate = {"created_at"})
    private String createdAt;

    public User() {
    }

    public User(Long id, String email, String fullName, Role role, String preferredLanguage) {
        this.id = id;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.preferredLanguage = preferredLanguage;
    }

    /** Ban sao nong (shallow) de mock backend khong chia se tham chieu voi UI. */
    public User copy() {
        User u = new User(id, email, fullName, role, preferredLanguage);
        u.phone = phone;
        u.avatarUrl = avatarUrl;
        u.createdAt = createdAt;
        return u;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return Objects.equals(id, user.id)
                && Objects.equals(email, user.email)
                && Objects.equals(fullName, user.fullName)
                && Objects.equals(preferredLanguage, user.preferredLanguage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, email, fullName, preferredLanguage);
    }

    @Override
    public String toString() {
        return "User{id=" + id + ", email='" + email + "', lang=" + preferredLanguage + '}';
    }
}
