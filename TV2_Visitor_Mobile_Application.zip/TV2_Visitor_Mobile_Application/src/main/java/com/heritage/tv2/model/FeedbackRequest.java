package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Body cua {@code POST /api/feedback} - khop DTO {@code FeedbackRequest} (TV2/TV5).
 * Ho tro day du schema JSON that (camelCase &amp; snake_case) tu Swagger/OpenAPI.
 */
public class FeedbackRequest {

    public static final int MIN_RATING = 1;
    public static final int MAX_RATING = 5;
    public static final int MAX_COMMENT_LENGTH = 1000;

    public enum ValidationError {
        MISSING_ARTIFACT,
        INVALID_RATING,
        EMPTY_COMMENT,
        COMMENT_TOO_LONG
    }

    @SerializedName(value = "artifactId", alternate = {"artifact_id"})
    private Long artifactId;

    @SerializedName(value = "rating", alternate = {"stars", "score"})
    private Integer rating;

    @SerializedName(value = "comment", alternate = {"feedback", "content", "reviewText", "review_text"})
    private String comment;

    public FeedbackRequest() {
    }

    public FeedbackRequest(Long artifactId, Integer rating, String comment) {
        this.artifactId = artifactId;
        this.rating = rating;
        this.comment = comment;
    }

    /**
     * Kiem tra chi tiet tung truong bat buoc truoc khi gui.
     *
     * @return {@code null} neu hop le, hoac ma loi {@link ValidationError} cu the
     */
    public ValidationError validate() {
        if (artifactId == null || artifactId <= 0) {
            return ValidationError.MISSING_ARTIFACT;
        }
        if (rating == null || rating < MIN_RATING || rating > MAX_RATING) {
            return ValidationError.INVALID_RATING;
        }
        if (comment == null || comment.trim().isEmpty()) {
            return ValidationError.EMPTY_COMMENT;
        }
        if (comment.trim().length() > MAX_COMMENT_LENGTH) {
            return ValidationError.COMMENT_TOO_LONG;
        }
        return null;
    }

    /** Kiem tra hop le phia client truoc khi gui (backend van validate lai). */
    public boolean isValid() {
        return validate() == null;
    }

    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
