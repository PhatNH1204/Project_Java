package com.heritage.tv2.api;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.ApiResponse;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Locale;

/**
 * Anh xa ma loi &amp; HTTP status tu Swagger/OpenAPI that cua Backend (TV1, TV3, TV4, TV5, TV6)
 * sang {@link Result} va thong diep da ngon ngu ({@code vi} / {@code en}) tren TV2.
 */
public final class ErrorMapper {

    // Ma loi chuan hoa tren TV2
    public static final String AUTH_INVALID_CREDENTIALS = "AUTH_INVALID_CREDENTIALS";
    public static final String AUTH_TOKEN_EXPIRED = "AUTH_TOKEN_EXPIRED";
    public static final String AUTH_TOKEN_INVALID = "AUTH_TOKEN_INVALID";
    public static final String AUTH_REFRESH_INVALID = "AUTH_REFRESH_INVALID";
    public static final String AUTH_EMAIL_EXISTS = "AUTH_EMAIL_EXISTS";
    public static final String FORBIDDEN = "FORBIDDEN";
    public static final String NOT_FOUND = "NOT_FOUND";
    public static final String LANGUAGE_NOT_SUPPORTED = "LANGUAGE_NOT_SUPPORTED";
    public static final String VALIDATION_ERROR = "VALIDATION_ERROR";
    public static final String SERVER_ERROR = "SERVER_ERROR";
    public static final String NETWORK_TIMEOUT = "NETWORK_TIMEOUT";

    private ErrorMapper() {
    }

    /**
     * Chuyen {@link ApiResponse} loi hoac HTTP status code cua Backend thanh {@link Result#error}.
     */
    public static <T> Result<T> mapHttpError(ApiResponse<?> body, int httpStatus) {
        String rawCode = null;
        String rawMessage = null;
        if (body != null) {
            rawMessage = body.getMessage();
            ApiResponse.ApiError apiErr = body.getError();
            if (apiErr != null) {
                rawCode = apiErr.getCode();
                if (apiErr.getMessage() != null && !apiErr.getMessage().isBlank()) {
                    rawMessage = apiErr.getMessage();
                } else if (apiErr.getDetails() != null && !apiErr.getDetails().isEmpty()) {
                    rawMessage = formatFieldErrors(apiErr.getDetails());
                }
            }
        }
        String canonicalCode = normalizeCode(rawCode, httpStatus);
        String userMessage = (rawMessage != null && !rawMessage.isBlank())
                ? rawMessage
                : defaultLocalizedMessage(canonicalCode, httpStatus, I18n.getLanguage());
        return Result.error(canonicalCode, userMessage, httpStatus);
    }

    /**
     * Chuyen {@link IOException} (timeout, connection refused, DNS) thanh {@link Result}.
     */
    public static <T> Result<T> mapNetworkException(IOException e) {
        return Result.networkError(e);
    }

    /**
     * Chuan hoa cac bien the ma loi giua TV1, TV3, TV4, TV5 ve ma chuan cua TV2.
     */
    public static String normalizeCode(String rawCode, int httpStatus) {
        if (rawCode != null && !rawCode.isBlank()) {
            String upper = rawCode.trim().toUpperCase(Locale.ROOT);
            switch (upper) {
                case "AUTH_INVALID_CREDENTIALS":
                case "INVALID_CREDENTIALS":
                case "BAD_CREDENTIALS":
                    return AUTH_INVALID_CREDENTIALS;
                case "AUTH_TOKEN_EXPIRED":
                case "TOKEN_EXPIRED":
                case "JWT_EXPIRED":
                    return AUTH_TOKEN_EXPIRED;
                case "AUTH_TOKEN_INVALID":
                case "INVALID_TOKEN":
                case "UNAUTHORIZED":
                    return AUTH_TOKEN_INVALID;
                case "AUTH_REFRESH_INVALID":
                case "REFRESH_TOKEN_EXPIRED":
                case "INVALID_REFRESH_TOKEN":
                    return AUTH_REFRESH_INVALID;
                case "AUTH_EMAIL_EXISTS":
                case "EMAIL_ALREADY_EXISTS":
                case "DUPLICATE_EMAIL":
                    return AUTH_EMAIL_EXISTS;
                case "LANGUAGE_NOT_SUPPORTED":
                case "UNSUPPORTED_LANGUAGE":
                    return LANGUAGE_NOT_SUPPORTED;
                case "VALIDATION_ERROR":
                case "BAD_REQUEST":
                case "METHOD_ARGUMENT_NOT_VALID":
                case "FEEDBACK_INVALID_RATING":
                    return VALIDATION_ERROR;
                case "NOT_FOUND":
                case "RESOURCE_NOT_FOUND":
                case "SITE_NOT_FOUND":
                case "ARTIFACT_NOT_FOUND":
                case "BEACON_NOT_FOUND":
                case "USER_NOT_FOUND":
                    return NOT_FOUND;
                case "FORBIDDEN":
                case "ACCESS_DENIED":
                    return FORBIDDEN;
                case "INTERNAL_SERVER_ERROR":
                case "SERVICE_UNAVAILABLE":
                    return SERVER_ERROR;
                default:
                    return upper;
            }
        }
        // Fallback theo HTTP status code khi backend khong tra error.code
        switch (httpStatus) {
            case 400:
            case 422:
                return VALIDATION_ERROR;
            case 401:
                return Result.CODE_UNAUTHORIZED;
            case 403:
                return FORBIDDEN;
            case 404:
                return NOT_FOUND;
            case 409:
                return AUTH_EMAIL_EXISTS;
            case 500:
            case 502:
            case 503:
            case 504:
                return SERVER_ERROR;
            default:
                return "HTTP_" + httpStatus;
        }
    }

    public static String defaultLocalizedMessage(String canonicalCode, int httpStatus, String lang) {
        boolean en = AppConfig.LANGUAGE_EN.equalsIgnoreCase(lang);
        switch (canonicalCode) {
            case AUTH_INVALID_CREDENTIALS:
                return en ? "Incorrect email or password." : "Email hoặc mật khẩu không đúng.";
            case AUTH_TOKEN_EXPIRED:
            case AUTH_TOKEN_INVALID:
            case AUTH_REFRESH_INVALID:
            case Result.CODE_UNAUTHORIZED:
                return en ? "Your session has expired. Please sign in again."
                        : "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.";
            case AUTH_EMAIL_EXISTS:
                return en ? "This email is already registered." : "Email đã được sử dụng.";
            case FORBIDDEN:
                return en ? "You do not have permission to perform this action."
                        : "Bạn không có quyền thực hiện thao tác này.";
            case NOT_FOUND:
                return en ? "Requested heritage resource was not found."
                        : "Không tìm thấy dữ liệu di sản yêu cầu.";
            case LANGUAGE_NOT_SUPPORTED:
                return en ? "Selected language is not supported." : "Ngôn ngữ không được hỗ trợ.";
            case VALIDATION_ERROR:
                return en ? "Invalid input data. Please check your entries."
                        : "Dữ liệu nhập không hợp lệ. Vui lòng kiểm tra lại.";
            case SERVER_ERROR:
                return en ? "Server is temporarily unavailable (HTTP " + httpStatus + ")."
                        : "Máy chủ đang bận hoặc bảo trì (HTTP " + httpStatus + ").";
            default:
                return I18n.tr("error.unknown");
        }
    }

    public static String describeNetworkException(Throwable cause, String lang) {
        boolean en = AppConfig.LANGUAGE_EN.equalsIgnoreCase(lang);
        if (cause instanceof SocketTimeoutException) {
            return en ? "Connection timed out. Please try again."
                    : "Kết nối tới máy chủ quá thời gian chờ. Vui lòng thử lại.";
        }
        if (cause instanceof ConnectException || cause instanceof UnknownHostException) {
            return I18n.tr("error.network");
        }
        return I18n.tr("error.network");
    }

    private static String formatFieldErrors(List<ApiResponse.FieldError> details) {
        StringBuilder sb = new StringBuilder();
        for (ApiResponse.FieldError fe : details) {
            if (fe.getMessage() != null && !fe.getMessage().isBlank()) {
                if (sb.length() > 0) {
                    sb.append("; ");
                }
                sb.append(fe.getMessage());
            }
        }
        return sb.toString();
    }
}
