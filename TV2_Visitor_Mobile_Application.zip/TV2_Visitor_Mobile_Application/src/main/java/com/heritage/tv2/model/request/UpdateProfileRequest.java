package com.heritage.tv2.model.request;

/**
 * Body {@code PUT /api/users/me} - cap nhat ho so &amp; ngon ngu uu tien.
 * Cac truong null nghia la "khong thay doi" (partial update).
 */
public class UpdateProfileRequest {

    private String fullName;
    private String phone;
    private String avatarUrl;
    private String preferredLanguage;

    public UpdateProfileRequest() {
    }

    public static UpdateProfileRequest language(String languageCode) {
        UpdateProfileRequest r = new UpdateProfileRequest();
        r.preferredLanguage = languageCode;
        return r;
    }

    public static UpdateProfileRequest profile(String fullName, String phone) {
        UpdateProfileRequest r = new UpdateProfileRequest();
        r.fullName = fullName;
        r.phone = phone;
        return r;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }
}
