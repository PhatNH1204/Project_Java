package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Noi dung thuyet minh - khop Entity {@code Content} cua TV4.
 * Mot Content co nhieu {@link ContentTranslation} (theo ngon ngu) va nhieu {@link Media}.
 */
public class Content {

    @SerializedName(value = "id", alternate = {"contentId", "content_id"})
    private Long id;

    @SerializedName(value = "artifactId", alternate = {"artifact_id"})
    private Long artifactId;

    @SerializedName(value = "translations", alternate = {"contentTranslations", "content_translations"})
    private List<ContentTranslation> translations = new ArrayList<>();

    @SerializedName(value = "media", alternate = {"mediaList", "media_list", "mediaAssets", "media_assets"})
    private List<Media> media = new ArrayList<>();

    public Content() {
    }

    public Content(Long id, Long artifactId, List<ContentTranslation> translations, List<Media> media) {
        this.id = id;
        this.artifactId = artifactId;
        this.translations = translations == null ? new ArrayList<>() : new ArrayList<>(translations);
        this.media = media == null ? new ArrayList<>() : new ArrayList<>(media);
    }

    /**
     * Lay ban dich theo ngon ngu, fallback: ngon ngu yeu cau -> {@code fallbackCode} -> ban dau tien.
     */
    public ContentTranslation findTranslation(String languageCode, String fallbackCode) {
        if (translations == null || translations.isEmpty()) {
            return null;
        }
        for (ContentTranslation t : translations) {
            if (t.getLanguageCode() != null && t.getLanguageCode().equalsIgnoreCase(languageCode)) {
                return t;
            }
        }
        for (ContentTranslation t : translations) {
            if (t.getLanguageCode() != null && t.getLanguageCode().equalsIgnoreCase(fallbackCode)) {
                return t;
            }
        }
        return translations.get(0);
    }

    public List<Media> mediaOfType(MediaType type) {
        if (media == null) {
            return List.of();
        }
        return media.stream().filter(m -> m.getMediaType() == type).collect(Collectors.toList());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public List<ContentTranslation> getTranslations() {
        return translations;
    }

    public void setTranslations(List<ContentTranslation> translations) {
        this.translations = translations;
    }

    public List<Media> getMedia() {
        return media;
    }

    public void setMedia(List<Media> media) {
        this.media = media;
    }
}
