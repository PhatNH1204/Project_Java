package com.heritage.tv2;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.PhoneFrame;
import com.heritage.tv2.ui.sql.SqlDatabaseInspectorDialog;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import java.awt.GraphicsEnvironment;
import java.util.Arrays;
import java.util.List;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Diem khoi chay ung dung TV2 - Visitor Mobile Application (Gate 2 / Tuan 1-2).
 *
 * <ul>
 *     <li>Chay giao dien khung dien thoai Swing 390x844: {@code java com.heritage.tv2.Tv2App}</li>
 *     <li>Chay kiem thu tu dong luong Dang nhap -> Main -> Ho so &amp; Doi ngon ngu:
 *     {@code java com.heritage.tv2.Tv2App --smoke-test}</li>
 * </ul>
 */
public final class Tv2App {

    private Tv2App() {
    }

    public static void main(String[] args) {
        List<String> argList = Arrays.asList(args);
        boolean showSqlTables = argList.contains("--show-sql-tables");
        boolean openSqlWindow = argList.contains("--open-sql");
        boolean smokeTest = argList.contains("--smoke-test");

        if (showSqlTables) {
            AppContainer container = new AppContainer(
                    new InMemoryKeyValueStore(),
                    AppExecutors.direct(),
                    new MockBackendInterceptor(0L),
                    AppConfig.MOCK_BASE_URL);
            SqlDatabaseInspectorDialog.printAllTablesToConsole(container);
            return;
        }
        if (smokeTest || GraphicsEnvironment.isHeadless()) {
            runSmokeVerification();
            return;
        }

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            AppContainer container = AppContainer.createDefault();
            PhoneFrame frame = new PhoneFrame(container);
            frame.setVisible(true);
            frame.start();
            if (openSqlWindow) {
                frame.openSqlDatabaseInspector();
            }
        });
    }

    /**
     * Kiem tra toan bo luong bat buoc Gate 2:
     * Dang nhap -> Main (Kham pha, Ban do, Yeu thich &amp; Lich su, Ho so &amp; Ngon ngu)
     * -> Doi ngon ngu (vi -> en) -> Auto Refresh Token khi 401 -> Dang xuat.
     */
    public static void runSmokeVerification() {
        System.out.println("=== [TV2 Gate 2] Smoke Verification (USE_MOCK_DATA=" + AppConfig.USE_MOCK_DATA + ") ===");
        MockBackendInterceptor mock = new MockBackendInterceptor(0L);
        AppContainer container = new AppContainer(
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mock,
                AppConfig.MOCK_BASE_URL);

        // 1. Login
        Result<User> loginRes = container.authRepository()
                .login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        require(loginRes.isSuccess(), "Login failed: " + loginRes);
        User userVi = loginRes.getData();
        require("vi".equals(userVi.getPreferredLanguage()), "Expected initial preferredLanguage=vi");
        System.out.println("[1/6] Login OK: " + userVi.getFullName() + " <" + userVi.getEmail()
                + "> (lang=" + container.sessionStorage().getLanguage() + ")");

        // 2. Load data in Vietnamese (Accept-Language: vi)
        Result<List<HeritageSite>> sitesVi = container.heritageRepository().getSites(true);
        require(sitesVi.isSuccess() && !sitesVi.getData().isEmpty(), "Sites (vi) failed");
        String firstSiteVi = sitesVi.getData().get(0).getName();
        System.out.println("[2/6] Sites (vi) OK: " + firstSiteVi + " (" + sitesVi.getData().size() + " sites)");

        Result<Artifact> beaconContentVi = container.heritageRepository().getBeaconContent("B-101");
        require(beaconContentVi.isSuccess() && beaconContentVi.getData() != null, "Beacon content failed");
        System.out.println("      Beacon B-101 (vi) -> " + beaconContentVi.getData().getName());

        // 3. Favorites & Visit History + Feedback
        Result<List<Favorite>> favsVi = container.favoriteRepository().getFavorites();
        Result<List<VisitHistory>> historyVi = container.visitHistoryRepository().getVisitHistory();
        Result<Void> fbRes = container.feedbackRepository().submit(new FeedbackRequest(101L, 5, "Tuyet voi!"));
        require(favsVi.isSuccess() && historyVi.isSuccess() && fbRes.isSuccess(), "Fav/History/Feedback failed");
        System.out.println("[3/6] Favorites=" + favsVi.getData().size()
                + ", VisitHistory=" + historyVi.getData().size() + ", Feedback=201 Created");

        // 4. Switch language vi -> en via PUT /api/users/me
        Result<User> langSwitch = container.languageRepository().changeLanguage(AppConfig.LANGUAGE_EN);
        require(langSwitch.isSuccess(), "Language switch failed: " + langSwitch);
        I18n.setLanguage(container.sessionStorage().getLanguage());
        require("en".equals(container.sessionStorage().getLanguage()), "Session language should be 'en'");

        Result<List<HeritageSite>> sitesEn = container.heritageRepository().getSites(true);
        require(sitesEn.isSuccess() && !sitesEn.getData().isEmpty(), "Sites (en) failed");
        String firstSiteEn = sitesEn.getData().get(0).getName();
        require(!firstSiteVi.equals(firstSiteEn), "Site name should be localized after switching vi -> en");
        System.out.println("[4/6] Language switch vi -> en OK: '" + firstSiteVi + "' -> '" + firstSiteEn
                + "', UI tab='" + I18n.tr("tab.profile") + "'");

        // 5. Simulate 401 Access Token expiry -> verify AuthInterceptor auto-refresh
        mock.expireAllAccessTokens();
        Result<User> afterRefresh = container.userRepository().getProfile();
        require(afterRefresh.isSuccess() && mock.getRefreshCount() == 1,
                "Expected transparent 401 refresh; refreshCount=" + mock.getRefreshCount());
        System.out.println("[5/7] 401 -> Auto Token Refresh OK (refreshCount=" + mock.getRefreshCount() + ")");

        // 6. Gate 3 Part 1: Search/Filter sites + ArtifactDetail + Offline ArtifactCache fallback
        List<HeritageSite> filteredSites = container.heritageRepository()
                .filterSites(sitesEn.getData(), "Ba Dinh", HeritageSite.CATEGORY_CITADEL);
        require(filteredSites.size() == 1, "Expected 1 Citadel site in Ba Dinh");
        Result<Artifact> detailOnline = container.heritageRepository().getArtifact(101L);
        require(detailOnline.isSuccess() && container.artifactCache().contains(101L),
                "Artifact 101 must be cached in ArtifactCache");
        mock.setSimulateNetworkError(true);
        Result<Artifact> detailOffline = container.heritageRepository().getArtifact(101L);
        mock.setSimulateNetworkError(false);
        require(detailOffline.isSuccess() && container.heritageRepository().isLastArtifactFromOfflineCache(),
                "Artifact 101 must be served from ArtifactCache when offline");
        System.out.println("[6/7] Gate 3 Part 1: Site Filter + ArtifactDetail + Offline ArtifactCache OK ("
                + detailOffline.getData().getName() + ")");

        // 7. Gate 3 Part 2: Optimistic Favorite + Feedback validation + VisitHistory source & sorting
        container.visitHistoryRepository().recordArtifactView(
                detailOnline.getData(), "National Museum", VisitHistory.SOURCE_MANUAL);
        Result<List<VisitHistory>> latestHistory = container.visitHistoryRepository().getVisitHistory();
        require(latestHistory.isSuccess() && !latestHistory.getData().isEmpty()
                        && latestHistory.getData().get(0).getArtifactId() == 101L
                        && VisitHistory.SOURCE_MANUAL.equals(latestHistory.getData().get(0).getSource()),
                "VisitHistory must put newly viewed artifact at index 0 with MANUAL source");
        Result<Void> invalidFb = container.feedbackRepository().submit(new FeedbackRequest(101L, 5, "   "));
        require(!invalidFb.isSuccess(), "Empty feedback comment must be rejected");
        System.out.println("[7/8] Gate 3 Part 2: Optimistic Favorite + Feedback Validation + VisitHistory (MANUAL/BEACON_BLE) OK");

        // 8. Gate 4: BLE Bridge (Beacon Enter -> Prompt -> Open Detail -> Out of Range Resilience)
        container.bleDebugSimulator().triggerEnterBeacon("B-101");
        require(container.bleBridge().pendingBeaconPrompt().getValue() != null,
                "Beacon ENTER must emit non-intrusive prompt");
        final Artifact[] openedFromBeacon = new Artifact[1];
        container.bleBridge().acceptBeaconPrompt((art, bId) -> openedFromBeacon[0] = art);
        require(openedFromBeacon[0] != null && openedFromBeacon[0].getId() == 101L,
                "Accepting beacon prompt must fetch GET /api/beacons/B-101/content?lang=en and return Artifact 101");
        container.bleDebugSimulator().triggerOutOfRange("B-101");
        require("B-101".equals(container.bleBridge().outOfRangeBeaconId().getValue()),
                "Out of range beacon ID must be tracked");
        System.out.println("[8/9] Gate 4: BLE Bridge (ENTER -> Prompt -> GET /api/beacons/{id}/content?lang=en -> OutOfRange Resilience) OK");

        // 9. Logout
        Result<Void> logoutRes = container.authRepository().logout();
        require(logoutRes.isSuccess() && !container.sessionStorage().isLoggedIn(), "Logout failed");
        System.out.println("[9/9] Logout OK (session cleared, language preserved="
                + container.sessionStorage().getLanguage() + ")");
        System.out.println("=== ALL SMOKE CHECKS PASSED ===");
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new IllegalStateException("Smoke check failed: " + message);
        }
    }
}
