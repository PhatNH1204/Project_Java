package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Lich su tham quan - khop Entity {@code VisitHistory} (TV2/TV5 &amp; TV3 Interaction).
 *
 * <p>Ho tro day du schema JSON that (camelCase &amp; snake_case) tu Swagger/OpenAPI,
 * bao gom ca truong hop backend map truc tiep tu bang {@code Interaction} cua TV3
 * ({@code interactionTime}, {@code dwellTimeSeconds}, {@code triggerSource}).</p>
 */
public class VisitHistory {

    public static final String SOURCE_MANUAL = "MANUAL";
    public static final String SOURCE_BEACON_BLE = "BEACON_BLE";

    @SerializedName(value = "id", alternate = {"historyId", "history_id", "interactionId", "interaction_id"})
    private Long id;

    @SerializedName(value = "userId", alternate = {"user_id", "visitorId", "visitor_id"})
    private Long userId;

    @SerializedName(value = "siteId", alternate = {"site_id", "heritageSiteId", "heritage_site_id"})
    private Long siteId;

    @SerializedName(value = "artifactId", alternate = {"artifact_id"})
    private Long artifactId;

    /** Ten hien vat da ban dia hoa (backend nhung san). */
    @SerializedName(value = "artifactName", alternate = {"artifact_name", "artifactTitle", "artifact_title"})
    private String artifactName;

    @SerializedName(value = "siteName", alternate = {"site_name", "heritageSiteName", "heritage_site_name"})
    private String siteName;

    /** ISO-8601 (sap xep giam dan theo thoi gian gan nhat). */
    @SerializedName(value = "visitedAt", alternate = {"visited_at", "interactionTime", "interaction_time", "createdAt", "created_at"})
    private String visitedAt;

    /** Thoi gian dung xem (giay). */
    @SerializedName(value = "durationSeconds", alternate = {"duration_seconds", "dwellTimeSeconds", "dwell_time_seconds", "duration"})
    private Integer durationSeconds;

    /** Nguon mo: MANUAL (Thu cong) hoac BEACON_BLE (Tu Beacon BLE). */
    @SerializedName(value = "source", alternate = {"triggerSource", "trigger_source", "openSource", "open_source", "interactionType", "interaction_type"})
    private String source = SOURCE_MANUAL;

    public VisitHistory() {
    }

    public VisitHistory(Long id, Long userId, Long siteId, Long artifactId, String artifactName,
                        String siteName, String visitedAt, Integer durationSeconds) {
        this(id, userId, siteId, artifactId, artifactName, siteName, visitedAt, durationSeconds, SOURCE_BEACON_BLE);
    }

    public VisitHistory(Long id, Long userId, Long siteId, Long artifactId, String artifactName,
                        String siteName, String visitedAt, Integer durationSeconds, String source) {
        this.id = id;
        this.userId = userId;
        this.siteId = siteId;
        this.artifactId = artifactId;
        this.artifactName = artifactName;
        this.siteName = siteName;
        this.visitedAt = visitedAt;
        this.durationSeconds = durationSeconds;
        this.source = (source == null || source.isBlank()) ? SOURCE_MANUAL : source;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public String getArtifactName() {
        return artifactName;
    }

    public void setArtifactName(String artifactName) {
        this.artifactName = artifactName;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getVisitedAt() {
        return visitedAt;
    }

    public void setVisitedAt(String visitedAt) {
        this.visitedAt = visitedAt;
    }

    public Integer getDurationSeconds() {
        return durationSeconds;
    }

    public void setDurationSeconds(Integer durationSeconds) {
        this.durationSeconds = durationSeconds;
    }

    public String getSource() {
        return source == null ? SOURCE_MANUAL : source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public boolean isFromBeacon() {
        return SOURCE_BEACON_BLE.equalsIgnoreCase(source)
                || "BLE".equalsIgnoreCase(source)
                || "BEACON".equalsIgnoreCase(source);
    }
}
