package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Entity / Response DTO {@code Feedback} cua TV5 (tra ve khi {@code POST /api/feedback}
 * hoac {@code GET /api/feedback} tren backend that).
 */
public class Feedback {

    @SerializedName(value = "id", alternate = {"feedbackId", "feedback_id"})
    private Long id;

    @SerializedName(value = "userId", alternate = {"user_id", "visitorId", "visitor_id"})
    private Long userId;

    @SerializedName(value = "artifactId", alternate = {"artifact_id"})
    private Long artifactId;

    @SerializedName(value = "rating", alternate = {"stars", "score"})
    private Integer rating;

    @SerializedName(value = "comment", alternate = {"feedback", "content", "reviewText", "review_text"})
    private String comment;

    @SerializedName(value = "createdAt", alternate = {"created_at", "submittedAt", "submitted_at"})
    private String createdAt;

    public Feedback() {
    }

    public Feedback(Long id, Long userId, Long artifactId, Integer rating, String comment, String createdAt) {
        this.id = id;
        this.userId = userId;
        this.artifactId = artifactId;
        this.rating = rating;
        this.comment = comment;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
