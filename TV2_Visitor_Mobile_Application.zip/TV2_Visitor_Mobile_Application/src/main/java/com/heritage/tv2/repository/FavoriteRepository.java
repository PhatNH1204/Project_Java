package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.util.Result;

import java.util.List;

/** Hien vat yeu thich: {@code GET/POST/DELETE /api/favorites}. */
public class FavoriteRepository {

    private final HeritageApiService api;

    public FavoriteRepository(HeritageApiService api) {
        this.api = api;
    }

    public Result<List<Favorite>> getFavorites() {
        return ApiCaller.execute(api.getFavorites());
    }

    public Result<Favorite> addFavorite(long artifactId) {
        return ApiCaller.execute(api.addFavorite(artifactId));
    }

    public Result<Void> removeFavorite(long artifactId) {
        return ApiCaller.execute(api.removeFavorite(artifactId));
    }
}
