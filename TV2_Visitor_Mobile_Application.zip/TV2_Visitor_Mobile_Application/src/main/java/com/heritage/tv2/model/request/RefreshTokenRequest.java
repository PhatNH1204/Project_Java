package com.heritage.tv2.model.request;

/** Body {@code POST /api/auth/refresh} va {@code POST /api/auth/logout}. */
public class RefreshTokenRequest {

    private String refreshToken;

    public RefreshTokenRequest() {
    }

    public RefreshTokenRequest(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }
}
