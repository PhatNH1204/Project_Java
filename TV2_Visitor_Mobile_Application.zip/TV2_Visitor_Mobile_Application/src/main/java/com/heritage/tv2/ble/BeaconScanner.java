package com.heritage.tv2.ble;

import com.heritage.tv2.model.BeaconSignalEvent;

/**
 * Hop dong tang BLE (TV3 cung cap thuat toan nhan dien vung beacon).
 * Ban Android se trien khai bang {@code BluetoothLeScanner}; ban Swing dung {@link SimulatedBeaconScanner}.
 */
public interface BeaconScanner {

    /** Nhan su kien ENTER / EXIT / SWITCH. */
    @FunctionalInterface
    interface Listener {
        void onBeaconEvent(BeaconSignalEvent event);
    }

    void start(Listener listener);

    void stop();

    boolean isScanning();
}
