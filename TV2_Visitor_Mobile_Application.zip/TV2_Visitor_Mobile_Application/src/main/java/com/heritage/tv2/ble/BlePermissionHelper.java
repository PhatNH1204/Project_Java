package com.heritage.tv2.ble;

import com.heritage.tv2.util.I18n;

import java.util.ArrayList;
import java.util.List;

/**
 * Kiem tra va huong dan xin quyen Bluetooth / Vi tri theo nen tang (Android 12+ vs Android 8-11),
 * dong thoi quan ly trang thai banner canh bao khi Bluetooth dang tat hoac thieu quyen.
 *
 * <p><b>Quy tac:</b> Ngay ca khi Bluetooth dang tat hoac nguoi dung tu choi quyen BLE,
 * {@link #canUseAppManually()} luon tra ve {@code true} de khach van dung app thu cong
 * (tim kiem, xem ban do, xem chi tiet hien vat, yeu thich, danh gia) binh thuong.</p>
 */
public class BlePermissionHelper {

    public static final String PERM_BLUETOOTH_SCAN = "android.permission.BLUETOOTH_SCAN";
    public static final String PERM_BLUETOOTH_CONNECT = "android.permission.BLUETOOTH_CONNECT";
    public static final String PERM_ACCESS_FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";

    private volatile boolean bluetoothEnabled = true;
    private volatile boolean blePermissionGranted = true;
    private volatile boolean locationPermissionGranted = true;
    private volatile boolean hardwareSupported = true;
    private volatile BleErrorCode lastErrorCode;

    /**
     * Danh sach quyen BLE can xin theo phien ban Android SDK.
     * <ul>
     *     <li>Android 12+ (API 31+): {@code BLUETOOTH_SCAN}, {@code BLUETOOTH_CONNECT}</li>
     *     <li>Android 8-11 (API 26-30): {@code ACCESS_FINE_LOCATION}</li>
     * </ul>
     */
    public List<String> requiredPermissionsForSdk(int androidSdkInt) {
        List<String> perms = new ArrayList<>();
        if (androidSdkInt >= 31) {
            perms.add(PERM_BLUETOOTH_SCAN);
            perms.add(PERM_BLUETOOTH_CONNECT);
        } else {
            perms.add(PERM_ACCESS_FINE_LOCATION);
        }
        return perms;
    }

    /** Kiem tra thiet bi da san sang nhan tin hieu BLE tu TV3 hay chua. */
    public boolean isBleReady() {
        return hardwareSupported && bluetoothEnabled && blePermissionGranted && locationPermissionGranted;
    }

    /**
     * Khach tham quan LUON duoc phep su dung app thu cong binh thuong
     * ngay ca khi Bluetooth tat hoac tu choi quyen BLE.
     */
    public boolean canUseAppManually() {
        return true;
    }

    public boolean isBluetoothEnabled() {
        return bluetoothEnabled;
    }

    public void setBluetoothEnabled(boolean bluetoothEnabled) {
        this.bluetoothEnabled = bluetoothEnabled;
        this.lastErrorCode = bluetoothEnabled ? null : BleErrorCode.BLUETOOTH_OFF;
    }

    public boolean isBlePermissionGranted() {
        return blePermissionGranted;
    }

    public void setBlePermissionGranted(boolean blePermissionGranted) {
        this.blePermissionGranted = blePermissionGranted;
        this.lastErrorCode = blePermissionGranted ? null : BleErrorCode.PERMISSION_DENIED;
    }

    public boolean isLocationPermissionGranted() {
        return locationPermissionGranted;
    }

    public void setLocationPermissionGranted(boolean locationPermissionGranted) {
        this.locationPermissionGranted = locationPermissionGranted;
        if (!locationPermissionGranted) {
            this.lastErrorCode = BleErrorCode.PERMISSION_DENIED;
        } else if (blePermissionGranted && bluetoothEnabled) {
            this.lastErrorCode = null;
        }
    }

    public boolean isHardwareSupported() {
        return hardwareSupported;
    }

    public void setHardwareSupported(boolean hardwareSupported) {
        this.hardwareSupported = hardwareSupported;
        this.lastErrorCode = hardwareSupported ? null : BleErrorCode.HARDWARE_UNSUPPORTED;
    }

    /** Cap nhat trang thai khi TV3 bao loi qua {@link BleBridgeListener#onBleError(BleErrorCode, String)}. */
    public void applyBleError(BleErrorCode code) {
        this.lastErrorCode = code;
        if (code == BleErrorCode.BLUETOOTH_OFF) {
            this.bluetoothEnabled = false;
        } else if (code == BleErrorCode.PERMISSION_DENIED) {
            this.blePermissionGranted = false;
        } else if (code == BleErrorCode.HARDWARE_UNSUPPORTED) {
            this.hardwareSupported = false;
        }
    }

    /** Khoi phuc tat ca quyen &amp; bat lai Bluetooth (khi nguoi dung bam "Bat Bluetooth / Cap quyen"). */
    public void enableBluetoothAndGrantPermissions() {
        this.hardwareSupported = true;
        this.bluetoothEnabled = true;
        this.blePermissionGranted = true;
        this.locationPermissionGranted = true;
        this.lastErrorCode = null;
    }

    public BleErrorCode getLastErrorCode() {
        return lastErrorCode;
    }

    /**
     * Noi dung banner canh bao &amp; huong dan khi Bluetooth dang tat hoac thieu quyen.
     * Tra ve {@code null} neu BLE dang hoat dong binh thuong.
     */
    public String getWarningBannerMessage() {
        if (!hardwareSupported || lastErrorCode == BleErrorCode.HARDWARE_UNSUPPORTED) {
            return I18n.tr("ble.error_hardware_unsupported");
        }
        if (!bluetoothEnabled || lastErrorCode == BleErrorCode.BLUETOOTH_OFF) {
            return I18n.tr("ble.error_bluetooth_off");
        }
        if (!blePermissionGranted || !locationPermissionGranted || lastErrorCode == BleErrorCode.PERMISSION_DENIED) {
            return I18n.tr("ble.error_permission_denied");
        }
        if (lastErrorCode == BleErrorCode.SCAN_FAILED) {
            return I18n.tr("ble.error_scan_failed");
        }
        return null;
    }
}
