package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Cap token xac thuc - khop DTO {@code AuthTokens} cua TV1.
 * Tra ve tu {@code POST /api/auth/login}, {@code /register}, {@code /refresh}.
 */
public class AuthTokens {

    @SerializedName(value = "accessToken", alternate = {"access_token", "token", "jwt"})
    private String accessToken;

    @SerializedName(value = "refreshToken", alternate = {"refresh_token"})
    private String refreshToken;

    /** Mac dinh "Bearer". */
    @SerializedName(value = "tokenType", alternate = {"token_type", "type"})
    private String tokenType = "Bearer";

    /** So giay con hieu luc cua access token (tuy chon). */
    @SerializedName(value = "expiresIn", alternate = {"expires_in", "expirationSeconds"})
    private Long expiresIn;

    public AuthTokens() {
    }

    public AuthTokens(String accessToken, String refreshToken) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
    }

    public AuthTokens(String accessToken, String refreshToken, Long expiresIn) {
        this(accessToken, refreshToken);
        this.expiresIn = expiresIn;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public Long getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Long expiresIn) {
        this.expiresIn = expiresIn;
    }

    public boolean hasAccessToken() {
        return accessToken != null && !accessToken.isBlank();
    }

    @Override
    public String toString() {
        return "AuthTokens{type=" + tokenType + ", expiresIn=" + expiresIn + '}';
    }
}
