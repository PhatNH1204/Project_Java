package com.heritage.tv2.config;

import com.heritage.tv2.api.ApiClient;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.ble.BleBridgeCoordinator;
import com.heritage.tv2.ble.BleDebugSimulator;
import com.heritage.tv2.ble.BlePermissionHelper;
import com.heritage.tv2.ble.Tv3BleAdapter;
import com.heritage.tv2.cache.ArtifactCache;
import com.heritage.tv2.cache.FileKeyValueStore;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.cache.KeyValueStore;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.repository.AuthRepository;
import com.heritage.tv2.repository.FavoriteRepository;
import com.heritage.tv2.repository.FeedbackRepository;
import com.heritage.tv2.repository.HeritageRepository;
import com.heritage.tv2.repository.LanguageRepository;
import com.heritage.tv2.repository.UserRepository;
import com.heritage.tv2.repository.VisitHistoryRepository;
import com.heritage.tv2.util.AppExecutors;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Dependency container thu cong (tuong duong Hilt module / Application class ben Android).
 * Tao mot lan khi khoi dong va truyen xuong UI.
 */
public final class AppContainer {

    private final AppExecutors executors;
    private final SessionStorage sessionStorage;
    private final ArtifactCache artifactCache;
    private final MockBackendInterceptor mockBackend;
    private final ApiClient apiClient;

    private final AuthRepository authRepository;
    private final UserRepository userRepository;
    private final LanguageRepository languageRepository;
    private final HeritageRepository heritageRepository;
    private final FavoriteRepository favoriteRepository;
    private final VisitHistoryRepository visitHistoryRepository;
    private final FeedbackRepository feedbackRepository;
    private final BlePermissionHelper blePermissionHelper;
    private final BleBridgeCoordinator bleBridge;
    private final Tv3BleAdapter tv3BleAdapter;
    private final BleDebugSimulator bleDebugSimulator;

    private final List<Runnable> sessionExpiredListeners = new CopyOnWriteArrayList<>();

    /**
     * @param mockBackend {@code null} de goi backend that tai {@code baseUrl}
     */
    public AppContainer(KeyValueStore store, AppExecutors executors, MockBackendInterceptor mockBackend, String baseUrl) {
        this(store, new InMemoryKeyValueStore(), executors, mockBackend, baseUrl);
    }

    public AppContainer(KeyValueStore sessionStore,
                        KeyValueStore artifactCacheStore,
                        AppExecutors executors,
                        MockBackendInterceptor mockBackend,
                        String baseUrl) {
        this.executors = executors;
        this.sessionStorage = new SessionStorage(sessionStore);
        this.artifactCache = new ArtifactCache(artifactCacheStore);
        this.mockBackend = mockBackend;
        this.apiClient = new ApiClient(baseUrl, sessionStorage, this::dispatchSessionExpired, mockBackend);

        HeritageApiService api = apiClient.service();
        this.authRepository = new AuthRepository(api, sessionStorage);
        this.userRepository = new UserRepository(api, sessionStorage);
        this.languageRepository = new LanguageRepository(api, sessionStorage);
        this.heritageRepository = new HeritageRepository(api, sessionStorage, artifactCache);
        this.favoriteRepository = new FavoriteRepository(api);
        this.visitHistoryRepository = new VisitHistoryRepository(api);
        this.feedbackRepository = new FeedbackRepository(api);
        this.blePermissionHelper = new BlePermissionHelper();
        this.bleBridge = new BleBridgeCoordinator(this.heritageRepository, executors, this.blePermissionHelper);
        this.tv3BleAdapter = new Tv3BleAdapter(this.bleBridge);
        this.bleDebugSimulator = new BleDebugSimulator(this.bleBridge);
    }

    /** Container mac dinh theo {@link AppConfig}. */
    public static AppContainer createDefault() {
        return createForEnvironment(AppConfig.ACTIVE_ENVIRONMENT, AppConfig.BASE_URL);
    }

    /**
     * Khoi tao container cho moi truong cu the ({@link AppConfig.Environment#MOCK}
     * hoac {@link AppConfig.Environment#DEV_BACKEND} cua TV6).
     */
    public static AppContainer createForEnvironment(AppConfig.Environment env, String devBackendUrl) {
        KeyValueStore sessionStore = new FileKeyValueStore(AppConfig.dataDirectory().resolve(AppConfig.SESSION_FILE_NAME));
        KeyValueStore cacheStore = new FileKeyValueStore(AppConfig.dataDirectory().resolve(AppConfig.ARTIFACT_CACHE_FILE_NAME));
        boolean useMock = (env == null || env.isMock());
        MockBackendInterceptor mock = useMock ? new MockBackendInterceptor() : null;
        String baseUrl = AppConfig.effectiveBaseUrl(env, devBackendUrl);
        return new AppContainer(sessionStore, cacheStore, AppExecutors.swing(), mock, baseUrl);
    }

    private void dispatchSessionExpired() {
        for (Runnable r : sessionExpiredListeners) {
            r.run();
        }
    }

    /** Dang ky callback khi phien het han (Navigator dung de quay ve Login). */
    public void addSessionExpiredListener(Runnable listener) {
        sessionExpiredListeners.add(listener);
    }

    public AppExecutors executors() {
        return executors;
    }

    public SessionStorage sessionStorage() {
        return sessionStorage;
    }

    public ArtifactCache artifactCache() {
        return artifactCache;
    }

    /** @return mock backend, hoac {@code null} khi chay backend that. */
    public MockBackendInterceptor mockBackend() {
        return mockBackend;
    }

    public ApiClient apiClient() {
        return apiClient;
    }

    public AuthRepository authRepository() {
        return authRepository;
    }

    public UserRepository userRepository() {
        return userRepository;
    }

    public LanguageRepository languageRepository() {
        return languageRepository;
    }

    public HeritageRepository heritageRepository() {
        return heritageRepository;
    }

    public FavoriteRepository favoriteRepository() {
        return favoriteRepository;
    }

    public VisitHistoryRepository visitHistoryRepository() {
        return visitHistoryRepository;
    }

    public FeedbackRepository feedbackRepository() {
        return feedbackRepository;
    }

    public BlePermissionHelper blePermissionHelper() {
        return blePermissionHelper;
    }

    public BleBridgeCoordinator bleBridge() {
        return bleBridge;
    }

    public Tv3BleAdapter tv3BleAdapter() {
        return tv3BleAdapter;
    }

    public BleDebugSimulator bleDebugSimulator() {
        return bleDebugSimulator;
    }
}
