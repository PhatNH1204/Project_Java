package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

/**
 * Ngon ngu ho tro - khop Entity {@code Language} cua TV1.
 */
public class Language {

    @SerializedName(value = "id", alternate = {"languageId", "language_id"})
    private Long id;

    /** ISO 639-1: vi, en. */
    @SerializedName(value = "code", alternate = {"languageCode", "language_code"})
    private String code;

    /** Ten hien thi bang chinh ngon ngu do (vd: "Tieng Viet", "English"). */
    @SerializedName(value = "name", alternate = {"displayName", "display_name"})
    private String name;

    @SerializedName(value = "active", alternate = {"isActive", "is_active", "enabled"})
    private boolean active = true;

    @SerializedName(value = "isDefault", alternate = {"default", "is_default"})
    private boolean isDefault;

    public Language() {
    }

    public Language(Long id, String code, String name, boolean isDefault) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.isDefault = isDefault;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean aDefault) {
        isDefault = aDefault;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Language)) return false;
        return Objects.equals(code, ((Language) o).code);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code);
    }

    @Override
    public String toString() {
        return name + " (" + code + ")";
    }
}
