package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Tep da phuong tien - khop Entity {@code Media} cua TV4.
 * Ho tro day du schema JSON that (camelCase &amp; snake_case) tu Swagger/OpenAPI.
 */
public class Media {

    @SerializedName(value = "id", alternate = {"mediaId", "media_id"})
    private Long id;

    @SerializedName(value = "mediaType", alternate = {"media_type", "type", "fileType", "file_type"})
    private MediaType mediaType;

    @SerializedName(value = "url", alternate = {"fileUrl", "file_url", "mediaUrl", "media_url", "src"})
    private String url;

    /** Thoi luong (giay) - chi co y nghia voi AUDIO/VIDEO. */
    @SerializedName(value = "duration", alternate = {"durationSeconds", "duration_seconds", "lengthSeconds"})
    private Integer duration;

    /** Ngon ngu cua file (vd: audio guide tieng Viet/Anh); null neu dung chung. */
    @SerializedName(value = "languageCode", alternate = {"language_code", "langCode", "lang_code", "lang"})
    private String languageCode;

    public Media() {
    }

    public Media(Long id, MediaType mediaType, String url, Integer duration, String languageCode) {
        this.id = id;
        this.mediaType = mediaType;
        this.url = url;
        this.duration = duration;
        this.languageCode = languageCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MediaType getMediaType() {
        return mediaType;
    }

    public void setMediaType(MediaType mediaType) {
        this.mediaType = mediaType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
}
