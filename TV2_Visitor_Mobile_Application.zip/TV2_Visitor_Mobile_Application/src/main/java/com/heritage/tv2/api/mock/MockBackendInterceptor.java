package com.heritage.tv2.api.mock;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.ApiResponse;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.Role;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.model.request.LoginRequest;
import com.heritage.tv2.model.request.RefreshTokenRequest;
import com.heritage.tv2.model.request.RegisterRequest;
import com.heritage.tv2.model.request.UpdateProfileRequest;
import com.heritage.tv2.util.JsonProvider;
import com.heritage.tv2.util.Validators;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

/**
 * Backend gia lap chay NGAY TRONG OkHttp (interceptor cuoi chuoi, khong goi mang).
 *
 * <p>Mo phong dung API Contract + format {@link ApiResponse} chuan, bao gom:
 * xac thuc Bearer token, het han/refresh token, ban dia hoa theo {@code Accept-Language},
 * ma loi HTTP (400/401/404/409). Nho vay toan bo stack that (AuthInterceptor, Retrofit, Gson,
 * Repository) duoc chay ngay ca khi chua co backend.</p>
 *
 * <p>Tai khoan demo: {@code visitor@heritage.vn / 123456} (vi) va
 * {@code tourist@heritage.vn / 123456} (en).</p>
 */
public class MockBackendInterceptor implements Interceptor {

    public static final String DEMO_EMAIL = "visitor@heritage.vn";
    public static final String DEMO_EMAIL_EN = "tourist@heritage.vn";
    public static final String DEMO_PASSWORD = "123456";

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final String ACCESS_PREFIX = "mock-at";
    private static final String REFRESH_PREFIX = "mock-rt";

    private static final Pattern SITE_ARTIFACTS_PATH = Pattern.compile("^/api/sites/(\\d+)/artifacts$");
    private static final Pattern ARTIFACT_PATH = Pattern.compile("^/api/artifacts/(\\d+)$");
    private static final Pattern BEACON_PATH = Pattern.compile("^/api/beacons/([^/]+)/content$");
    private static final Pattern FAVORITE_PATH = Pattern.compile("^/api/favorites/(\\d+)$");

    private static final class MockAccount {
        final User user;
        final String password;

        MockAccount(User user, String password) {
            this.user = user;
            this.password = password;
        }
    }

    private static final class FavoriteRecord {
        final long id;
        final String createdAt;

        FavoriteRecord(long id, String createdAt) {
            this.id = id;
            this.createdAt = createdAt;
        }
    }

    private static final class VisitSeed {
        final long id;
        final long artifactId;
        final String visitedAt;
        final int duration;
        final String source;

        VisitSeed(long id, long artifactId, String visitedAt, int duration, String source) {
            this.id = id;
            this.artifactId = artifactId;
            this.visitedAt = visitedAt;
            this.duration = duration;
            this.source = source;
        }
    }

    private final Gson gson = JsonProvider.gson();
    private final long latencyMs;
    private final Map<Long, MockAccount> accounts = new ConcurrentHashMap<>();
    private final Map<Long, Map<Long, FavoriteRecord>> favorites = new ConcurrentHashMap<>();
    private final Map<Long, List<VisitSeed>> visits = new ConcurrentHashMap<>();
    private final List<FeedbackRequest> feedbacks = new CopyOnWriteArrayList<>();
    private final Set<String> revokedRefreshTokens = ConcurrentHashMap.newKeySet();
    private final AtomicLong userIdSeq = new AtomicLong(100);
    private final AtomicLong favoriteIdSeq = new AtomicLong(5000);
    /** Tang gia tri nay de vo hieu hoa moi access token dang luu hanh (demo refresh). */
    private final AtomicInteger tokenGeneration = new AtomicInteger(1);
    private final AtomicInteger refreshCount = new AtomicInteger();
    /** Co gia lap mat ket noi mang (nem IOException) de test Error State &amp; Offline ArtifactCache. */
    private volatile boolean simulateNetworkError;

    public MockBackendInterceptor() {
        this(AppConfig.MOCK_LATENCY_MS);
    }

    public MockBackendInterceptor(long latencyMs) {
        this.latencyMs = latencyMs;
        seed();
    }

    private void seed() {
        User visitor = new User(1L, DEMO_EMAIL, "Nguyễn Văn An", new Role(3L, Role.VISITOR, "Khách tham quan"),
                AppConfig.LANGUAGE_VI);
        visitor.setPhone("0901 234 567");
        visitor.setCreatedAt("2026-10-01T08:00:00Z");
        accounts.put(1L, new MockAccount(visitor, DEMO_PASSWORD));

        User tourist = new User(2L, DEMO_EMAIL_EN, "John Smith", new Role(3L, Role.VISITOR, "Visitor"),
                AppConfig.LANGUAGE_EN);
        tourist.setCreatedAt("2026-11-01T08:00:00Z");
        accounts.put(2L, new MockAccount(tourist, DEMO_PASSWORD));

        Map<Long, FavoriteRecord> favs = new LinkedHashMap<>();
        favs.put(101L, new FavoriteRecord(favoriteIdSeq.incrementAndGet(), "2026-11-15T09:35:00Z"));
        favs.put(103L, new FavoriteRecord(favoriteIdSeq.incrementAndGet(), "2026-11-16T14:10:00Z"));
        favorites.put(1L, favs);

        visits.put(1L, List.of(
                new VisitSeed(9001, 102, "2026-11-17T10:12:00Z", 95, VisitHistory.SOURCE_BEACON_BLE),
                new VisitSeed(9002, 103, "2026-11-16T14:05:00Z", 240, VisitHistory.SOURCE_MANUAL),
                new VisitSeed(9003, 101, "2026-11-15T09:30:00Z", 180, VisitHistory.SOURCE_BEACON_BLE)));
    }

    // ================================================================ Test hooks

    /** Vo hieu hoa moi access token hien co -> request tiep theo se nhan 401 va phai refresh. */
    public void expireAllAccessTokens() {
        tokenGeneration.incrementAndGet();
    }

    public int getRefreshCount() {
        return refreshCount.get();
    }

    public List<FeedbackRequest> getFeedbacks() {
        return List.copyOf(feedbacks);
    }

    /** Bat/tat gia lap loi mang (IOException) cho cac request tiep theo. */
    public void setSimulateNetworkError(boolean simulateNetworkError) {
        this.simulateNetworkError = simulateNetworkError;
    }

    public boolean isSimulateNetworkError() {
        return simulateNetworkError;
    }

    // ================================================================= Routing

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request req = chain.request();
        simulateLatency();
        if (simulateNetworkError) {
            throw new IOException("Simulated network outage (offline mode)");
        }
        String lang = language(req.header("Accept-Language"));
        String path = req.url().encodedPath();
        try {
            return route(req, req.method(), path, lang);
        } catch (JsonParseException e) {
            return error(req, 400, "BAD_REQUEST", msg(lang, "Dữ liệu gửi lên không hợp lệ", "Malformed request body"));
        }
    }

    private Response route(Request req, String method, String path, String lang) throws IOException {
        // ---------- Public ----------
        if ("POST".equals(method)) {
            switch (path) {
                case "/api/auth/login":
                    return login(req, lang);
                case "/api/auth/register":
                    return register(req, lang);
                case "/api/auth/refresh":
                    return refresh(req, lang);
                default:
                    break;
            }
        }

        // ---------- Protected ----------
        Long userId = authenticate(req);
        if (userId == null) {
            return error(req, 401, "AUTH_TOKEN_INVALID",
                    msg(lang, "Phiên đăng nhập không hợp lệ hoặc đã hết hạn", "Invalid or expired access token"));
        }

        if ("POST".equals(method) && "/api/auth/logout".equals(path)) {
            RefreshTokenRequest body = readBody(req, RefreshTokenRequest.class);
            if (body != null && body.getRefreshToken() != null) {
                revokedRefreshTokens.add(body.getRefreshToken());
            }
            return ok(req, 200, null, msg(lang, "Đăng xuất thành công", "Logged out"));
        }
        if ("/api/users/me".equals(path)) {
            if ("GET".equals(method)) {
                return ok(req, 200, accounts.get(userId).user.copy(), "OK");
            }
            if ("PUT".equals(method)) {
                return updateMe(req, userId, lang);
            }
        }
        if ("GET".equals(method) && "/api/sites".equals(path)) {
            return ok(req, 200, MockDataSource.sites(lang), "OK");
        }
        Matcher m = SITE_ARTIFACTS_PATH.matcher(path);
        if ("GET".equals(method) && m.matches()) {
            long siteId = Long.parseLong(m.group(1));
            MockDataSource.SiteSeed siteSeed = MockDataSource.findSite(siteId);
            return siteSeed == null ? notFound(req, lang)
                    : ok(req, 200, MockDataSource.artifactsBySite(siteId, lang), "OK");
        }
        m = ARTIFACT_PATH.matcher(path);
        if ("GET".equals(method) && m.matches()) {
            MockDataSource.ArtifactSeed seed = MockDataSource.findArtifact(Long.parseLong(m.group(1)));
            return seed == null ? notFound(req, lang) : ok(req, 200, MockDataSource.artifactDetail(seed, lang), "OK");
        }
        m = BEACON_PATH.matcher(path);
        if ("GET".equals(method) && m.matches()) {
            String queryLang = req.url().queryParameter("lang");
            String effectiveLang = AppConfig.isSupportedLanguage(queryLang)
                    ? queryLang.trim().toLowerCase(Locale.ROOT) : lang;
            MockDataSource.ArtifactSeed seed = MockDataSource.findArtifactByBeacon(m.group(1));
            return seed == null ? notFound(req, effectiveLang)
                    : ok(req, 200, MockDataSource.artifactDetail(seed, effectiveLang), "OK");
        }
        if ("GET".equals(method) && "/api/favorites".equals(path)) {
            return ok(req, 200, favoritesOf(userId, lang), "OK");
        }
        m = FAVORITE_PATH.matcher(path);
        if (m.matches() && ("POST".equals(method) || "DELETE".equals(method))) {
            return toggleFavorite(req, method, userId, Long.parseLong(m.group(1)), lang);
        }
        if ("GET".equals(method) && "/api/visit-history".equals(path)) {
            return ok(req, 200, visitHistoryOf(userId, lang), "OK");
        }
        if ("POST".equals(method) && "/api/feedback".equals(path)) {
            FeedbackRequest body = readBody(req, FeedbackRequest.class);
            if (body == null || !body.isValid() || MockDataSource.findArtifact(body.getArtifactId()) == null) {
                return error(req, 400, "VALIDATION_ERROR",
                        msg(lang, "Đánh giá phải từ 1 đến 5 sao và hiện vật phải tồn tại",
                                "Rating must be 1-5 and the artifact must exist"));
            }
            feedbacks.add(body);
            return ok(req, 201, null, msg(lang, "Cảm ơn bạn đã góp ý!", "Thank you for your feedback!"));
        }
        return notFound(req, lang);
    }

    // =================================================================== Auth

    private Response login(Request req, String lang) throws IOException {
        LoginRequest body = readBody(req, LoginRequest.class);
        if (body == null || isBlank(body.getEmail()) || isBlank(body.getPassword())) {
            return error(req, 400, "VALIDATION_ERROR",
                    msg(lang, "Vui lòng nhập email và mật khẩu", "Email and password are required"));
        }
        MockAccount account = findByEmail(body.getEmail());
        if (account == null || !account.password.equals(body.getPassword())) {
            return error(req, 401, "AUTH_INVALID_CREDENTIALS",
                    msg(lang, "Email hoặc mật khẩu không đúng", "Incorrect email or password"));
        }
        return ok(req, 200, issueTokens(account.user.getId()), msg(lang, "Đăng nhập thành công", "Login successful"));
    }

    private Response register(Request req, String lang) throws IOException {
        RegisterRequest body = readBody(req, RegisterRequest.class);
        if (body == null || !Validators.isValidEmail(body.getEmail())) {
            return error(req, 400, "VALIDATION_ERROR", msg(lang, "Email không hợp lệ", "Invalid email address"));
        }
        if (!Validators.isValidPassword(body.getPassword())) {
            return error(req, 400, "VALIDATION_ERROR",
                    msg(lang, "Mật khẩu phải có ít nhất 6 ký tự", "Password must be at least 6 characters"));
        }
        if (isBlank(body.getFullName())) {
            return error(req, 400, "VALIDATION_ERROR", msg(lang, "Vui lòng nhập họ tên", "Full name is required"));
        }
        if (findByEmail(body.getEmail()) != null) {
            return error(req, 409, "AUTH_EMAIL_EXISTS", msg(lang, "Email đã được sử dụng", "Email is already registered"));
        }
        long id = userIdSeq.incrementAndGet();
        String preferred = AppConfig.isSupportedLanguage(body.getPreferredLanguage())
                ? body.getPreferredLanguage().toLowerCase(Locale.ROOT) : lang;
        User user = new User(id, body.getEmail().trim().toLowerCase(Locale.ROOT), body.getFullName().trim(),
                new Role(3L, Role.VISITOR, "Visitor"), preferred);
        user.setCreatedAt(Instant.now().toString());
        accounts.put(id, new MockAccount(user, body.getPassword()));
        return ok(req, 201, issueTokens(id), msg(lang, "Đăng ký thành công", "Registration successful"));
    }

    private Response refresh(Request req, String lang) throws IOException {
        RefreshTokenRequest body = readBody(req, RefreshTokenRequest.class);
        String token = body == null ? null : body.getRefreshToken();
        Long userId = parseRefreshToken(token);
        if (userId == null || revokedRefreshTokens.contains(token) || !accounts.containsKey(userId)) {
            return error(req, 401, "AUTH_REFRESH_INVALID",
                    msg(lang, "Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại", "Session expired, please log in again"));
        }
        revokedRefreshTokens.add(token); // xoay vong refresh token
        refreshCount.incrementAndGet();
        return ok(req, 200, issueTokens(userId), "OK");
    }

    private Response updateMe(Request req, long userId, String lang) throws IOException {
        UpdateProfileRequest body = readBody(req, UpdateProfileRequest.class);
        if (body == null) {
            return error(req, 400, "VALIDATION_ERROR", msg(lang, "Thiếu dữ liệu cập nhật", "Missing body"));
        }
        if (body.getPreferredLanguage() != null && !AppConfig.isSupportedLanguage(body.getPreferredLanguage())) {
            return error(req, 400, "LANGUAGE_NOT_SUPPORTED",
                    msg(lang, "Ngôn ngữ không được hỗ trợ", "Language is not supported"));
        }
        if (body.getFullName() != null && body.getFullName().isBlank()) {
            return error(req, 400, "VALIDATION_ERROR", msg(lang, "Họ tên không được để trống", "Full name must not be blank"));
        }
        User user = accounts.get(userId).user;
        synchronized (user) {
            if (body.getFullName() != null) user.setFullName(body.getFullName().trim());
            if (body.getPhone() != null) user.setPhone(body.getPhone().trim());
            if (body.getAvatarUrl() != null) user.setAvatarUrl(body.getAvatarUrl());
            if (body.getPreferredLanguage() != null) {
                user.setPreferredLanguage(body.getPreferredLanguage().toLowerCase(Locale.ROOT));
            }
        }
        return ok(req, 200, user.copy(), msg(lang, "Cập nhật hồ sơ thành công", "Profile updated"));
    }

    private AuthTokens issueTokens(long userId) {
        long now = System.currentTimeMillis();
        String access = String.join(".", ACCESS_PREFIX, String.valueOf(userId), String.valueOf(tokenGeneration.get()),
                String.valueOf(now + AppConfig.MOCK_ACCESS_TOKEN_TTL_SECONDS * 1000), nonce());
        String refresh = String.join(".", REFRESH_PREFIX, String.valueOf(userId),
                String.valueOf(now + AppConfig.MOCK_REFRESH_TOKEN_TTL_SECONDS * 1000), nonce());
        return new AuthTokens(access, refresh, AppConfig.MOCK_ACCESS_TOKEN_TTL_SECONDS);
    }

    /** @return userId neu Bearer token hop le, nguoc lai null. */
    private Long authenticate(Request req) {
        String header = req.header("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            return null;
        }
        String[] parts = header.substring(7).trim().split("\\.");
        if (parts.length != 5 || !ACCESS_PREFIX.equals(parts[0])) {
            return null;
        }
        try {
            long userId = Long.parseLong(parts[1]);
            int generation = Integer.parseInt(parts[2]);
            long expiresAt = Long.parseLong(parts[3]);
            if (generation != tokenGeneration.get() || System.currentTimeMillis() > expiresAt
                    || !accounts.containsKey(userId)) {
                return null;
            }
            return userId;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Long parseRefreshToken(String token) {
        if (token == null) {
            return null;
        }
        String[] parts = token.split("\\.");
        if (parts.length != 4 || !REFRESH_PREFIX.equals(parts[0])) {
            return null;
        }
        try {
            long userId = Long.parseLong(parts[1]);
            long expiresAt = Long.parseLong(parts[2]);
            return System.currentTimeMillis() > expiresAt ? null : userId;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private MockAccount findByEmail(String email) {
        String normalized = email.trim().toLowerCase(Locale.ROOT);
        return accounts.values().stream()
                .filter(a -> a.user.getEmail().equalsIgnoreCase(normalized))
                .findFirst().orElse(null);
    }

    // ============================================================= Favorites

    private List<Favorite> favoritesOf(long userId, String lang) {
        Map<Long, FavoriteRecord> favs = favorites.getOrDefault(userId, Map.of());
        List<Favorite> list = new ArrayList<>();
        synchronized (favs) {
            favs.forEach((artifactId, rec) -> {
                MockDataSource.ArtifactSeed seed = MockDataSource.findArtifact(artifactId);
                if (seed != null) {
                    list.add(new Favorite(rec.id, userId, artifactId, MockDataSource.artifactSummary(seed, lang), rec.createdAt));
                }
            });
        }
        return list;
    }

    private Response toggleFavorite(Request req, String method, long userId, long artifactId, String lang) {
        MockDataSource.ArtifactSeed seed = MockDataSource.findArtifact(artifactId);
        if (seed == null) {
            return notFound(req, lang);
        }
        Map<Long, FavoriteRecord> favs = favorites.computeIfAbsent(userId, k -> new LinkedHashMap<>());
        synchronized (favs) {
            if ("DELETE".equals(method)) {
                favs.remove(artifactId);
                return ok(req, 200, null, msg(lang, "Đã bỏ yêu thích", "Removed from favorites"));
            }
            FavoriteRecord existing = favs.get(artifactId);
            boolean created = existing == null;
            FavoriteRecord rec = created
                    ? new FavoriteRecord(favoriteIdSeq.incrementAndGet(), Instant.now().toString()) : existing;
            favs.put(artifactId, rec);
            Favorite fav = new Favorite(rec.id, userId, artifactId, MockDataSource.artifactSummary(seed, lang), rec.createdAt);
            return ok(req, created ? 201 : 200, fav, msg(lang, "Đã thêm vào yêu thích", "Added to favorites"));
        }
    }

    private List<VisitHistory> visitHistoryOf(long userId, String lang) {
        List<VisitHistory> list = new ArrayList<>();
        for (VisitSeed v : visits.getOrDefault(userId, List.of())) {
            MockDataSource.ArtifactSeed a = MockDataSource.findArtifact(v.artifactId);
            MockDataSource.SiteSeed s = a == null ? null : MockDataSource.findSite(a.siteId);
            if (a != null && s != null) {
                list.add(new VisitHistory(v.id, userId, s.id, a.id, a.name.in(lang),
                        s.name.in(lang), v.visitedAt, v.duration, v.source));
            }
        }
        return list;
    }

    // =============================================================== Helpers

    private <T> T readBody(Request req, Class<T> type) throws IOException {
        if (req.body() == null) {
            return null;
        }
        Buffer buffer = new Buffer();
        req.body().writeTo(buffer);
        String json = buffer.readUtf8();
        return json.isBlank() ? null : gson.fromJson(json, type);
    }

    private Response ok(Request req, int code, Object data, String message) {
        return respond(req, code, ApiResponse.ok(data, message));
    }

    private Response error(Request req, int code, String errorCode, String message) {
        return respond(req, code, ApiResponse.fail(code, errorCode, message, req.url().encodedPath()));
    }

    private Response notFound(Request req, String lang) {
        return error(req, 404, "NOT_FOUND", msg(lang, "Không tìm thấy tài nguyên", "Resource not found"));
    }

    private Response respond(Request req, int code, ApiResponse<?> body) {
        return new Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(code)
                .message(reason(code))
                .header("Content-Type", JSON.toString())
                .header("X-Mock-Backend", "true")
                .body(ResponseBody.create(gson.toJson(body), JSON))
                .build();
    }

    private static String reason(int code) {
        switch (code) {
            case 200: return "OK";
            case 201: return "Created";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 404: return "Not Found";
            case 409: return "Conflict";
            default: return "HTTP " + code;
        }
    }

    private static String language(String acceptLanguage) {
        if (acceptLanguage == null || acceptLanguage.isBlank()) {
            return AppConfig.DEFAULT_LANGUAGE;
        }
        String first = acceptLanguage.split(",")[0].trim().toLowerCase(Locale.ROOT);
        String code = first.length() >= 2 ? first.substring(0, 2) : first;
        return AppConfig.isSupportedLanguage(code) ? code : AppConfig.DEFAULT_LANGUAGE;
    }

    private static String msg(String lang, String vi, String en) {
        return AppConfig.LANGUAGE_EN.equals(lang) ? en : vi;
    }

    private static String nonce() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 12);
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    private void simulateLatency() {
        if (latencyMs <= 0) {
            return;
        }
        try {
            Thread.sleep(latencyMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
