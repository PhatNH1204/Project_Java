package com.heritage.tv2.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.LongSupplier;

/**
 * Cache trong bo nho co TTL - dung cho du lieu noi dung (sites, artifacts) theo ngon ngu.
 * Khoa thuong gom ngon ngu, vd: {@code "sites:vi"}.
 */
public class MemoryCache<K, V> {

    private static final class Entry<V> {
        final V value;
        final long expiresAt;

        Entry(V value, long expiresAt) {
            this.value = value;
            this.expiresAt = expiresAt;
        }
    }

    private final Map<K, Entry<V>> map = new ConcurrentHashMap<>();
    private final long ttlMillis;
    private final LongSupplier clock;

    public MemoryCache(long ttlMillis) {
        this(ttlMillis, System::currentTimeMillis);
    }

    public MemoryCache(long ttlMillis, LongSupplier clock) {
        this.ttlMillis = ttlMillis;
        this.clock = clock;
    }

    public V get(K key) {
        Entry<V> e = map.get(key);
        if (e == null) {
            return null;
        }
        if (clock.getAsLong() > e.expiresAt) {
            map.remove(key);
            return null;
        }
        return e.value;
    }

    public void put(K key, V value) {
        map.put(key, new Entry<>(value, clock.getAsLong() + ttlMillis));
    }

    public void invalidate(K key) {
        map.remove(key);
    }

    public void clear() {
        map.clear();
    }
}
