package com.heritage.tv2.ui.splash;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.theme.UiTheme;
import com.heritage.tv2.util.I18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.border.EmptyBorder;

/**
 * Man hinh Splash khoi dong: hien thi thuong hieu Heritage Guide va trang thai khoi phuc phien.
 */
public class SplashScreen extends Screen {

    private final SplashViewModel viewModel;
    private final Navigator navigator;

    public SplashScreen(SplashViewModel viewModel, Navigator navigator) {
        this.viewModel = viewModel;
        this.navigator = navigator;
        buildUi();
    }

    private void buildUi() {
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(UiTheme.PRIMARY_DARK);
        center.setBorder(new EmptyBorder(180, 32, 120, 32));

        JLabel emblem = new JLabel("🏛", JLabel.CENTER);
        emblem.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 56));
        emblem.setForeground(UiTheme.ACCENT_GOLD);
        emblem.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel(AppConfig.APP_NAME, JLabel.CENTER);
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel(I18n.tr("app.subtitle"), JLabel.CENTER);
        sub.setFont(UiTheme.FONT_BODY);
        sub.setForeground(UiTheme.ACCENT_SOFT);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JProgressBar progress = new JProgressBar();
        progress.setIndeterminate(true);
        progress.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel checking = new JLabel(I18n.tr("splash.checking"), JLabel.CENTER);
        checking.setFont(UiTheme.FONT_SMALL);
        checking.setForeground(UiTheme.ACCENT_GOLD);
        checking.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(emblem);
        center.add(Box.createVerticalStrut(14));
        center.add(title);
        center.add(Box.createVerticalStrut(6));
        center.add(sub);
        center.add(Box.createVerticalStrut(42));
        center.add(progress);
        center.add(Box.createVerticalStrut(10));
        center.add(checking);

        add(center);
    }

    @Override
    public void onShow() {
        observe(viewModel.nextRoute(), event -> {
            Navigator.Route target = event.getIfNotHandled();
            if (target != null) {
                navigator.navigateTo(target);
            }
        });
        viewModel.checkSession();
    }
}
