package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.cache.ArtifactCache;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.cache.MemoryCache;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.util.Result;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Noi dung di san (TV4): sites, artifacts, noi dung theo beacon.
 *
 * <ul>
 *     <li>Cache danh sach {@link HeritageSite} theo ngon ngu ({@code sites:<lang>}).</li>
 *     <li>Ngay khi tai {@link Artifact} thanh cong tu {@code GET /api/artifacts/{id}} hoac
 *     {@code GET /api/beacons/{id}/content}, luu ban sao day du ({@code Artifact} + {@code ContentTranslation}
 *     + {@code Media}) vao {@link ArtifactCache} de san sang xem tiep khi mat mang hoac mat song beacon.</li>
 *     <li>Ho tro tim kiem theo ten/khu vuc (khong phan biet hoa thuong &amp; dau tieng Viet) va loc theo danh muc.</li>
 * </ul>
 */
public class HeritageRepository {

    private static final long CACHE_TTL_MS = 5 * 60 * 1000L;

    private final HeritageApiService api;
    private final SessionStorage session;
    private final ArtifactCache artifactCache;
    private final MemoryCache<String, List<HeritageSite>> siteCache = new MemoryCache<>(CACHE_TTL_MS);
    private volatile boolean lastArtifactFromOfflineCache;

    public HeritageRepository(HeritageApiService api, SessionStorage session) {
        this(api, session, new ArtifactCache(new InMemoryKeyValueStore()));
    }

    public HeritageRepository(HeritageApiService api, SessionStorage session, ArtifactCache artifactCache) {
        this.api = api;
        this.session = session;
        this.artifactCache = artifactCache;
    }

    public ArtifactCache artifactCache() {
        return artifactCache;
    }

    public boolean isLastArtifactFromOfflineCache() {
        return lastArtifactFromOfflineCache;
    }

    public Result<List<HeritageSite>> getSites(boolean forceRefresh) {
        String key = "sites:" + session.getLanguage();
        List<HeritageSite> cached = forceRefresh ? null : siteCache.get(key);
        if (cached != null) {
            return Result.success(cached);
        }
        Result<List<HeritageSite>> result = ApiCaller.execute(api.getSites());
        if (result.isSuccess() && result.getData() != null) {
            siteCache.put(key, result.getData());
        }
        return result;
    }

    public Result<List<Artifact>> getSiteArtifacts(long siteId) {
        Result<List<Artifact>> res = ApiCaller.execute(api.getSiteArtifacts(siteId));
        if (res.isSuccess() && res.getData() != null) {
            return res;
        }
        // Fallback tu danh sach site da cache neu dang mat mang
        List<HeritageSite> cachedSites = siteCache.get("sites:" + session.getLanguage());
        if (cachedSites != null) {
            for (HeritageSite s : cachedSites) {
                if (s.getId() != null && s.getId() == siteId && s.getArtifacts() != null) {
                    return Result.success(s.getArtifacts());
                }
            }
        }
        return res;
    }

    /**
     * Lay chi tiet hien vat tu {@code GET /api/artifacts/{id}}.
     * <ul>
     *     <li>Thanh cong: luu ngay ban sao vao {@link ArtifactCache}.</li>
     *     <li>Loi mang / offline: doc ban sao tu {@link ArtifactCache} (neu da tung tai truoc do).</li>
     * </ul>
     */
    public Result<Artifact> getArtifact(long artifactId) {
        Result<Artifact> result = ApiCaller.execute(api.getArtifact(artifactId));
        if (result.isSuccess() && result.getData() != null) {
            lastArtifactFromOfflineCache = false;
            artifactCache.save(result.getData());
            return result;
        }
        Artifact offlineCopy = artifactCache.getLocalized(
                artifactId, session.getLanguage(), AppConfig.DEFAULT_LANGUAGE);
        if (offlineCopy != null) {
            lastArtifactFromOfflineCache = true;
            return Result.success(offlineCopy);
        }
        lastArtifactFromOfflineCache = false;
        return result;
    }

    /**
     * Noi dung hien vat gan voi beacon: {@code GET /api/beacons/{id}/content?lang={lang}}.
     * Ngay khi tai thanh cong, luu vao {@link ArtifactCache}; neu mat song/mat mang thi doc tu {@link ArtifactCache}.
     */
    public Result<Artifact> getBeaconContent(String beaconId) {
        String lang = session.getLanguage();
        Result<Artifact> result = ApiCaller.execute(api.getBeaconContent(beaconId, lang));
        if (result.isSuccess() && result.getData() != null) {
            lastArtifactFromOfflineCache = false;
            artifactCache.saveBeaconMapping(beaconId, result.getData());
            return result;
        }
        Artifact cached = artifactCache.getByBeaconLocalized(beaconId, lang, AppConfig.DEFAULT_LANGUAGE);
        if (cached != null) {
            lastArtifactFromOfflineCache = true;
            return Result.success(cached);
        }
        lastArtifactFromOfflineCache = false;
        return result;
    }

    /**
     * Tim kiem dia diem theo ten / khu vuc / dia chi va loc theo danh muc ({@code ALL}, {@code CITADEL}, {@code TEMPLE}, {@code MUSEUM}).
     */
    public List<HeritageSite> filterSites(List<HeritageSite> sites, String searchQuery, String category) {
        if (sites == null || sites.isEmpty()) {
            return List.of();
        }
        String normQuery = normalizeForSearch(searchQuery);
        boolean filterCat = category != null && !category.isBlank()
                && !HeritageSite.CATEGORY_ALL.equalsIgnoreCase(category.trim());

        List<HeritageSite> filtered = new ArrayList<>();
        for (HeritageSite site : sites) {
            if (filterCat && (site.getCategory() == null || !site.getCategory().equalsIgnoreCase(category.trim()))) {
                continue;
            }
            if (!normQuery.isEmpty()) {
                String haystack = normalizeForSearch(
                        (site.getName() == null ? "" : site.getName()) + " "
                        + (site.getRegion() == null ? "" : site.getRegion()) + " "
                        + (site.getAddress() == null ? "" : site.getAddress()) + " "
                        + (site.getCode() == null ? "" : site.getCode()));
                if (!haystack.contains(normQuery)) {
                    continue;
                }
            }
            filtered.add(site);
        }
        return filtered;
    }

    private static String normalizeForSearch(String input) {
        if (input == null || input.isBlank()) {
            return "";
        }
        String lower = input.trim().toLowerCase(Locale.ROOT)
                .replace('đ', 'd')
                .replace('Đ', 'd');
        String decomposed = Normalizer.normalize(lower, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    public void clearCache() {
        siteCache.clear();
    }
}
