package com.heritage.tv2.model;

/** Loai media - khop enum {@code mediaType} cua TV4. */
public enum MediaType {
    IMAGE,
    AUDIO,
    VIDEO
}
