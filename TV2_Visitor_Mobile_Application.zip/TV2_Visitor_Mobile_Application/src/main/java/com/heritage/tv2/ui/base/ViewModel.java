package com.heritage.tv2.ui.base;

import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.Result;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * ViewModel co so (tuong duong {@code androidx.lifecycle.ViewModel}).
 * Song theo back-stack entry cua Navigator -> ton tai qua viec tao lai Screen (doi ngon ngu).
 */
public abstract class ViewModel {

    protected final AppExecutors executors;
    private volatile boolean cleared;

    protected ViewModel(AppExecutors executors) {
        this.executors = executors;
    }

    /** Chay {@code work} tren IO, tra ket qua ve main thread (bo qua neu VM da bi huy). */
    protected <T> void launch(Supplier<Result<T>> work, Consumer<Result<T>> onResult) {
        executors.io().execute(() -> {
            Result<T> result;
            try {
                result = work.get();
            } catch (RuntimeException e) {
                result = Result.error(Result.CODE_UNKNOWN, e.getMessage(), 0);
            }
            Result<T> finalResult = result;
            executors.main().execute(() -> {
                if (!cleared) {
                    onResult.accept(finalResult);
                }
            });
        });
    }

    public final void clear() {
        cleared = true;
        onCleared();
    }

    public boolean isCleared() {
        return cleared;
    }

    protected void onCleared() {
    }
}
