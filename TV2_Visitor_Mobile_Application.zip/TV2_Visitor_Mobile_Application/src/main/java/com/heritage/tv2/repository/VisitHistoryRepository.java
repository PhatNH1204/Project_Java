package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.util.Result;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Repository quan ly Lich su tham quan ({@link VisitHistory} - Gate 3 Phan 2).
 *
 * <ul>
 *     <li>Tach biet nguon du lieu qua {@link VisitHistoryDataSource} de de dang chuyen doi giua
 *     API tong hop tu {@code Interaction} cua TV3 ({@link SourceMode#INTERACTION_AGGREGATED})
 *     hoac bang {@code VisitHistory} doc lap ({@link SourceMode#STANDALONE_TABLE}) sau khi nhom chot.</li>
 *     <li>Luon sap xep danh sach theo thoi gian gan nhat ({@code visitedAt} giam dan).</li>
 *     <li>Gan nhan phan biet nguon mo: {@link VisitHistory#SOURCE_MANUAL} (Thu cong) hay
 *     {@link VisitHistory#SOURCE_BEACON_BLE} (Tu Beacon BLE).</li>
 * </ul>
 */
public class VisitHistoryRepository {

    public enum SourceMode {
        /** Doc qua GET /api/visit-history (tong hop tu Interaction cua TV3) ket hop luot xem trong phien. */
        INTERACTION_AGGREGATED,
        /** Bang VisitHistory doc lap. */
        STANDALONE_TABLE
    }

    private final HeritageApiService api;
    private final Map<Long, VisitHistory> recentSessionVisits = new LinkedHashMap<>();
    private final AtomicLong localVisitIdSeq = new AtomicLong(99000L);
    private volatile SourceMode sourceMode = SourceMode.INTERACTION_AGGREGATED;
    private volatile VisitHistoryDataSource dataSource;

    public VisitHistoryRepository(HeritageApiService api) {
        this.api = api;
        this.dataSource = createDataSource(SourceMode.INTERACTION_AGGREGATED);
    }

    public SourceMode getSourceMode() {
        return sourceMode;
    }

    /** Doi chien luoc nguon du lieu ma khong anh huong ViewModel hay UI. */
    public void setSourceMode(SourceMode mode) {
        this.sourceMode = mode == null ? SourceMode.INTERACTION_AGGREGATED : mode;
        this.dataSource = createDataSource(this.sourceMode);
    }

    /** Cho phep inject bat ky VisitHistoryDataSource tuy chinh nao (phuc vu test / mo rong). */
    public void setDataSource(VisitHistoryDataSource customDataSource) {
        if (customDataSource == null) {
            throw new IllegalArgumentException("customDataSource must not be null");
        }
        this.dataSource = customDataSource;
    }

    /**
     * Lay danh sach lich su tham quan da sap xep theo thoi gian gan nhat (newest first).
     */
    public Result<List<VisitHistory>> getVisitHistory() {
        Result<List<VisitHistory>> res = dataSource.fetchHistory();
        if (!res.isSuccess() || res.getData() == null) {
            return res;
        }
        List<VisitHistory> sorted = new ArrayList<>(res.getData());
        sorted.sort(Comparator.comparing(
                (VisitHistory v) -> v.getVisitedAt() == null ? "" : v.getVisitedAt())
                .reversed());
        return Result.success(sorted);
    }

    /**
     * Ghi nhan nguoi dung vua mo xem chi tiet mot hien vat (Thu cong hoac tu Beacon BLE).
     */
    public void recordArtifactView(Artifact artifact, String siteName, String source) {
        dataSource.recordVisit(artifact, siteName, source);
    }

    public synchronized void clearSessionVisits() {
        recentSessionVisits.clear();
    }

    private VisitHistoryDataSource createDataSource(SourceMode mode) {
        if (mode == SourceMode.STANDALONE_TABLE) {
            return new StandaloneVisitHistoryDataSource();
        }
        return new InteractionAggregatedDataSource();
    }

    private synchronized void putSessionVisit(Artifact artifact, String siteName, String source) {
        if (artifact == null || artifact.getId() == null) {
            return;
        }
        String src = (source == null || source.isBlank()) ? VisitHistory.SOURCE_MANUAL : source;
        VisitHistory vh = new VisitHistory(
                localVisitIdSeq.incrementAndGet(),
                1L,
                artifact.getSiteId(),
                artifact.getId(),
                artifact.getName(),
                siteName != null ? siteName : "",
                Instant.now().toString(),
                45,
                src);
        recentSessionVisits.put(artifact.getId(), vh);
    }

    /**
     * Chien luoc A (Mac dinh): Doc tu GET /api/visit-history (do TV3 tong hop tu Interaction)
     * va cap nhat nhan nguon mo trong phien.
     */
    private final class InteractionAggregatedDataSource implements VisitHistoryDataSource {
        @Override
        public Result<List<VisitHistory>> fetchHistory() {
            Result<List<VisitHistory>> apiRes = ApiCaller.execute(api.getVisitHistory());
            if (!apiRes.isSuccess() || apiRes.getData() == null) {
                return apiRes;
            }
            Map<Long, VisitHistory> merged = new LinkedHashMap<>();
            synchronized (VisitHistoryRepository.this) {
                for (VisitHistory local : recentSessionVisits.values()) {
                    merged.put(local.getArtifactId(), local);
                }
            }
            for (VisitHistory remote : apiRes.getData()) {
                merged.putIfAbsent(remote.getArtifactId(), remote);
            }
            return Result.success(new ArrayList<>(merged.values()));
        }

        @Override
        public void recordVisit(Artifact artifact, String siteName, String source) {
            putSessionVisit(artifact, siteName, source);
        }
    }

    /**
     * Chien luoc B: Bang VisitHistory doc lap (co the doi sang ngay khi nhom chot).
     */
    private final class StandaloneVisitHistoryDataSource implements VisitHistoryDataSource {
        @Override
        public Result<List<VisitHistory>> fetchHistory() {
            Result<List<VisitHistory>> apiRes = ApiCaller.execute(api.getVisitHistory());
            List<VisitHistory> combined = new ArrayList<>();
            synchronized (VisitHistoryRepository.this) {
                combined.addAll(recentSessionVisits.values());
            }
            if (apiRes.isSuccess() && apiRes.getData() != null) {
                for (VisitHistory remote : apiRes.getData()) {
                    boolean exists = combined.stream()
                            .anyMatch(v -> v.getArtifactId() != null && v.getArtifactId().equals(remote.getArtifactId()));
                    if (!exists) {
                        combined.add(remote);
                    }
                }
                return Result.success(combined);
            }
            return combined.isEmpty() ? apiRes : Result.success(combined);
        }

        @Override
        public void recordVisit(Artifact artifact, String siteName, String source) {
            putSessionVisit(artifact, siteName, source);
        }
    }
}
