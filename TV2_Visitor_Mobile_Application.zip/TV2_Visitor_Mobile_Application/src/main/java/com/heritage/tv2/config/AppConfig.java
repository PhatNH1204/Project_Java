package com.heritage.tv2.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/**
 * Cau hinh toan cuc cua ung dung TV2 (Visitor Mobile Application - Tich hop Tuan 5-6).
 *
 * <p>Ho tro chuyen doi linh hoat giua 2 moi truong {@link Environment#MOCK} ({@code mock})
 * va {@link Environment#DEV_BACKEND} ({@code dev-backend} - Docker/server cua TV6) theo thu tu uu tien:</p>
 * <ol>
 *     <li>JVM System Properties: {@code -Dtv2.env=dev-backend}, {@code -Dtv2.mock=false}, {@code -Dtv2.baseUrl=http://...}</li>
 *     <li>Bien moi truong HDH (OS Env): {@code TV2_ENV=dev-backend}, {@code TV2_USE_MOCK=false}, {@code TV2_BACKEND_URL=http://...}</li>
 *     <li>File cau hinh ngoai {@code -Dtv2.config=/path/to/tv2-config.properties} hoac {@code ~/.heritage-tv2/tv2-config.properties}</li>
 *     <li>File cau hinh mac dinh trong classpath: {@code /application.properties}</li>
 * </ol>
 */
public final class AppConfig {

    /** Moi truong van hanh cua ung dung TV2. */
    public enum Environment {
        /** Chay voi MockBackendInterceptor + MockDataSource da ngon ngu (vi/en). */
        MOCK("mock"),
        /** Ket noi Backend that (Docker / Server cua TV6). */
        DEV_BACKEND("dev-backend");

        private final String code;

        Environment(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }

        public boolean isMock() {
            return this == MOCK;
        }

        public static Environment fromString(String raw) {
            if (raw == null || raw.isBlank()) {
                return null;
            }
            String norm = raw.trim().toLowerCase(Locale.ROOT);
            if ("dev-backend".equals(norm) || "dev_backend".equals(norm)
                    || "dev".equals(norm) || "docker".equals(norm)
                    || "prod".equals(norm) || "live".equals(norm)) {
                return DEV_BACKEND;
            }
            if ("mock".equals(norm) || "local-mock".equals(norm)) {
                return MOCK;
            }
            return null;
        }
    }

    public static final String DEFAULT_DEV_BACKEND_URL = "http://localhost:8080/";
    public static final String MOCK_BASE_URL = "http://mock.heritage.local/";

    private static final Properties FILE_PROPERTIES = loadFileProperties();

    /** Moi truong hien tai duoc phan giai tu System Property / Env / Config file. */
    public static final Environment ACTIVE_ENVIRONMENT =
            resolveEnvironment(FILE_PROPERTIES, System.getenv(), System.getProperties());

    /**
     * Bat/tat che do du lieu gia lap ({@code true} khi {@code ACTIVE_ENVIRONMENT == MOCK}).
     */
    public static final boolean USE_MOCK_DATA = ACTIVE_ENVIRONMENT.isMock();

    /** Tuong duong BuildConfig.DEBUG ben Android. */
    public static final boolean DEBUG =
            Boolean.parseBoolean(System.getProperty("tv2.debug", "true"));

    /** Co bat cong cu BLE Debug Simulator (Gate 4 - phoi hop TV3 &amp; TV6). */
    public static final boolean ENABLE_BLE_SIMULATOR =
            Boolean.parseBoolean(resolveValue("tv2.bleSim", "TV2_BLE_SIM", "true",
                    FILE_PROPERTIES, System.getenv(), System.getProperties()));

    /** Base URL backend that (Docker / Spring Boot cua TV1/TV4/TV6). */
    public static final String BASE_URL =
            resolveBaseUrl(FILE_PROPERTIES, System.getenv(), System.getProperties());

    private AppConfig() {
    }

    public static String effectiveBaseUrl() {
        return effectiveBaseUrl(ACTIVE_ENVIRONMENT, BASE_URL);
    }

    public static String effectiveBaseUrl(Environment env, String devBackendUrl) {
        return (env == null || env.isMock()) ? MOCK_BASE_URL : ensureTrailingSlash(devBackendUrl);
    }

    /**
     * Phan giai moi truong ({@code mock} vs {@code dev-backend}) tu cac nguon cau hinh.
     */
    public static Environment resolveEnvironment(Properties fileProps,
                                                 Map<String, String> envVars,
                                                 Properties sysProps) {
        // 1. System properties: -Dtv2.env=... hoac -Dtv2.mock=...
        if (sysProps != null) {
            Environment fromSysEnv = Environment.fromString(sysProps.getProperty("tv2.env"));
            if (fromSysEnv != null) {
                return fromSysEnv;
            }
            String sysMock = sysProps.getProperty("tv2.mock");
            if (sysMock != null && !sysMock.isBlank()) {
                return Boolean.parseBoolean(sysMock.trim()) ? Environment.MOCK : Environment.DEV_BACKEND;
            }
        }
        // 2. OS Environment variables: TV2_ENV=... hoac TV2_USE_MOCK=...
        if (envVars != null) {
            Environment fromOsEnv = Environment.fromString(envVars.get("TV2_ENV"));
            if (fromOsEnv != null) {
                return fromOsEnv;
            }
            String osMock = envVars.get("TV2_USE_MOCK");
            if (osMock != null && !osMock.isBlank()) {
                return Boolean.parseBoolean(osMock.trim()) ? Environment.MOCK : Environment.DEV_BACKEND;
            }
        }
        // 3. Config file: tv2.env=... hoac tv2.mock=...
        if (fileProps != null) {
            Environment fromFileEnv = Environment.fromString(fileProps.getProperty("tv2.env"));
            if (fromFileEnv != null) {
                return fromFileEnv;
            }
            String fileMock = fileProps.getProperty("tv2.mock");
            if (fileMock != null && !fileMock.isBlank()) {
                return Boolean.parseBoolean(fileMock.trim()) ? Environment.MOCK : Environment.DEV_BACKEND;
            }
        }
        return Environment.MOCK;
    }

    /**
     * Phan giai Base URL cua Backend TV6 (luon dam bao dau '/' o cuoi cho Retrofit2).
     */
    public static String resolveBaseUrl(Properties fileProps,
                                        Map<String, String> envVars,
                                        Properties sysProps) {
        String raw = resolveValue("tv2.baseUrl", "TV2_BACKEND_URL", DEFAULT_DEV_BACKEND_URL,
                fileProps, envVars, sysProps);
        return ensureTrailingSlash(raw);
    }

    private static String resolveValue(String propKey,
                                       String envKey,
                                       String defaultValue,
                                       Properties fileProps,
                                       Map<String, String> envVars,
                                       Properties sysProps) {
        if (sysProps != null) {
            String v = sysProps.getProperty(propKey);
            if (v != null && !v.isBlank()) {
                return v.trim();
            }
        }
        if (envVars != null && envKey != null) {
            String v = envVars.get(envKey);
            if (v != null && !v.isBlank()) {
                return v.trim();
            }
        }
        if (fileProps != null) {
            String v = fileProps.getProperty(propKey);
            if (v != null && !v.isBlank()) {
                return v.trim();
            }
        }
        return defaultValue;
    }

    public static String ensureTrailingSlash(String url) {
        if (url == null || url.isBlank()) {
            return DEFAULT_DEV_BACKEND_URL;
        }
        String trimmed = url.trim();
        return trimmed.endsWith("/") ? trimmed : (trimmed + "/");
    }

    private static Properties loadFileProperties() {
        Properties props = new Properties();
        // 1. Classpath /application.properties
        try (InputStream in = AppConfig.class.getResourceAsStream("/application.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException ignored) {
        }
        // 2. External file (~/.heritage-tv2/tv2-config.properties hoac -Dtv2.config=...)
        String customPath = System.getProperty("tv2.config");
        Path externalFile = (customPath != null && !customPath.isBlank())
                ? Paths.get(customPath)
                : dataDirectory().resolve("tv2-config.properties");
        if (Files.isRegularFile(externalFile)) {
            try (Reader reader = Files.newBufferedReader(externalFile, StandardCharsets.UTF_8)) {
                props.load(reader);
            } catch (IOException ignored) {
            }
        }
        return props;
    }

    // ---------------------------------------------------------------- Network
    public static final int CONNECT_TIMEOUT_SECONDS = 15;
    public static final int READ_TIMEOUT_SECONDS = 20;
    public static final int WRITE_TIMEOUT_SECONDS = 20;
    /** Bat log HTTP (BASIC) - ghi de bang {@code -Dtv2.httpLog=true}. */
    public static final boolean HTTP_LOGGING =
            Boolean.parseBoolean(resolveValue("tv2.httpLog", "TV2_HTTP_LOG", "false",
                    FILE_PROPERTIES, System.getenv(), System.getProperties()));

    // ----------------------------------------------------------- Mock backend
    public static final long MOCK_LATENCY_MS = Long.getLong("tv2.mockLatency", 350L);
    public static final long MOCK_ACCESS_TOKEN_TTL_SECONDS = Long.getLong("tv2.mockAccessTtl", 300L);
    public static final long MOCK_REFRESH_TOKEN_TTL_SECONDS = 7L * 24 * 3600;

    // ------------------------------------------------------------- Language
    public static final String LANGUAGE_VI = "vi";
    public static final String LANGUAGE_EN = "en";
    public static final String DEFAULT_LANGUAGE = LANGUAGE_VI;
    public static final List<String> SUPPORTED_LANGUAGES = List.of(LANGUAGE_VI, LANGUAGE_EN);

    public static boolean isSupportedLanguage(String code) {
        return code != null && SUPPORTED_LANGUAGES.contains(code.trim().toLowerCase());
    }

    // --------------------------------------------------------------- Storage
    public static Path dataDirectory() {
        String custom = System.getProperty("tv2.dataDir");
        if (custom != null && !custom.isBlank()) {
            return Paths.get(custom);
        }
        return Paths.get("target", "tv2-data");
    }

    public static final String SESSION_FILE_NAME = "session.properties";
    public static final String ARTIFACT_CACHE_FILE_NAME = "artifact-cache.properties";

    // --------------------------------------------------------- Phone frame UI
    public static final int PHONE_WIDTH = 390;
    public static final int PHONE_HEIGHT = 844;
    public static final long SPLASH_DURATION_MS = 1200L;

    public static final String APP_NAME = "Heritage Guide";
    public static final String APP_VERSION = "0.5.0 (Week 5-6 E2E)";
}
