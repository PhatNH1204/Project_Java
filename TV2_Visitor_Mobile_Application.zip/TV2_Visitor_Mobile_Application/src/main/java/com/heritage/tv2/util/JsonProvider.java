package com.heritage.tv2.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/** Gson dung chung cho Retrofit, mock backend va SessionStorage. */
public final class JsonProvider {

    private static final Gson GSON = new GsonBuilder()
            .disableHtmlEscaping()
            .create();

    private JsonProvider() {
    }

    public static Gson gson() {
        return GSON;
    }
}
