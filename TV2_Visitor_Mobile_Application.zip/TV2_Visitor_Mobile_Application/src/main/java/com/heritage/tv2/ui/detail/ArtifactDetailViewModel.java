package com.heritage.tv2.ui.detail;

import com.heritage.tv2.ble.BleBridgeCoordinator;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.MediaType;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.repository.FavoriteRepository;
import com.heritage.tv2.repository.FeedbackRepository;
import com.heritage.tv2.repository.HeritageRepository;
import com.heritage.tv2.repository.LanguageRepository;
import com.heritage.tv2.repository.VisitHistoryRepository;
import com.heritage.tv2.ui.base.Event;
import com.heritage.tv2.ui.base.LiveData;
import com.heritage.tv2.ui.base.UiState;
import com.heritage.tv2.ui.base.ViewModel;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import java.util.List;

/**
 * ViewModel cho man hinh Chi tiet Hien vat ({@code ArtifactDetailScreen} - Gate 3 Phan 1 &amp; Phan 2).
 *
 * <ul>
 *     <li>Goi {@code GET /api/artifacts/{id}} va luu ban sao vao {@code ArtifactCache}.</li>
 *     <li>Ghi nhan luot xem vao {@link VisitHistoryRepository} kem nguon mo
 *     ({@link VisitHistory#SOURCE_MANUAL} hoac {@link VisitHistory#SOURCE_BEACON_BLE}).</li>
 *     <li><b>Optimistic UI cho Yeu thich</b>: doi trang thai tim ngay lap tuc khi bam, goi
 *     {@code POST/DELETE /api/favorites/{artifactId}}; neu loi mang thi hoan tac (rollback) trang thai nut
 *     va hien thi thong bao loi.</li>
 *     <li><b>Danh gia &amp; Phan hoi (TV5)</b>: chon so sao (1-5) va nhap nhan xet, validate bat buoc
 *     truoc khi goi {@code POST /api/feedback}, hien thi trang thai dang gui / thanh cong / bao loi.</li>
 * </ul>
 */
public class ArtifactDetailViewModel extends ViewModel {

    private final long artifactId;
    private final String openSource;
    private final String associatedBeaconId;
    private final long openedAtEpochMs;
    private final HeritageRepository heritageRepository;
    private final LanguageRepository languageRepository;
    private final FavoriteRepository favoriteRepository;
    private final VisitHistoryRepository visitHistoryRepository;
    private final FeedbackRepository feedbackRepository;
    private final BleBridgeCoordinator bleBridge;
    private final Runnable outOfRangeUnsubscriber;

    private final LiveData<UiState<Artifact>> artifactState = new LiveData<>(UiState.loading());
    private final LiveData<Boolean> fromOfflineCache = new LiveData<>(false);
    private final LiveData<Boolean> beaconOutOfRange = new LiveData<>(false);
    private final LiveData<String> beaconOutOfRangeNotice = new LiveData<>();
    private final LiveData<Boolean> favoriteState = new LiveData<>(false);
    private final LiveData<Event<String>> toastEvent = new LiveData<>();
    private final LiveData<Event<String>> errorEvent = new LiveData<>();

    // Feedback form state (Gate 3 - Part 2)
    private Integer selectedRating = 5;
    private String draftComment = "";
    private final LiveData<Boolean> feedbackSubmitting = new LiveData<>(false);
    private final LiveData<String> feedbackSuccessMessage = new LiveData<>();
    private final LiveData<String> feedbackErrorMessage = new LiveData<>();

    // Media playback & error isolation states
    private int currentImageIndex;
    private boolean forceCurrentImageBroken;
    private boolean audioPlaying;
    private int audioPositionSeconds;
    private boolean forceAudioBroken;
    private boolean videoPlaying;
    private int videoPositionSeconds;
    private boolean forceVideoBroken;
    private boolean repairedBrokenVideoUrl;

    public ArtifactDetailViewModel(long artifactId, AppContainer container) {
        this(artifactId, VisitHistory.SOURCE_MANUAL, null, container);
    }

    public ArtifactDetailViewModel(long artifactId, String openSource, AppContainer container) {
        this(artifactId, openSource, "B-" + artifactId, container);
    }

    public ArtifactDetailViewModel(long artifactId, String openSource, String associatedBeaconId, AppContainer container) {
        super(container.executors());
        this.artifactId = artifactId;
        this.openSource = (openSource == null || openSource.isBlank()) ? VisitHistory.SOURCE_MANUAL : openSource;
        this.associatedBeaconId = (associatedBeaconId == null || associatedBeaconId.isBlank())
                ? ("B-" + artifactId) : associatedBeaconId;
        this.openedAtEpochMs = System.currentTimeMillis();
        this.heritageRepository = container.heritageRepository();
        this.languageRepository = container.languageRepository();
        this.favoriteRepository = container.favoriteRepository();
        this.visitHistoryRepository = container.visitHistoryRepository();
        this.feedbackRepository = container.feedbackRepository();
        this.bleBridge = container.bleBridge();

        this.outOfRangeUnsubscriber = this.bleBridge.outOfRangeBeaconId().observe(id -> {
            if (id != null && matchesBeacon(id)) {
                handleBeaconOutOfRange(id);
            }
        });
    }

    public long getArtifactId() {
        return artifactId;
    }

    public String getOpenSource() {
        return openSource;
    }

    public LiveData<UiState<Artifact>> artifactState() {
        return artifactState;
    }

    public LiveData<Boolean> fromOfflineCache() {
        return fromOfflineCache;
    }

    public LiveData<Boolean> beaconOutOfRange() {
        return beaconOutOfRange;
    }

    public LiveData<String> beaconOutOfRangeNotice() {
        return beaconOutOfRangeNotice;
    }

    public String getAssociatedBeaconId() {
        return associatedBeaconId;
    }

    public boolean matchesBeacon(String beaconId) {
        if (beaconId == null || beaconId.isBlank()) {
            return false;
        }
        return beaconId.trim().equalsIgnoreCase(associatedBeaconId)
                || beaconId.trim().equalsIgnoreCase("B-" + artifactId);
    }

    /**
     * Quy tac BAT BUOC Gate 4 khi nhan onBeaconOutOfRange(beaconId) cho hien vat dang xem:
     * <ul>
     *     <li>KHONG dong man hinh, KHONG xoa du lieu tren UI, KHONG dung Audio/Video dang phat.</li>
     *     <li>Chuyen nguon doc du phong sang {@code ArtifactCache}.</li>
     *     <li>Hien nhan trang thai nho: "Ban da roi khoi vung beacon — van co the tiep tuc xem noi dung".</li>
     * </ul>
     */
    public void handleBeaconOutOfRange(String beaconId) {
        if (!matchesBeacon(beaconId)) {
            return;
        }
        // Dam bao ban sao hien tai luon co trong ArtifactCache va chuyen nguon doc du phong sang ArtifactCache
        Artifact current = currentArtifact();
        if (current != null) {
            heritageRepository.artifactCache().saveBeaconMapping(associatedBeaconId, current);
        } else {
            Artifact cached = heritageRepository.artifactCache()
                    .getLocalized(artifactId, currentLanguage(), AppConfig.DEFAULT_LANGUAGE);
            if (cached != null) {
                artifactState.setValue(UiState.success(cached));
            }
        }
        fromOfflineCache.setValue(true);
        beaconOutOfRange.setValue(true);
        beaconOutOfRangeNotice.setValue(I18n.tr("ble.out_of_range_notice"));
    }

    public LiveData<Boolean> favoriteState() {
        return favoriteState;
    }

    public LiveData< Boolean> feedbackSubmitting() {
        return feedbackSubmitting;
    }

    public LiveData<String> feedbackSuccessMessage() {
        return feedbackSuccessMessage;
    }

    public LiveData<String> feedbackErrorMessage() {
        return feedbackErrorMessage;
    }

    public Integer getSelectedRating() {
        return selectedRating;
    }

    public void setSelectedRating(Integer selectedRating) {
        this.selectedRating = selectedRating;
    }

    public String getDraftComment() {
        return draftComment;
    }

    public void setDraftComment(String draftComment) {
        this.draftComment = draftComment == null ? "" : draftComment;
    }

    public LiveData<Event<String>> toastEvent() {
        return toastEvent;
    }

    public LiveData<Event<String>> errorEvent() {
        return errorEvent;
    }

    public String currentLanguage() {
        return languageRepository.getCurrentLanguage();
    }

    public boolean isCachedInArtifactCache() {
        return heritageRepository.artifactCache().contains(artifactId);
    }

    /** Tai chi tiet hien vat tu API (hoac ArtifactCache neu mat mang) va ghi nhan vao VisitHistory. */
    public void loadArtifact() {
        artifactState.setValue(UiState.loading());
        launch(() -> heritageRepository.getArtifact(artifactId), res -> {
            if (res.isSuccess() && res.getData() != null) {
                Artifact artifact = res.getData();
                fromOfflineCache.setValue(heritageRepository.isLastArtifactFromOfflineCache());
                artifactState.setValue(UiState.success(artifact));
                recordVisitInHistory(artifact);
                refreshFavoriteStatus();
            } else {
                artifactState.setValue(UiState.error(I18n.errorMessage(res)));
            }
        });
    }

    private void recordVisitInHistory(Artifact artifact) {
        String siteName = resolveSiteName(artifact.getSiteId());
        visitHistoryRepository.recordArtifactView(artifact, siteName, openSource);
    }

    private String resolveSiteName(Long siteId) {
        if (siteId == null) {
            return "";
        }
        Result<List<HeritageSite>> sitesRes = heritageRepository.getSites(false);
        if (sitesRes.isSuccess() && sitesRes.getData() != null) {
            for (HeritageSite s : sitesRes.getData()) {
                if (siteId.equals(s.getId())) {
                    return s.getName();
                }
            }
        }
        return "Site #" + siteId;
    }

    /**
     * Tim ban dich khop {@code currentLanguage()}, fallback sang {@link AppConfig#DEFAULT_LANGUAGE}.
     */
    public ContentTranslation resolveTranslation(Artifact artifact) {
        if (artifact == null || artifact.getContent() == null) {
            return null;
        }
        return artifact.getContent().findTranslation(currentLanguage(), AppConfig.DEFAULT_LANGUAGE);
    }

    /** @return {@code true} neu ban dich hien tai la ban fallback (khac ngon ngu nguoi dung chon). */
    public boolean isUsingFallbackTranslation(Artifact artifact) {
        ContentTranslation tr = resolveTranslation(artifact);
        if (tr == null || tr.getLanguageCode() == null) {
            return false;
        }
        return !tr.getLanguageCode().equalsIgnoreCase(currentLanguage());
    }

    // =========================================================== Image Gallery

    public List<Media> imageMediaList(Artifact artifact) {
        if (artifact == null || artifact.getContent() == null) {
            return List.of();
        }
        return artifact.getContent().mediaOfType(MediaType.IMAGE);
    }

    public int getCurrentImageIndex() {
        return currentImageIndex;
    }

    public void nextImage(int totalImages) {
        if (totalImages > 0) {
            currentImageIndex = (currentImageIndex + 1) % totalImages;
            forceCurrentImageBroken = false;
        }
    }

    public void previousImage(int totalImages) {
        if (totalImages > 0) {
            currentImageIndex = (currentImageIndex - 1 + totalImages) % totalImages;
            forceCurrentImageBroken = false;
        }
    }

    public void toggleForceCurrentImageBroken() {
        this.forceCurrentImageBroken = !this.forceCurrentImageBroken;
    }

    public boolean isImageBroken(Media imageMedia) {
        if (forceCurrentImageBroken) {
            return true;
        }
        return isUrlBroken(imageMedia == null ? null : imageMedia.getUrl());
    }

    // ============================================================ Audio Player

    public Media resolveAudioMedia(Artifact artifact) {
        if (artifact == null || artifact.getContent() == null) {
            return null;
        }
        List<Media> audios = artifact.getContent().mediaOfType(MediaType.AUDIO);
        if (audios.isEmpty()) {
            return null;
        }
        String lang = currentLanguage();
        for (Media m : audios) {
            if (m.getLanguageCode() != null && m.getLanguageCode().equalsIgnoreCase(lang)) {
                return m;
            }
        }
        return audios.get(0);
    }

    public boolean isAudioPlaying() {
        return audioPlaying;
    }

    public void setAudioPlaying(boolean audioPlaying) {
        if (isAudioBroken(currentArtifact())) {
            this.audioPlaying = false;
            return;
        }
        this.audioPlaying = audioPlaying;
    }

    public int getAudioPositionSeconds() {
        return audioPositionSeconds;
    }

    public void seekAudio(int seconds, int maxDuration) {
        this.audioPositionSeconds = Math.max(0, Math.min(seconds, Math.max(maxDuration, 1)));
    }

    public boolean isAudioBroken(Artifact artifact) {
        if (forceAudioBroken) {
            return true;
        }
        Media audio = resolveAudioMedia(artifact);
        return audio != null && isUrlBroken(audio.getUrl());
    }

    public void setForceAudioBroken(boolean broken) {
        this.forceAudioBroken = broken;
        if (broken) {
            this.audioPlaying = false;
        }
    }

    // ============================================================ Video Player

    public Media resolveVideoMedia(Artifact artifact) {
        if (artifact == null || artifact.getContent() == null) {
            return null;
        }
        List<Media> videos = artifact.getContent().mediaOfType(MediaType.VIDEO);
        return videos.isEmpty() ? null : videos.get(0);
    }

    public boolean isVideoPlaying() {
        return videoPlaying;
    }

    public void setVideoPlaying(boolean videoPlaying) {
        if (isVideoBroken(currentArtifact())) {
            this.videoPlaying = false;
            return;
        }
        this.videoPlaying = videoPlaying;
    }

    public int getVideoPositionSeconds() {
        return videoPositionSeconds;
    }

    public void seekVideo(int seconds, int maxDuration) {
        this.videoPositionSeconds = Math.max(0, Math.min(seconds, Math.max(maxDuration, 1)));
    }

    public boolean isVideoBroken(Artifact artifact) {
        if (forceVideoBroken) {
            return true;
        }
        Media video = resolveVideoMedia(artifact);
        if (video == null) {
            return false;
        }
        if (repairedBrokenVideoUrl) {
            return false;
        }
        return isUrlBroken(video.getUrl());
    }

    public void setForceVideoBroken(boolean broken) {
        this.forceVideoBroken = broken;
        if (broken) {
            this.videoPlaying = false;
            this.repairedBrokenVideoUrl = false;
        } else {
            this.repairedBrokenVideoUrl = true;
        }
    }

    // =========================================== Optimistic UI for Favorites

    private void refreshFavoriteStatus() {
        launch(favoriteRepository::getFavorites, res -> {
            if (res.isSuccess() && res.getData() != null) {
                boolean fav = false;
                for (Favorite f : res.getData()) {
                    if (f.getArtifactId() != null && f.getArtifactId() == artifactId) {
                        fav = true;
                        break;
                    }
                }
                favoriteState.setValue(fav);
            }
        });
    }

    /**
     * Optimistic UI khi bam nut Yeu thich tren ArtifactDetail:
     * <ol>
     *     <li>Doi trang thai tim ngay lap tuc ({@code previous -> !previous}).</li>
     *     <li>Goi {@code POST /api/favorites/{id}} hoac {@code DELETE /api/favorites/{id}}.</li>
     *     <li>Neu loi mang / API that bai: <b>hoan tac (rollback)</b> trang thai nut ve {@code previous}
     *     va phat thong bao loi.</li>
     * </ol>
     */
    public void toggleFavorite() {
        boolean previousState = Boolean.TRUE.equals(favoriteState.getValue());
        boolean optimisticTarget = !previousState;

        // 1. Optimistic UI: cap nhat trang thai nut ngay lap tuc
        favoriteState.setValue(optimisticTarget);

        // 2. Goi API va hoan tac neu that bai
        if (optimisticTarget) {
            launch(() -> favoriteRepository.addFavorite(artifactId), res -> {
                if (res.isSuccess()) {
                    toastEvent.setValue(new Event<>(I18n.tr("favorite.added_toast")));
                } else {
                    // Rollback ve trang thai cu
                    favoriteState.setValue(previousState);
                    errorEvent.setValue(new Event<>(I18n.tr("favorite.rollback_error")));
                }
            });
        } else {
            launch(() -> favoriteRepository.removeFavorite(artifactId), res -> {
                if (res.isSuccess()) {
                    toastEvent.setValue(new Event<>(I18n.tr("favorite.removed_toast")));
                } else {
                    // Rollback ve trang thai cu
                    favoriteState.setValue(previousState);
                    errorEvent.setValue(new Event<>(I18n.tr("favorite.rollback_error")));
                }
            });
        }
    }

    // ============================================ Rating & Feedback (TV5)

    /**
     * Gui danh gia &amp; phan hoi ({@code POST /api/feedback}) voi validate bat buoc:
     * <ul>
     *     <li>{@code rating}: tu 1 den 5 sao</li>
     *     <li>{@code comment}: bat buoc khong duoc de trong, toi da 1000 ky tu</li>
     * </ul>
     */
    public void submitFeedback(Integer rating, String comment) {
        this.selectedRating = rating;
        this.draftComment = comment == null ? "" : comment;
        feedbackSuccessMessage.setValue(null);
        feedbackErrorMessage.setValue(null);

        FeedbackRequest req = new FeedbackRequest(artifactId, rating, comment);
        FeedbackRequest.ValidationError validationError = req.validate();
        if (validationError != null) {
            String msg;
            switch (validationError) {
                case INVALID_RATING:
                    msg = I18n.tr("feedback.error_invalid_rating");
                    break;
                case EMPTY_COMMENT:
                    msg = I18n.tr("feedback.error_empty_comment");
                    break;
                case COMMENT_TOO_LONG:
                    msg = I18n.tr("feedback.error_comment_too_long");
                    break;
                default:
                    msg = I18n.tr("error.unknown");
                    break;
            }
            feedbackErrorMessage.setValue(msg);
            errorEvent.setValue(new Event<>(msg));
            return;
        }

        feedbackSubmitting.setValue(true);
        launch(() -> feedbackRepository.submit(req), res -> {
            feedbackSubmitting.setValue(false);
            if (res.isSuccess()) {
                this.draftComment = "";
                String okMsg = I18n.tr("feedback.success_msg", rating);
                feedbackSuccessMessage.setValue(okMsg);
                toastEvent.setValue(new Event<>(okMsg));
            } else {
                String errMsg = I18n.errorMessage(res);
                feedbackErrorMessage.setValue(errMsg);
                errorEvent.setValue(new Event<>(errMsg));
            }
        });
    }

    /** Phim tat gui nhanh 5 sao voi nhan xet mac dinh. */
    public void sendFiveStarFeedback() {
        submitFeedback(5, "Great artifact guide!");
    }

    private Artifact currentArtifact() {
        UiState<Artifact> state = artifactState.getValue();
        return state == null ? null : state.getData();
    }

    public static boolean isUrlBroken(String url) {
        if (url == null || url.isBlank()) {
            return true;
        }
        String lower = url.toLowerCase();
        return lower.contains("broken") || lower.contains("error") || lower.contains("invalid");
    }

    @Override
    protected void onCleared() {
        if (outOfRangeUnsubscriber != null) {
            outOfRangeUnsubscriber.run();
        }
        if (VisitHistory.SOURCE_BEACON_BLE.equalsIgnoreCase(openSource) && bleBridge != null) {
            int wallSeconds = (int) Math.max(1L, (System.currentTimeMillis() - openedAtEpochMs) / 1000L);
            int mediaSeconds = Math.max(audioPositionSeconds, videoPositionSeconds);
            bleBridge.notifyContentViewed(associatedBeaconId, artifactId, openedAtEpochMs,
                    Math.max(wallSeconds, mediaSeconds));
        }
    }
}
