package com.heritage.tv2.ui.base;

import com.heritage.tv2.ui.theme.UiTheme;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import javax.swing.JPanel;

/**
 * Lop co so cho moi man hinh (tuong duong {@code Fragment} trong Single-Activity Android).
 * Tu dong huy cac subscription {@link LiveData} khi man hinh bi an ({@link #onHide()}).
 */
public abstract class Screen extends JPanel {

    private final List<Runnable> unsubscribers = new ArrayList<>();

    protected Screen() {
        super(new BorderLayout());
        setBackground(UiTheme.BG_APP);
    }

    /** Dang ky LiveData gan voi vong doi hien thi cua Screen. */
    protected <T> void observe(LiveData<T> liveData, Consumer<T> observer) {
        unsubscribers.add(liveData.observe(observer));
    }

    /** Goi khi Screen duoc dua len khung hien thi. */
    public void onShow() {
    }

    /** Goi khi Screen roi khoi khung hien thi. */
    public void onHide() {
        for (Runnable u : unsubscribers) {
            u.run();
        }
        unsubscribers.clear();
    }
}
