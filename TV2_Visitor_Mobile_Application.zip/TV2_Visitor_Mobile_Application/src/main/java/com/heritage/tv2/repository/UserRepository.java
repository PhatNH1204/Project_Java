package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.request.UpdateProfileRequest;
import com.heritage.tv2.util.Result;

/** Ho so nguoi dung: {@code GET/PUT /api/users/me}. */
public class UserRepository {

    private final HeritageApiService api;
    private final SessionStorage session;

    public UserRepository(HeritageApiService api, SessionStorage session) {
        this.api = api;
        this.session = session;
    }

    public Result<User> getProfile() {
        Result<User> result = ApiCaller.execute(api.getMe());
        if (result.isSuccess()) {
            session.saveUser(result.getData());
        } else if (result.isNetworkError() && session.getUser() != null) {
            return Result.success(session.getUser());
        }
        return result;
    }

    public Result<User> updateProfile(String fullName, String phone) {
        if (fullName == null || fullName.isBlank()) {
            return Result.error(Result.CODE_VALIDATION, null, 0);
        }
        Result<User> result = ApiCaller.execute(api.updateMe(UpdateProfileRequest.profile(fullName.trim(),
                phone == null ? null : phone.trim())));
        if (result.isSuccess()) {
            session.saveUser(result.getData());
        }
        return result;
    }

    public User getCachedUser() {
        return session.getUser();
    }
}
