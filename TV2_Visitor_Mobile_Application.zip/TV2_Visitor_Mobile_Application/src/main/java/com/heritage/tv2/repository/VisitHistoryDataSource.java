package com.heritage.tv2.repository;

import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.util.Result;

import java.util.List;

/**
 * Tang truu tuong nguon du lieu Lich su tham quan ({@link VisitHistory}).
 *
 * <p>Giup {@link VisitHistoryRepository} tach biet hoan toan giua 2 phuong an kien truc:</p>
 * <ul>
 *     <li><b>Phuong an A ({@code INTERACTION_AGGREGATED})</b>: Doc tu endpoint {@code GET /api/visit-history}
 *     do backend tong hop tu bang {@code Interaction} cua TV3.</li>
 *     <li><b>Phuong an B ({@code STANDALONE_VISIT_HISTORY})</b>: Bang / nguon {@code VisitHistory} doc lap
 *     ghi nhan truc tiep cac luot mo hien vat ({@code MANUAL} hoac {@code BEACON_BLE}).</li>
 * </ul>
 */
public interface VisitHistoryDataSource {

    /** Lay danh sach lich su tham quan (chua can sap xep; Repository se sap xep theo thoi gian gan nhat). */
    Result<List<VisitHistory>> fetchHistory();

    /**
     * Ghi nhan mot luot xem hien vat voi nguon mo ({@link VisitHistory#SOURCE_MANUAL}
     * hoac {@link VisitHistory#SOURCE_BEACON_BLE}).
     */
    void recordVisit(Artifact artifact, String siteName, String source);
}
