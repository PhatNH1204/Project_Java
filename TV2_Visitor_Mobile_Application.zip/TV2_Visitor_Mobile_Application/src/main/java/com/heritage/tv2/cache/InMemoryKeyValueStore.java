package com.heritage.tv2.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Kho trong bo nho - dung cho Unit Test va che do khong luu phien. */
public class InMemoryKeyValueStore implements KeyValueStore {

    private final Map<String, String> data = new ConcurrentHashMap<>();

    @Override
    public String get(String key) {
        return data.get(key);
    }

    @Override
    public synchronized void putAll(Map<String, String> values) {
        values.forEach((k, v) -> {
            if (v == null) {
                data.remove(k);
            } else {
                data.put(k, v);
            }
        });
    }

    public int size() {
        return data.size();
    }
}
