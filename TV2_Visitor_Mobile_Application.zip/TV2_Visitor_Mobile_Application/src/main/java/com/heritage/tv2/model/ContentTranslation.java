package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Ban dich cua mot {@link Content} - khop Entity {@code ContentTranslation} cua TV4.
 * Ho tro day du schema JSON that (camelCase &amp; snake_case) tu Swagger/OpenAPI.
 */
public class ContentTranslation {

    @SerializedName(value = "id", alternate = {"translationId", "translation_id"})
    private Long id;

    /** Ma ngon ngu ISO 639-1: vi / en. */
    @SerializedName(value = "languageCode", alternate = {"language_code", "langCode", "lang_code", "lang", "locale"})
    private String languageCode;

    @SerializedName(value = "title", alternate = {"heading", "artifactTitle", "artifact_title"})
    private String title;

    @SerializedName(value = "bodyText", alternate = {"body_text", "body", "contentText", "content_text", "description"})
    private String bodyText;

    public ContentTranslation() {
    }

    public ContentTranslation(Long id, String languageCode, String title, String bodyText) {
        this.id = id;
        this.languageCode = languageCode;
        this.title = title;
        this.bodyText = bodyText;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBodyText() {
        return bodyText;
    }

    public void setBodyText(String bodyText) {
        this.bodyText = bodyText;
    }
}
