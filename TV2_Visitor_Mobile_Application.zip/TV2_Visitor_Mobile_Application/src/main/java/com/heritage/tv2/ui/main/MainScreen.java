package com.heritage.tv2.ui.main;

import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.base.UiState;
import com.heritage.tv2.ui.theme.UiTheme;
import com.heritage.tv2.util.I18n;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 * Man hinh Main voi Bottom Navigation Bar 4 Tab (Gate 2 + Gate 3 Phan 1):
 * <ol>
 *     <li>Tab 1: Kham pha ({@code GET /api/sites}, tim kiem ten/khu vuc, loc danh muc,
 *     4 trang thai Loading/Success/Empty/Error+Retry, mo {@code ArtifactDetailScreen})</li>
 *     <li>Tab 2: Ban do Di san (Marker theo latitude/longitude, kiem tra quyen GPS Granted/Denied,
 *     bam vao dia diem mo danh sach {@code Artifact} thuoc dia diem do -> mo {@code ArtifactDetailScreen})</li>
 *     <li>Tab 3: Yeu thich &amp; Lich su ({@code GET/POST/DELETE /api/favorites}, {@code GET /api/visit-history})</li>
 *     <li>Tab 4: Ho so &amp; Ngon ngu ({@code GET/PUT /api/users/me}, doi ngon ngu {@code vi}/{@code en})</li>
 * </ol>
 */
public class MainScreen extends Screen {

    private final MainViewModel viewModel;
    private final Navigator navigator;

    private final CardLayout tabCardLayout = new CardLayout();
    private final JPanel tabHost = new JPanel(tabCardLayout);
    private final List<JButton> navButtons = new ArrayList<>();

    // Tab 1 - Explore components
    private JTextField searchField;
    private JComboBox<CategoryOption> categoryCombo;
    private final JPanel sitesStateContainer = new JPanel();
    private final JPanel artifactDetailContainer = new JPanel();
    private final JLabel bleEventLabel = UiTheme.subtitleLabel("");

    // Tab 2 - Map components
    private HeritageMapCanvas mapCanvas;
    private final JPanel gpsPermissionContainer = new JPanel();
    private final JLabel mapSelectedSiteLabel = UiTheme.sectionLabel("");
    private final JLabel mapCoordsLabel = UiTheme.subtitleLabel("");
    private final JLabel mapDistanceLabel = UiTheme.subtitleLabel("");
    private final JLabel mapAddressLabel = UiTheme.subtitleLabel("");
    private final JPanel mapSiteArtifactsContainer = new JPanel();
    private HeritageSite mapSelectedSite;

    // Tab 3 - Favorites & History components (2 sub-tabs: Favorites & Visit History)
    private final CardLayout favHistorySubCardLayout = new CardLayout();
    private final JPanel favHistorySubHost = new JPanel(favHistorySubCardLayout);
    private JButton favSubTabBtn;
    private JButton historySubTabBtn;
    private final JPanel favoritesListContainer = new JPanel();
    private final JPanel historyListContainer = new JPanel();
    private final JLabel favSectionTitle = UiTheme.sectionLabel("");
    private final JLabel historySectionTitle = UiTheme.sectionLabel("");

    // Tab 4 - Profile & Language components
    private JLabel emailValueLabel;
    private JLabel roleValueLabel;
    private JTextField fullNameField;
    private JTextField phoneField;
    private JButton saveProfileButton;
    private JComboBox<Language> languageCombo;
    private boolean suppressLanguageComboEvent;

    private static final class CategoryOption {
        final String code;
        final String label;

        CategoryOption(String code, String label) {
            this.code = code;
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    public MainScreen(MainViewModel viewModel, Navigator navigator) {
        this.viewModel = viewModel;
        this.navigator = navigator;
        buildUi();
    }

    private void buildUi() {
        tabHost.setBackground(UiTheme.BG_APP);
        tabHost.add(buildExploreTab(), String.valueOf(MainViewModel.TAB_EXPLORE));
        tabHost.add(buildMapTab(), String.valueOf(MainViewModel.TAB_MAP));
        tabHost.add(buildFavHistoryTab(), String.valueOf(MainViewModel.TAB_FAV_HISTORY));
        tabHost.add(buildProfileLanguageTab(), String.valueOf(MainViewModel.TAB_PROFILE));

        add(tabHost, BorderLayout.CENTER);
        add(buildBottomNavigationBar(), BorderLayout.SOUTH);

        switchTab(viewModel.getActiveTab());
    }

    // ===================================================== Bottom Navigation
    private JPanel buildBottomNavigationBar() {
        JPanel bar = new JPanel(new GridLayout(1, 4, 2, 0));
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UiTheme.BORDER_COLOR));

        String[] icons = {"🏛", "🗺", "♥", "👤"};
        String[] labels = {
                I18n.tr("tab.explore"),
                I18n.tr("tab.map"),
                I18n.tr("tab.fav_history"),
                I18n.tr("tab.profile")
        };

        navButtons.clear();
        for (int i = 0; i < 4; i++) {
            final int tabIndex = i;
            JButton btn = new JButton("<html><center>" + icons[i] + "<br><span style='font-size:8.5px'>"
                    + labels[i] + "</span></center></html>");
            btn.setFocusPainted(false);
            btn.setBorder(new EmptyBorder(7, 2, 7, 2));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btn.setOpaque(true);
            btn.addActionListener(e -> switchTab(tabIndex));
            navButtons.add(btn);
            bar.add(btn);
        }
        return bar;
    }

    public void switchTab(int tabIndex) {
        viewModel.setActiveTab(tabIndex);
        tabCardLayout.show(tabHost, String.valueOf(tabIndex));
        for (int i = 0; i < navButtons.size(); i++) {
            JButton b = navButtons.get(i);
            boolean active = (i == tabIndex);
            b.setBackground(active ? UiTheme.ACCENT_SOFT : Color.WHITE);
            b.setForeground(active ? UiTheme.PRIMARY_DARK : UiTheme.TEXT_SECONDARY);
        }
    }

    // ===================================================== Tab 1: Explore
    private Component buildExploreTab() {
        JPanel page = new JPanel();
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBackground(UiTheme.BG_APP);
        page.setBorder(new EmptyBorder(12, 14, 14, 14));

        // Top header + Refresh / Simulate Network Error buttons
        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        topRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        topRow.add(UiTheme.titleLabel(I18n.tr("explore.header")), BorderLayout.WEST);

        JPanel topBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        topBtns.setOpaque(false);
        if (viewModel.hasMockBackend()) {
            JButton simErrBtn = UiTheme.dangerButton(I18n.tr("explore.sim_error"));
            simErrBtn.setFont(UiTheme.FONT_BADGE);
            simErrBtn.addActionListener(e -> viewModel.simulateSitesNetworkError());
            topBtns.add(simErrBtn);
        }
        JButton reloadBtn = UiTheme.secondaryButton(I18n.tr("explore.reload"));
        reloadBtn.setFont(UiTheme.FONT_BADGE);
        reloadBtn.addActionListener(e -> viewModel.retryLoadSites());
        topBtns.add(reloadBtn);
        topRow.add(topBtns, BorderLayout.EAST);

        page.add(topRow);
        page.add(Box.createVerticalStrut(2));
        page.add(UiTheme.subtitleLabel(I18n.tr("explore.subtitle",
                viewModel.currentLanguage().toUpperCase(Locale.ROOT))));
        page.add(Box.createVerticalStrut(8));

        // Search & Category filter bar
        JPanel filterCard = new JPanel();
        filterCard.setLayout(new BoxLayout(filterCard, BoxLayout.Y_AXIS));
        filterCard.setBackground(UiTheme.BG_CARD);
        filterCard.setBorder(UiTheme.cardBorder());
        filterCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        searchField = UiTheme.textField(viewModel.getSearchQuery());
        searchField.setToolTipText(I18n.tr("explore.search_placeholder"));
        searchField.setAlignmentX(Component.LEFT_ALIGNMENT);
        searchField.addActionListener(e -> applyExploreFilters());
        filterCard.add(searchField);
        filterCard.add(Box.createVerticalStrut(6));

        CategoryOption[] catOptions = {
                new CategoryOption(HeritageSite.CATEGORY_ALL, I18n.tr("explore.cat_all")),
                new CategoryOption(HeritageSite.CATEGORY_CITADEL, I18n.tr("explore.cat_citadel")),
                new CategoryOption(HeritageSite.CATEGORY_TEMPLE, I18n.tr("explore.cat_temple")),
                new CategoryOption(HeritageSite.CATEGORY_MUSEUM, I18n.tr("explore.cat_museum"))
        };
        categoryCombo = new JComboBox<>(catOptions);
        categoryCombo.setAlignmentX(Component.LEFT_ALIGNMENT);
        categoryCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        for (int i = 0; i < catOptions.length; i++) {
            if (catOptions[i].code.equalsIgnoreCase(viewModel.getSelectedCategory())) {
                categoryCombo.setSelectedIndex(i);
                break;
            }
        }
        categoryCombo.addActionListener(e -> applyExploreFilters());
        filterCard.add(categoryCombo);
        filterCard.add(Box.createVerticalStrut(6));

        JPanel filterBtnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        filterBtnRow.setOpaque(false);
        filterBtnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton searchBtn = UiTheme.primaryButton("🔍 " + I18n.tr("explore.search_btn"));
        searchBtn.addActionListener(e -> applyExploreFilters());
        JButton clearBtn = UiTheme.secondaryButton(I18n.tr("explore.clear_filter"));
        clearBtn.addActionListener(e -> {
            searchField.setText("");
            categoryCombo.setSelectedIndex(0);
            viewModel.clearFilters();
        });
        filterBtnRow.add(searchBtn);
        filterBtnRow.add(clearBtn);
        filterCard.add(filterBtnRow);

        page.add(filterCard);
        page.add(Box.createVerticalStrut(8));

        // BLE Beacon simulator button
        JButton bleBtn = UiTheme.secondaryButton("📡 " + I18n.tr("explore.ble_sim"));
        bleBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        bleBtn.addActionListener(e -> viewModel.simulateBeaconSignal());
        page.add(bleBtn);
        page.add(Box.createVerticalStrut(3));
        bleEventLabel.setForeground(UiTheme.PRIMARY);
        page.add(bleEventLabel);
        page.add(Box.createVerticalStrut(8));

        // 4-State Sites Container (Loading / Success / Empty / Error)
        sitesStateContainer.setLayout(new BoxLayout(sitesStateContainer, BoxLayout.Y_AXIS));
        sitesStateContainer.setOpaque(false);
        sitesStateContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(sitesStateContainer);
        page.add(Box.createVerticalStrut(10));

        // Quick preview card for selected artifact
        artifactDetailContainer.setLayout(new BoxLayout(artifactDetailContainer, BoxLayout.Y_AXIS));
        artifactDetailContainer.setOpaque(false);
        artifactDetailContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(artifactDetailContainer);

        return UiTheme.verticalScroll(page);
    }

    private void applyExploreFilters() {
        CategoryOption opt = (CategoryOption) categoryCombo.getSelectedItem();
        String cat = opt != null ? opt.code : HeritageSite.CATEGORY_ALL;
        viewModel.setSearchAndCategory(searchField.getText(), cat);
    }

    /**
     * Render day du 4 trang thai UI cho Tab 1: LOADING, SUCCESS, EMPTY, ERROR.
     */
    private void renderSitesState(UiState<List<HeritageSite>> state) {
        sitesStateContainer.removeAll();
        if (state == null || state.isLoading()) {
            // 1. LOADING STATE (Shimmer / Progress)
            JPanel shimmerCard = new JPanel();
            shimmerCard.setLayout(new BoxLayout(shimmerCard, BoxLayout.Y_AXIS));
            shimmerCard.setBackground(UiTheme.BG_CARD);
            shimmerCard.setBorder(UiTheme.cardBorder());
            shimmerCard.setAlignmentX(Component.LEFT_ALIGNMENT);

            shimmerCard.add(UiTheme.sectionLabel("⏳ " + I18n.tr("explore.state_loading")));
            shimmerCard.add(Box.createVerticalStrut(8));
            JProgressBar progress = new JProgressBar();
            progress.setIndeterminate(true);
            progress.setAlignmentX(Component.LEFT_ALIGNMENT);
            shimmerCard.add(progress);
            shimmerCard.add(Box.createVerticalStrut(10));

            for (int i = 0; i < 2; i++) {
                JPanel skeleton = new JPanel();
                skeleton.setPreferredSize(new Dimension(320, 48));
                skeleton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
                skeleton.setBackground(new Color(235, 230, 222));
                skeleton.setAlignmentX(Component.LEFT_ALIGNMENT);
                shimmerCard.add(skeleton);
                shimmerCard.add(Box.createVerticalStrut(6));
            }
            sitesStateContainer.add(shimmerCard);

        } else if (state.isError()) {
            // 2. ERROR STATE (Loi mang + nut Thu lai)
            JPanel errCard = new JPanel();
            errCard.setLayout(new BoxLayout(errCard, BoxLayout.Y_AXIS));
            errCard.setBackground(new Color(253, 237, 237));
            errCard.setBorder(UiTheme.cardBorder());
            errCard.setAlignmentX(Component.LEFT_ALIGNMENT);

            errCard.add(UiTheme.sectionLabel("⚠ " + I18n.tr("explore.state_error_title")));
            errCard.add(Box.createVerticalStrut(4));
            errCard.add(UiTheme.wrappingText(state.getErrorMessage(), UiTheme.FONT_BODY, UiTheme.DANGER));
            errCard.add(Box.createVerticalStrut(10));

            JButton retryBtn = UiTheme.primaryButton(I18n.tr("explore.retry_btn"));
            retryBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            retryBtn.addActionListener(e -> viewModel.retryLoadSites());
            errCard.add(retryBtn);
            sitesStateContainer.add(errCard);

        } else if (state.isEmpty()) {
            // 3. EMPTY STATE (Khong tim thay)
            JPanel emptyCard = new JPanel();
            emptyCard.setLayout(new BoxLayout(emptyCard, BoxLayout.Y_AXIS));
            emptyCard.setBackground(UiTheme.BG_CARD);
            emptyCard.setBorder(UiTheme.cardBorder());
            emptyCard.setAlignmentX(Component.LEFT_ALIGNMENT);

            emptyCard.add(UiTheme.sectionLabel("🔍 " + I18n.tr("explore.state_empty_title")));
            emptyCard.add(Box.createVerticalStrut(4));
            emptyCard.add(UiTheme.wrappingText(I18n.tr("explore.state_empty_sub"),
                    UiTheme.FONT_SMALL, UiTheme.TEXT_SECONDARY));
            emptyCard.add(Box.createVerticalStrut(8));

            JButton clearBtn = UiTheme.secondaryButton(I18n.tr("explore.clear_filter"));
            clearBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            clearBtn.addActionListener(e -> {
                if (searchField != null) {
                    searchField.setText("");
                }
                if (categoryCombo != null) {
                    categoryCombo.setSelectedIndex(0);
                }
                viewModel.clearFilters();
            });
            emptyCard.add(clearBtn);
            sitesStateContainer.add(emptyCard);

        } else {
            // 4. SUCCESS STATE
            renderSitesSuccessList(state.getData());
        }
        sitesStateContainer.revalidate();
        sitesStateContainer.repaint();
    }

    private void renderSitesSuccessList(List<HeritageSite> siteList) {
        sitesStateContainer.add(UiTheme.sectionLabel(I18n.tr("explore.sites_title", siteList.size())));
        sitesStateContainer.add(Box.createVerticalStrut(6));

        for (HeritageSite site : siteList) {
            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(UiTheme.BG_CARD);
            card.setBorder(UiTheme.cardBorder());
            card.setAlignmentX(Component.LEFT_ALIGNMENT);

            String catTag = site.getCategory() != null ? (" [" + site.getCategory() + "]") : "";
            JLabel name = UiTheme.sectionLabel(site.getName() + " (" + site.getCode() + ")" + catTag);
            name.setForeground(UiTheme.PRIMARY_DARK);
            card.add(name);
            card.add(Box.createVerticalStrut(3));
            card.add(UiTheme.wrappingText(site.getDescription(), UiTheme.FONT_SMALL, UiTheme.TEXT_PRIMARY));
            card.add(Box.createVerticalStrut(4));
            if (site.getRegion() != null) {
                card.add(UiTheme.subtitleLabel("🗺 " + I18n.tr("explore.region", site.getRegion())));
            }
            card.add(UiTheme.subtitleLabel("📍 " + site.getAddress()));
            if (site.getOpeningHours() != null) {
                card.add(UiTheme.subtitleLabel("🕒 " + I18n.tr("explore.open_hours", site.getOpeningHours())));
            }
            card.add(Box.createVerticalStrut(6));

            // Danh sach hien vat thuoc dia diem nay -> bam de mo ArtifactDetailScreen
            List<Artifact> siteArtifacts = site.getArtifacts();
            if (siteArtifacts != null && !siteArtifacts.isEmpty()) {
                card.add(UiTheme.subtitleLabel(I18n.tr("explore.site_artifacts_label", siteArtifacts.size())));
                card.add(Box.createVerticalStrut(4));
                for (Artifact a : siteArtifacts) {
                    JPanel artRow = new JPanel(new BorderLayout(6, 0));
                    artRow.setBackground(UiTheme.ACCENT_SOFT);
                    artRow.setBorder(new EmptyBorder(5, 8, 5, 8));
                    artRow.setAlignmentX(Component.LEFT_ALIGNMENT);

                    JLabel artTitle = UiTheme.subtitleLabel("🏺 " + a.getName());
                    artTitle.setForeground(UiTheme.TEXT_PRIMARY);
                    artRow.add(artTitle, BorderLayout.CENTER);

                    JButton detailBtn = UiTheme.primaryButton(I18n.tr("explore.open_detail"));
                    detailBtn.setFont(UiTheme.FONT_BADGE);
                    detailBtn.addActionListener(e -> navigator.openArtifactDetail(a.getId()));
                    artRow.add(detailBtn, BorderLayout.EAST);

                    card.add(artRow);
                    card.add(Box.createVerticalStrut(4));
                }
            } else {
                JButton inspectBtn = UiTheme.secondaryButton(I18n.tr("explore.inspect_artifact"));
                inspectBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
                inspectBtn.addActionListener(e -> viewModel.inspectSiteFeaturedArtifact(site.getId()));
                card.add(inspectBtn);
            }

            sitesStateContainer.add(card);
            sitesStateContainer.add(Box.createVerticalStrut(8));
        }
    }

    private void renderArtifactDetail(Artifact artifact) {
        artifactDetailContainer.removeAll();
        if (artifact == null) {
            artifactDetailContainer.revalidate();
            artifactDetailContainer.repaint();
            return;
        }

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UiTheme.ACCENT_SOFT);
        card.setBorder(UiTheme.cardBorder());
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(UiTheme.subtitleLabel(I18n.tr("explore.artifact_detail") + " • " + artifact.getCode()));
        card.add(Box.createVerticalStrut(2));

        String lang = viewModel.currentLanguage();
        ContentTranslation tr = artifact.getContent() == null
                ? null : artifact.getContent().findTranslation(lang, "vi");
        String title = tr != null ? tr.getTitle() : artifact.getName();
        String body = tr != null ? tr.getBodyText() : artifact.getShortDescription();

        card.add(UiTheme.sectionLabel("🏺 " + title));
        card.add(Box.createVerticalStrut(2));
        card.add(UiTheme.subtitleLabel(I18n.tr("explore.period", artifact.getPeriod())));
        card.add(Box.createVerticalStrut(6));
        card.add(UiTheme.wrappingText(body, UiTheme.FONT_BODY, UiTheme.TEXT_PRIMARY));

        if (artifact.getContent() != null && artifact.getContent().getMedia() != null) {
            card.add(Box.createVerticalStrut(6));
            card.add(UiTheme.subtitleLabel(I18n.tr("explore.media_list")));
            for (Media m : artifact.getContent().getMedia()) {
                if (m.getLanguageCode() == null || m.getLanguageCode().equalsIgnoreCase(lang)) {
                    String dur = m.getDuration() != null ? " (" + m.getDuration() + "s)" : "";
                    card.add(UiTheme.subtitleLabel("  • [" + m.getMediaType() + "] " + m.getUrl() + dur));
                }
            }
        }

        card.add(Box.createVerticalStrut(8));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        actions.setOpaque(false);
        actions.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton fullDetailBtn = UiTheme.primaryButton(I18n.tr("explore.open_detail"));
        fullDetailBtn.addActionListener(e -> navigator.openArtifactDetail(artifact.getId()));

        boolean fav = viewModel.isFavorite(artifact.getId());
        JButton favBtn = fav
                ? UiTheme.dangerButton(I18n.tr("explore.fav_remove"))
                : UiTheme.secondaryButton(I18n.tr("explore.fav_add"));
        favBtn.addActionListener(e -> viewModel.toggleFavorite(artifact.getId()));

        actions.add(fullDetailBtn);
        actions.add(favBtn);
        card.add(actions);

        artifactDetailContainer.add(card);
        artifactDetailContainer.revalidate();
        artifactDetailContainer.repaint();
    }

    // ===================================================== Tab 2: Map
    private Component buildMapTab() {
        JPanel page = new JPanel();
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBackground(UiTheme.BG_APP);
        page.setBorder(new EmptyBorder(12, 14, 14, 14));

        page.add(UiTheme.titleLabel(I18n.tr("map.header")));
        page.add(Box.createVerticalStrut(2));
        page.add(UiTheme.wrappingText(I18n.tr("map.subtitle"), UiTheme.FONT_SMALL, UiTheme.TEXT_SECONDARY));
        page.add(Box.createVerticalStrut(6));

        // GPS Permission status & guidance box
        gpsPermissionContainer.setLayout(new BoxLayout(gpsPermissionContainer, BoxLayout.Y_AXIS));
        gpsPermissionContainer.setOpaque(false);
        gpsPermissionContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(gpsPermissionContainer);
        page.add(Box.createVerticalStrut(6));

        page.add(UiTheme.subtitleLabel(I18n.tr("map.legend")));
        page.add(Box.createVerticalStrut(6));

        mapCanvas = new HeritageMapCanvas();
        mapCanvas.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(mapCanvas);
        page.add(Box.createVerticalStrut(8));

        // Selected site info + Artifacts belonging to this site
        JPanel infoCard = new JPanel();
        infoCard.setLayout(new BoxLayout(infoCard, BoxLayout.Y_AXIS));
        infoCard.setBackground(UiTheme.BG_CARD);
        infoCard.setBorder(UiTheme.cardBorder());
        infoCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        infoCard.add(mapSelectedSiteLabel);
        infoCard.add(Box.createVerticalStrut(3));
        infoCard.add(mapCoordsLabel);
        infoCard.add(Box.createVerticalStrut(2));
        infoCard.add(mapDistanceLabel);
        infoCard.add(Box.createVerticalStrut(2));
        infoCard.add(mapAddressLabel);
        infoCard.add(Box.createVerticalStrut(8));

        // Container for Artifacts belonging to the selected site on Map
        mapSiteArtifactsContainer.setLayout(new BoxLayout(mapSiteArtifactsContainer, BoxLayout.Y_AXIS));
        mapSiteArtifactsContainer.setOpaque(false);
        mapSiteArtifactsContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoCard.add(mapSiteArtifactsContainer);
        infoCard.add(Box.createVerticalStrut(6));

        JButton scanHereBtn = UiTheme.secondaryButton("📡 " + I18n.tr("map.trigger_beacon"));
        scanHereBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        scanHereBtn.addActionListener(e -> {
            if (mapSelectedSite != null) {
                viewModel.inspectSiteFeaturedArtifact(mapSelectedSite.getId());
            }
            viewModel.simulateBeaconSignal();
            switchTab(MainViewModel.TAB_EXPLORE);
        });
        infoCard.add(scanHereBtn);

        page.add(infoCard);
        return UiTheme.verticalScroll(page);
    }

    private void renderGpsPermissionState(boolean granted) {
        gpsPermissionContainer.removeAll();
        if (granted) {
            JPanel okBar = new JPanel(new BorderLayout(6, 0));
            okBar.setBackground(new Color(228, 245, 233));
            okBar.setBorder(UiTheme.cardBorder());
            okBar.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel lbl = UiTheme.subtitleLabel("📍 " + I18n.tr("map.gps_granted_badge"));
            lbl.setForeground(UiTheme.SUCCESS);
            okBar.add(lbl, BorderLayout.CENTER);

            JButton denyTestBtn = UiTheme.secondaryButton(I18n.tr("map.gps_deny_btn"));
            denyTestBtn.setFont(UiTheme.FONT_BADGE);
            denyTestBtn.addActionListener(e -> viewModel.setLocationPermissionGranted(false));
            okBar.add(denyTestBtn, BorderLayout.EAST);

            gpsPermissionContainer.add(okBar);
        } else {
            // User denied GPS permission: show guidance banner while keeping Map & Markers active!
            JPanel deniedCard = new JPanel();
            deniedCard.setLayout(new BoxLayout(deniedCard, BoxLayout.Y_AXIS));
            deniedCard.setBackground(new Color(255, 243, 205));
            deniedCard.setBorder(UiTheme.cardBorder());
            deniedCard.setAlignmentX(Component.LEFT_ALIGNMENT);

            deniedCard.add(UiTheme.sectionLabel(I18n.tr("map.gps_denied_title")));
            deniedCard.add(Box.createVerticalStrut(4));
            deniedCard.add(UiTheme.wrappingText(I18n.tr("map.gps_denied_guide"),
                    UiTheme.FONT_SMALL, UiTheme.PRIMARY_DARK));
            deniedCard.add(Box.createVerticalStrut(6));

            JButton grantBtn = UiTheme.primaryButton(I18n.tr("map.gps_grant_btn"));
            grantBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            grantBtn.addActionListener(e -> viewModel.setLocationPermissionGranted(true));
            deniedCard.add(grantBtn);

            gpsPermissionContainer.add(deniedCard);
        }
        if (mapSelectedSite != null) {
            updateMapDistanceLabel(mapSelectedSite);
        }
        if (mapCanvas != null) {
            mapCanvas.repaint();
        }
        gpsPermissionContainer.revalidate();
        gpsPermissionContainer.repaint();
    }

    public void selectSiteOnMap(HeritageSite site) {
        this.mapSelectedSite = site;
        if (site != null) {
            viewModel.selectSite(site.getId());
            mapSelectedSiteLabel.setText(I18n.tr("map.selected_site", site.getName()));
            mapCoordsLabel.setText(I18n.tr("map.coords",
                    String.format(Locale.US, "%.4f°N", site.getLatitude()),
                    String.format(Locale.US, "%.4f°E", site.getLongitude())));
            updateMapDistanceLabel(site);
            mapAddressLabel.setText(I18n.tr("map.address", site.getAddress()));
        }
        if (mapCanvas != null) {
            mapCanvas.repaint();
        }
    }

    private void updateMapDistanceLabel(HeritageSite site) {
        if (viewModel.isLocationPermissionGranted() && site != null) {
            double km = viewModel.distanceFromUserKm(site);
            mapDistanceLabel.setText("📏 " + I18n.tr("map.distance", String.format(Locale.US, "%.2f", km)));
            mapDistanceLabel.setVisible(true);
        } else {
            mapDistanceLabel.setText("");
            mapDistanceLabel.setVisible(false);
        }
    }

    private void renderMapSiteArtifacts(List<Artifact> artifacts) {
        mapSiteArtifactsContainer.removeAll();
        String siteName = mapSelectedSite != null ? mapSelectedSite.getName() : "";
        List<Artifact> list = artifacts == null ? List.of() : artifacts;
        mapSiteArtifactsContainer.add(UiTheme.subtitleLabel(
                I18n.tr("map.site_artifacts_title", siteName, list.size())));
        mapSiteArtifactsContainer.add(Box.createVerticalStrut(4));

        for (Artifact a : list) {
            JPanel row = new JPanel(new BorderLayout(6, 0));
            row.setBackground(UiTheme.ACCENT_SOFT);
            row.setBorder(new EmptyBorder(6, 8, 6, 8));
            row.setAlignmentX(Component.LEFT_ALIGNMENT);

            JPanel left = new JPanel();
            left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
            left.setOpaque(false);
            left.add(UiTheme.sectionLabel("🏺 " + a.getName()));
            if (a.getPeriod() != null) {
                left.add(UiTheme.subtitleLabel(a.getPeriod()));
            }
            row.add(left, BorderLayout.CENTER);

            JButton openBtn = UiTheme.primaryButton(I18n.tr("explore.open_detail"));
            openBtn.setFont(UiTheme.FONT_BADGE);
            openBtn.addActionListener(e -> navigator.openArtifactDetail(a.getId()));
            row.add(openBtn, BorderLayout.EAST);

            mapSiteArtifactsContainer.add(row);
            mapSiteArtifactsContainer.add(Box.createVerticalStrut(4));
        }
        mapSiteArtifactsContainer.revalidate();
        mapSiteArtifactsContainer.repaint();
    }

    /** Canvas ve ban do khu di san Ha Noi, Marker latitude/longitude va vi tri GPS nguoi dung. */
    private final class HeritageMapCanvas extends JPanel {
        private List<HeritageSite> mapSites = List.of();

        HeritageMapCanvas() {
            setPreferredSize(new Dimension(340, 210));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 210));
            setBackground(new Color(230, 239, 229));
            setBorder(BorderFactory.createLineBorder(UiTheme.BORDER_COLOR, 1, true));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    HeritageSite nearest = findNearest(e.getX(), e.getY());
                    if (nearest != null) {
                        selectSiteOnMap(nearest);
                    }
                }
            });
        }

        void setSites(List<HeritageSite> list) {
            this.mapSites = list == null ? List.of() : list;
            if (!mapSites.isEmpty() && mapSelectedSite == null) {
                selectSiteOnMap(mapSites.get(0));
            } else if (mapSelectedSite != null) {
                for (HeritageSite s : mapSites) {
                    if (s.getId().equals(mapSelectedSite.getId())) {
                        selectSiteOnMap(s);
                        break;
                    }
                }
            }
            repaint();
        }

        private int[] latLngToPixel(double lat, double lng) {
            int w = Math.max(getWidth(), 320);
            int h = Math.max(getHeight(), 190);
            double minLat = 21.020, maxLat = 21.040;
            double minLng = 105.830, maxLng = 105.865;
            double xRatio = (lng - minLng) / (maxLng - minLng);
            double yRatio = 1.0 - (lat - minLat) / (maxLat - minLat);
            int x = 32 + (int) (xRatio * (w - 64));
            int y = 28 + (int) (yRatio * (h - 56));
            return new int[]{x, y};
        }

        private int[] toPixel(HeritageSite s) {
            return latLngToPixel(s.getLatitude(), s.getLongitude());
        }

        private HeritageSite findNearest(int mx, int my) {
            HeritageSite best = null;
            double bestDist = Double.MAX_VALUE;
            for (HeritageSite s : mapSites) {
                int[] p = toPixel(s);
                double d = Math.hypot(mx - p[0], my - p[1]);
                if (d < bestDist) {
                    bestDist = d;
                    best = s;
                }
            }
            return best;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Grid lines
            g2.setColor(new Color(210, 224, 210));
            for (int x = 30; x < getWidth(); x += 40) {
                g2.drawLine(x, 0, x, getHeight());
            }
            for (int y = 30; y < getHeight(); y += 40) {
                g2.drawLine(0, y, getWidth(), y);
            }

            // Red River curve
            g2.setColor(new Color(179, 211, 232));
            g2.setStroke(new BasicStroke(12f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawLine(getWidth() - 70, 0, getWidth(), getHeight());

            // Draw user GPS marker if location permission is granted
            if (viewModel.isLocationPermissionGranted()) {
                int[] up = latLngToPixel(MainViewModel.USER_GPS_LAT, MainViewModel.USER_GPS_LNG);
                g2.setColor(new Color(33, 118, 255, 60));
                g2.fillOval(up[0] - 18, up[1] - 18, 36, 36);
                g2.setColor(new Color(22, 96, 224));
                g2.fillOval(up[0] - 6, up[1] - 6, 12, 12);
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(up[0] - 6, up[1] - 6, 12, 12);
                g2.setFont(UiTheme.FONT_BADGE);
                g2.setColor(new Color(22, 96, 224));
                g2.drawString("GPS", up[0] + 8, up[1] + 4);
            }

            g2.setStroke(new BasicStroke(1.5f));
            for (HeritageSite s : mapSites) {
                int[] p = toPixel(s);
                boolean selected = mapSelectedSite != null && s.getId().equals(mapSelectedSite.getId());

                // Beacon coverage circle
                g2.setColor(selected ? new Color(197, 151, 62, 85) : new Color(138, 43, 28, 45));
                int r = selected ? 28 : 20;
                g2.fillOval(p[0] - r, p[1] - r, r * 2, r * 2);

                // Marker pin
                g2.setColor(selected ? UiTheme.PRIMARY : UiTheme.PRIMARY_DARK);
                g2.fillOval(p[0] - 7, p[1] - 7, 14, 14);
                g2.setColor(Color.WHITE);
                g2.drawOval(p[0] - 7, p[1] - 7, 14, 14);

                // Label
                g2.setFont(UiTheme.FONT_BADGE);
                g2.setColor(UiTheme.TEXT_PRIMARY);
                g2.drawString(s.getCode(), p[0] + 10, p[1] + 4);
            }
            g2.dispose();
        }
    }

    // ===================================================== Tab 3: Favorites & History (2 Sub-tabs)
    private Component buildFavHistoryTab() {
        JPanel page = new JPanel(new BorderLayout(0, 8));
        page.setBackground(UiTheme.BG_APP);
        page.setBorder(new EmptyBorder(12, 14, 14, 14));

        // Header + 2 sub-tab buttons (Yeu thich | Lich su tham quan)
        JPanel topHeader = new JPanel();
        topHeader.setLayout(new BoxLayout(topHeader, BoxLayout.Y_AXIS));
        topHeader.setOpaque(false);
        topHeader.add(UiTheme.titleLabel(I18n.tr("fav_history.header")));
        topHeader.add(Box.createVerticalStrut(8));

        JPanel subTabBar = new JPanel(new GridLayout(1, 2, 6, 0));
        subTabBar.setOpaque(false);
        subTabBar.setAlignmentX(Component.LEFT_ALIGNMENT);

        favSubTabBtn = UiTheme.primaryButton("♥ " + I18n.tr("fav_history.tab_favorites", 0));
        favSubTabBtn.addActionListener(e -> switchFavHistorySubTab(MainViewModel.SUB_TAB_FAVORITES));

        historySubTabBtn = UiTheme.secondaryButton("🕒 " + I18n.tr("fav_history.tab_history", 0));
        historySubTabBtn.addActionListener(e -> switchFavHistorySubTab(MainViewModel.SUB_TAB_HISTORY));

        subTabBar.add(favSubTabBtn);
        subTabBar.add(historySubTabBtn);
        topHeader.add(subTabBar);

        // Sub-tab 0: Yeu thich
        JPanel favSubPage = new JPanel();
        favSubPage.setLayout(new BoxLayout(favSubPage, BoxLayout.Y_AXIS));
        favSubPage.setBackground(UiTheme.BG_APP);
        favSubPage.add(favSectionTitle);
        favSubPage.add(Box.createVerticalStrut(6));
        favoritesListContainer.setLayout(new BoxLayout(favoritesListContainer, BoxLayout.Y_AXIS));
        favoritesListContainer.setOpaque(false);
        favoritesListContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        favSubPage.add(favoritesListContainer);

        // Sub-tab 1: Lich su tham quan
        JPanel historySubPage = new JPanel();
        historySubPage.setLayout(new BoxLayout(historySubPage, BoxLayout.Y_AXIS));
        historySubPage.setBackground(UiTheme.BG_APP);
        historySubPage.add(historySectionTitle);
        historySubPage.add(Box.createVerticalStrut(4));
        historySubPage.add(UiTheme.wrappingText(I18n.tr("fav_history.readonly_note"),
                UiTheme.FONT_SMALL, UiTheme.TEXT_SECONDARY));
        historySubPage.add(Box.createVerticalStrut(6));
        historyListContainer.setLayout(new BoxLayout(historyListContainer, BoxLayout.Y_AXIS));
        historyListContainer.setOpaque(false);
        historyListContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
        historySubPage.add(historyListContainer);

        favHistorySubHost.setBackground(UiTheme.BG_APP);
        favHistorySubHost.add(UiTheme.verticalScroll(favSubPage), String.valueOf(MainViewModel.SUB_TAB_FAVORITES));
        favHistorySubHost.add(UiTheme.verticalScroll(historySubPage), String.valueOf(MainViewModel.SUB_TAB_HISTORY));

        page.add(topHeader, BorderLayout.NORTH);
        page.add(favHistorySubHost, BorderLayout.CENTER);

        switchFavHistorySubTab(viewModel.getFavHistorySubTab());
        return page;
    }

    public void switchFavHistorySubTab(int subTabIndex) {
        viewModel.setFavHistorySubTab(subTabIndex);
        favHistorySubCardLayout.show(favHistorySubHost, String.valueOf(subTabIndex));
        boolean favActive = (subTabIndex == MainViewModel.SUB_TAB_FAVORITES);
        if (favSubTabBtn != null) {
            favSubTabBtn.setBackground(favActive ? UiTheme.PRIMARY : UiTheme.ACCENT_SOFT);
            favSubTabBtn.setForeground(favActive ? Color.WHITE : UiTheme.PRIMARY_DARK);
        }
        if (historySubTabBtn != null) {
            historySubTabBtn.setBackground(!favActive ? UiTheme.PRIMARY : UiTheme.ACCENT_SOFT);
            historySubTabBtn.setForeground(!favActive ? Color.WHITE : UiTheme.PRIMARY_DARK);
        }
    }

    private void renderFavorites(List<Favorite> favList) {
        String titleText = "♥ " + I18n.tr("fav_history.tab_favorites", favList.size());
        favSectionTitle.setText(titleText);
        if (favSubTabBtn != null) {
            favSubTabBtn.setText(titleText);
        }
        favoritesListContainer.removeAll();
        if (favList.isEmpty()) {
            favoritesListContainer.add(UiTheme.subtitleLabel(I18n.tr("fav_history.empty_favorites")));
        } else {
            for (Favorite fav : favList) {
                JPanel card = new JPanel();
                card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                card.setBackground(UiTheme.BG_CARD);
                card.setBorder(UiTheme.cardBorder());
                card.setAlignmentX(Component.LEFT_ALIGNMENT);

                String artifactName = fav.getArtifact() != null
                        ? fav.getArtifact().getName()
                        : ("#" + fav.getArtifactId());
                String period = fav.getArtifact() != null ? fav.getArtifact().getPeriod() : "";

                card.add(UiTheme.sectionLabel("🏺 " + artifactName));
                if (period != null && !period.isBlank()) {
                    card.add(UiTheme.subtitleLabel(period));
                }
                card.add(Box.createVerticalStrut(6));

                JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
                btnRow.setOpaque(false);
                btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);

                JButton openBtn = UiTheme.primaryButton(I18n.tr("fav_history.open_detail"));
                openBtn.setFont(UiTheme.FONT_BADGE);
                openBtn.addActionListener(e ->
                        navigator.openArtifactDetail(fav.getArtifactId(), VisitHistory.SOURCE_MANUAL));

                JButton removeBtn = UiTheme.dangerButton(I18n.tr("fav_history.remove_btn"));
                removeBtn.setFont(UiTheme.FONT_BADGE);
                removeBtn.addActionListener(e -> viewModel.removeFavorite(fav.getArtifactId()));

                btnRow.add(openBtn);
                btnRow.add(removeBtn);
                card.add(btnRow);

                favoritesListContainer.add(card);
                favoritesListContainer.add(Box.createVerticalStrut(6));
            }
        }
        favoritesListContainer.revalidate();
        favoritesListContainer.repaint();
    }

    private void renderVisitHistory(List<VisitHistory> list) {
        String titleText = "🕒 " + I18n.tr("fav_history.tab_history", list.size());
        historySectionTitle.setText(titleText);
        if (historySubTabBtn != null) {
            historySubTabBtn.setText(titleText);
        }
        historyListContainer.removeAll();
        if (list.isEmpty()) {
            historyListContainer.add(UiTheme.subtitleLabel(I18n.tr("fav_history.empty_history")));
        } else {
            for (VisitHistory vh : list) {
                JPanel card = new JPanel();
                card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                card.setBackground(UiTheme.BG_CARD);
                card.setBorder(UiTheme.cardBorder());
                card.setAlignmentX(Component.LEFT_ALIGNMENT);

                card.add(UiTheme.sectionLabel("🏺 " + vh.getArtifactName()));
                card.add(UiTheme.subtitleLabel("🏛 " + vh.getSiteName()));

                // Nhan phan biet nguon mo: Thu cong (MANUAL) vs Tu Beacon BLE (BEACON_BLE)
                boolean fromBeacon = vh.isFromBeacon();
                JLabel sourceBadge = UiTheme.subtitleLabel(
                        fromBeacon ? I18n.tr("fav_history.source_beacon") : I18n.tr("fav_history.source_manual"));
                sourceBadge.setForeground(fromBeacon ? UiTheme.PRIMARY : UiTheme.SUCCESS);
                card.add(sourceBadge);

                card.add(UiTheme.subtitleLabel(I18n.tr("fav_history.visited_at",
                        vh.getVisitedAt(), vh.getDurationSeconds())));
                card.add(Box.createVerticalStrut(6));

                JButton openBtn = UiTheme.primaryButton(I18n.tr("fav_history.open_detail"));
                openBtn.setFont(UiTheme.FONT_BADGE);
                openBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
                openBtn.addActionListener(e ->
                        navigator.openArtifactDetail(vh.getArtifactId(), vh.getSource()));
                card.add(openBtn);

                historyListContainer.add(card);
                historyListContainer.add(Box.createVerticalStrut(6));
            }
        }
        historyListContainer.revalidate();
        historyListContainer.repaint();
    }

    // ===================================================== Tab 4: Profile & Language
    private Component buildProfileLanguageTab() {
        JPanel page = new JPanel();
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBackground(UiTheme.BG_APP);
        page.setBorder(new EmptyBorder(14, 14, 14, 14));

        page.add(UiTheme.titleLabel(I18n.tr("profile.header")));
        page.add(Box.createVerticalStrut(12));

        // 1. Account & Profile Card
        JPanel profileCard = new JPanel();
        profileCard.setLayout(new BoxLayout(profileCard, BoxLayout.Y_AXIS));
        profileCard.setBackground(UiTheme.BG_CARD);
        profileCard.setBorder(UiTheme.cardBorder());
        profileCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        profileCard.add(UiTheme.sectionLabel("👤 " + I18n.tr("profile.section_account")));
        profileCard.add(Box.createVerticalStrut(8));

        emailValueLabel = UiTheme.subtitleLabel(I18n.tr("profile.email") + ": -");
        roleValueLabel = UiTheme.subtitleLabel(I18n.tr("profile.role") + ": -");
        profileCard.add(emailValueLabel);
        profileCard.add(Box.createVerticalStrut(2));
        profileCard.add(roleValueLabel);
        profileCard.add(Box.createVerticalStrut(8));

        profileCard.add(UiTheme.subtitleLabel(I18n.tr("profile.full_name")));
        profileCard.add(Box.createVerticalStrut(3));
        fullNameField = UiTheme.textField("");
        fullNameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        profileCard.add(fullNameField);
        profileCard.add(Box.createVerticalStrut(8));

        profileCard.add(UiTheme.subtitleLabel(I18n.tr("profile.phone")));
        profileCard.add(Box.createVerticalStrut(3));
        phoneField = UiTheme.textField("");
        phoneField.setAlignmentX(Component.LEFT_ALIGNMENT);
        profileCard.add(phoneField);
        profileCard.add(Box.createVerticalStrut(10));

        saveProfileButton = UiTheme.primaryButton(I18n.tr("profile.save_btn"));
        saveProfileButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        saveProfileButton.addActionListener(e ->
                viewModel.saveProfile(fullNameField.getText(), phoneField.getText()));
        profileCard.add(saveProfileButton);

        page.add(profileCard);
        page.add(Box.createVerticalStrut(12));

        // 2. Language Switcher Card
        JPanel langCard = new JPanel();
        langCard.setLayout(new BoxLayout(langCard, BoxLayout.Y_AXIS));
        langCard.setBackground(UiTheme.ACCENT_SOFT);
        langCard.setBorder(UiTheme.cardBorder());
        langCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        langCard.add(UiTheme.sectionLabel("🌐 " + I18n.tr("profile.section_language")));
        langCard.add(Box.createVerticalStrut(4));
        langCard.add(UiTheme.wrappingText(I18n.tr("profile.language_hint"),
                UiTheme.FONT_SMALL, UiTheme.TEXT_SECONDARY));
        langCard.add(Box.createVerticalStrut(8));

        languageCombo = new JComboBox<>(viewModel.supportedLanguages().toArray(new Language[0]));
        languageCombo.setAlignmentX(Component.LEFT_ALIGNMENT);
        languageCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        selectLanguageInCombo(viewModel.currentLanguage());
        languageCombo.addActionListener(e -> {
            if (suppressLanguageComboEvent) {
                return;
            }
            Language selected = (Language) languageCombo.getSelectedItem();
            if (selected != null) {
                viewModel.changeLanguage(selected.getCode());
            }
        });
        langCard.add(languageCombo);
        langCard.add(Box.createVerticalStrut(8));

        // Quick 1-tap VI / EN buttons
        JPanel quickLangRow = new JPanel(new GridLayout(1, 2, 8, 0));
        quickLangRow.setOpaque(false);
        quickLangRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton viBtn = UiTheme.secondaryButton("Tiếng Việt (vi)");
        viBtn.addActionListener(e -> viewModel.changeLanguage("vi"));
        JButton enBtn = UiTheme.secondaryButton("English (en)");
        enBtn.addActionListener(e -> viewModel.changeLanguage("en"));
        quickLangRow.add(viBtn);
        quickLangRow.add(enBtn);
        langCard.add(quickLangRow);

        page.add(langCard);
        page.add(Box.createVerticalStrut(12));

        // 3. Session & AuthInterceptor Verification Card
        JPanel secCard = new JPanel();
        secCard.setLayout(new BoxLayout(secCard, BoxLayout.Y_AXIS));
        secCard.setBackground(UiTheme.BG_CARD);
        secCard.setBorder(UiTheme.cardBorder());
        secCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        secCard.add(UiTheme.sectionLabel("🔐 " + I18n.tr("profile.section_security")));
        secCard.add(Box.createVerticalStrut(4));
        secCard.add(UiTheme.subtitleLabel(I18n.tr("profile.token_status")));
        secCard.add(Box.createVerticalStrut(8));

        if (viewModel.hasMockBackend()) {
            JButton simExpireBtn = UiTheme.secondaryButton(I18n.tr("profile.simulate_expire"));
            simExpireBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            simExpireBtn.addActionListener(e -> viewModel.simulateTokenExpiryAndVerifyRefresh());
            secCard.add(simExpireBtn);
            secCard.add(Box.createVerticalStrut(8));
        }

        JButton logoutBtn = UiTheme.dangerButton(I18n.tr("profile.logout_btn"));
        logoutBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutBtn.addActionListener(e -> viewModel.logout());
        secCard.add(logoutBtn);

        page.add(secCard);
        return UiTheme.verticalScroll(page);
    }

    private void selectLanguageInCombo(String code) {
        if (languageCombo == null || code == null) {
            return;
        }
        suppressLanguageComboEvent = true;
        try {
            for (int i = 0; i < languageCombo.getItemCount(); i++) {
                if (languageCombo.getItemAt(i).getCode().equalsIgnoreCase(code)) {
                    languageCombo.setSelectedIndex(i);
                    break;
                }
            }
        } finally {
            suppressLanguageComboEvent = false;
        }
    }

    private void bindUser(User u) {
        if (u == null) {
            return;
        }
        emailValueLabel.setText(I18n.tr("profile.email") + ": " + u.getEmail());
        String roleName = u.getRole() != null ? u.getRole().getName() : "VISITOR";
        roleValueLabel.setText(I18n.tr("profile.role") + ": " + roleName);
        if (fullNameField != null) {
            fullNameField.setText(u.getFullName() == null ? "" : u.getFullName());
        }
        if (phoneField != null) {
            phoneField.setText(u.getPhone() == null ? "" : u.getPhone());
        }
        selectLanguageInCombo(viewModel.currentLanguage());
    }

    @Override
    public void onShow() {
        observe(viewModel.sitesUiState(), this::renderSitesState);
        observe(viewModel.sites(), list -> {
            if (mapCanvas != null) {
                mapCanvas.setSites(list);
            }
        });
        observe(viewModel.locationPermissionGranted(), granted ->
                renderGpsPermissionState(Boolean.TRUE.equals(granted)));
        observe(viewModel.selectedSiteArtifacts(), this::renderMapSiteArtifacts);
        observe(viewModel.selectedArtifact(), this::renderArtifactDetail);
        observe(viewModel.lastBeaconEvent(), ev -> {
            if (ev != null) {
                bleEventLabel.setText(I18n.tr("explore.ble_event",
                        ev.getBeaconId(), ev.getEventType(), ev.getRssi()));
            }
        });
        observe(viewModel.favorites(), favList -> {
            renderFavorites(favList);
            if (viewModel.selectedArtifact().getValue() != null) {
                renderArtifactDetail(viewModel.selectedArtifact().getValue());
            }
        });
        observe(viewModel.visitHistory(), this::renderVisitHistory);
        observe(viewModel.user(), this::bindUser);
        observe(viewModel.busy(), isBusy -> {
            boolean b = Boolean.TRUE.equals(isBusy);
            if (saveProfileButton != null) {
                saveProfileButton.setEnabled(!b);
                saveProfileButton.setText(b ? I18n.tr("profile.saving") : I18n.tr("profile.save_btn"));
            }
        });
        observe(viewModel.toastEvent(), ev -> {
            String msg = ev.getIfNotHandled();
            if (msg != null) {
                navigator.showToast(msg, false);
            }
        });
        observe(viewModel.errorEvent(), ev -> {
            String msg = ev.getIfNotHandled();
            if (msg != null) {
                navigator.showToast(msg, true);
            }
        });
        observe(viewModel.loggedOutEvent(), ev -> {
            Boolean out = ev.getIfNotHandled();
            if (Boolean.TRUE.equals(out)) {
                navigator.navigateTo(Navigator.Route.LOGIN);
            }
        });

        viewModel.ensureLoaded();
    }
}
