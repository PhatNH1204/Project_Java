package com.heritage.tv2.api;

import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.model.AuthTokens;

import java.io.IOException;
import java.util.Set;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Interceptor xac thuc cua OkHttp.
 *
 * <ol>
 *     <li>Gan {@code Accept-Language: <lang>} cho MOI request (lay tu {@link SessionStorage}).</li>
 *     <li>Gan {@code Authorization: Bearer <accessToken>} cho cac endpoint can xac thuc
 *     (bo qua login/register/refresh).</li>
 *     <li>Khi nhan {@code 401} tu endpoint can xac thuc: dung refresh token de lay token moi
 *     (dong bo hoa - nhieu request 401 cung luc chi refresh <b>1 lan</b>) roi gui lai request.</li>
 *     <li>Neu refresh that bai (refresh token het han / bi thu hoi): xoa phien va goi
 *     {@link SessionExpiredListener} de UI dieu huong ve man hinh Dang nhap.</li>
 * </ol>
 *
 * <p>Loi mang trong luc refresh ({@link IOException}) duoc nem lai, KHONG xoa phien -
 * tranh dang xuat nguoi dung chi vi mat mang tam thoi.</p>
 */
public class AuthInterceptor implements Interceptor {

    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String HEADER_ACCEPT_LANGUAGE = "Accept-Language";
    public static final String BEARER_PREFIX = "Bearer ";

    /** Endpoint cong khai: khong gan token, khong refresh khi 401. */
    private static final Set<String> PUBLIC_PATHS = Set.of(
            "/" + HeritageApiService.PATH_LOGIN,
            "/" + HeritageApiService.PATH_REGISTER,
            "/" + HeritageApiService.PATH_REFRESH);

    /** Endpoint co gan token nhung 401 khong kich hoat refresh (vd: logout). */
    private static final Set<String> NO_REFRESH_PATHS = Set.of(
            "/" + HeritageApiService.PATH_LOGOUT);

    /** Goi {@code POST /api/auth/refresh} (phai dung client KHONG co AuthInterceptor). */
    @FunctionalInterface
    public interface TokenRefresher {
        /**
         * @return token moi, hoac {@code null} neu refresh token bi tu choi (400/401/403)
         * @throws IOException loi mang / server tam thoi (5xx)
         */
        AuthTokens refresh(String refreshToken) throws IOException;
    }

    /** Callback khi phien het han khong the khoi phuc -> dieu huong ve Login. */
    @FunctionalInterface
    public interface SessionExpiredListener {
        void onSessionExpired();
    }

    private final SessionStorage sessionStorage;
    private final TokenRefresher tokenRefresher;
    private final SessionExpiredListener sessionExpiredListener;
    private final Object refreshLock = new Object();

    public AuthInterceptor(SessionStorage sessionStorage,
                           TokenRefresher tokenRefresher,
                           SessionExpiredListener sessionExpiredListener) {
        this.sessionStorage = sessionStorage;
        this.tokenRefresher = tokenRefresher;
        this.sessionExpiredListener = sessionExpiredListener != null ? sessionExpiredListener : () -> { };
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request original = chain.request();
        String path = original.url().encodedPath();
        boolean isPublic = matches(PUBLIC_PATHS, path);

        String accessToken = isPublic ? null : sessionStorage.getAccessToken();
        Response response = chain.proceed(decorate(original, accessToken, isPublic));

        if (response.code() != 401 || isPublic || matches(NO_REFRESH_PATHS, path)) {
            return response;
        }

        // ---- 401 tren endpoint can xac thuc ----
        String newToken = refreshAccessToken(accessToken, response);
        if (newToken == null) {
            expireSession();
            return response;
        }
        response.close();

        Response retried = chain.proceed(decorate(original, newToken, false));
        if (retried.code() == 401) {
            // Token vua refresh van bi tu choi -> phien khong con hop le.
            expireSession();
        }
        return retried;
    }

    /** So khop theo hau to de ho tro base URL co context-path (vd: http://host/backend/). */
    private static boolean matches(Set<String> paths, String encodedPath) {
        for (String p : paths) {
            if (encodedPath.endsWith(p)) {
                return true;
            }
        }
        return false;
    }

    /** Gan header Accept-Language (+ Authorization neu co token). */
    private Request decorate(Request original, String accessToken, boolean isPublic) {
        Request.Builder builder = original.newBuilder()
                .header(HEADER_ACCEPT_LANGUAGE, sessionStorage.getLanguage());
        if (!isPublic && accessToken != null) {
            builder.header(HEADER_AUTHORIZATION, BEARER_PREFIX + accessToken);
        }
        return builder.build();
    }

    /**
     * Lam moi access token mot cach dong bo.
     *
     * @param failedToken token da gui di va bi 401 (co the null)
     * @return access token hop le de thu lai, hoac {@code null} neu khong the khoi phuc phien
     */
    private String refreshAccessToken(String failedToken, Response failedResponse) throws IOException {
        synchronized (refreshLock) {
            String current = sessionStorage.getAccessToken();
            if (current != null && !current.equals(failedToken)) {
                // Thread khac da refresh xong trong luc ta cho -> dung luon token moi.
                return current;
            }
            String refreshToken = sessionStorage.getRefreshToken();
            if (refreshToken == null || tokenRefresher == null) {
                return null;
            }
            AuthTokens tokens;
            try {
                tokens = tokenRefresher.refresh(refreshToken);
            } catch (IOException e) {
                failedResponse.close();
                throw e;
            }
            if (tokens == null || !tokens.hasAccessToken()) {
                return null;
            }
            sessionStorage.saveTokens(tokens);
            return tokens.getAccessToken();
        }
    }

    private void expireSession() {
        boolean hadSession = sessionStorage.isLoggedIn();
        sessionStorage.clearSession();
        if (hadSession) {
            sessionExpiredListener.onSessionExpired();
        }
    }
}
