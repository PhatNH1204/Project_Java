package com.heritage.tv2.api;

import com.heritage.tv2.model.ApiResponse;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.model.request.LoginRequest;
import com.heritage.tv2.model.request.RefreshTokenRequest;
import com.heritage.tv2.model.request.RegisterRequest;
import com.heritage.tv2.model.request.UpdateProfileRequest;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Retrofit2 API Contract cua phan he TV2 (Visitor Mobile App - Tich hop Tuan 5-6).
 *
 * <p>Khop 100% duong dan, HTTP method va query param trong Swagger/OpenAPI cua TV1, TV3, TV4, TV5.
 * Header {@code Authorization} va {@code Accept-Language} duoc {@link AuthInterceptor}
 * tu dong dinh kem cho moi request.</p>
 */
public interface HeritageApiService {

    // ------------------------------------------------------------------ Auth (TV1)
    String PATH_LOGIN = "api/auth/login";
    String PATH_REGISTER = "api/auth/register";
    String PATH_REFRESH = "api/auth/refresh";
    String PATH_LOGOUT = "api/auth/logout";

    @POST(PATH_LOGIN)
    Call<ApiResponse<AuthTokens>> login(@Body LoginRequest request);

    @POST(PATH_REGISTER)
    Call<ApiResponse<AuthTokens>> register(@Body RegisterRequest request);

    @POST(PATH_REFRESH)
    Call<ApiResponse<AuthTokens>> refresh(@Body RefreshTokenRequest request);

    @POST(PATH_LOGOUT)
    Call<ApiResponse<Void>> logout(@Body RefreshTokenRequest request);

    // ------------------------------------------------------------------ User (TV1)
    @GET("api/users/me")
    Call<ApiResponse<User>> getMe();

    /** Cap nhat ho so &amp; {@code preferredLanguage}. */
    @PUT("api/users/me")
    Call<ApiResponse<User>> updateMe(@Body UpdateProfileRequest request);

    // --------------------------------------------------------------- Content (TV4 & TV3)
    @GET("api/sites")
    Call<ApiResponse<List<HeritageSite>>> getSites(
            @Query("search") String search,
            @Query("category") String category,
            @Query("lang") String lang);

    default Call<ApiResponse<List<HeritageSite>>> getSites() {
        return getSites(null, null, null);
    }

    @GET("api/sites/{id}/artifacts")
    Call<ApiResponse<List<Artifact>>> getSiteArtifacts(
            @Path("id") long siteId,
            @Query("lang") String lang);

    default Call<ApiResponse<List<Artifact>>> getSiteArtifacts(long siteId) {
        return getSiteArtifacts(siteId, null);
    }

    @GET("api/artifacts/{id}")
    Call<ApiResponse<Artifact>> getArtifact(
            @Path("id") long artifactId,
            @Query("lang") String lang);

    default Call<ApiResponse<Artifact>> getArtifact(long artifactId) {
        return getArtifact(artifactId, null);
    }

    /**
     * Noi dung hien vat gan voi beacon: {@code GET /api/beacons/{id}/content?lang={lang}} (API TV3 + TV4).
     */
    @GET("api/beacons/{id}/content")
    Call<ApiResponse<Artifact>> getBeaconContent(
            @Path("id") String beaconId,
            @Query("lang") String lang);

    default Call<ApiResponse<Artifact>> getBeaconContent(String beaconId) {
        return getBeaconContent(beaconId, null);
    }

    // ------------------------------------------------------------ Favorites (TV2/TV5)
    @GET("api/favorites")
    Call<ApiResponse<List<Favorite>>> getFavorites(@Query("lang") String lang);

    default Call<ApiResponse<List<Favorite>>> getFavorites() {
        return getFavorites(null);
    }

    @POST("api/favorites/{artifactId}")
    Call<ApiResponse<Favorite>> addFavorite(@Path("artifactId") long artifactId);

    @DELETE("api/favorites/{artifactId}")
    Call<ApiResponse<Void>> removeFavorite(@Path("artifactId") long artifactId);

    // -------------------------------------------------------- Visit history (TV2/TV3/TV5)
    @GET("api/visit-history")
    Call<ApiResponse<List<VisitHistory>>> getVisitHistory(
            @Query("page") Integer page,
            @Query("size") Integer size,
            @Query("lang") String lang);

    default Call<ApiResponse<List<VisitHistory>>> getVisitHistory() {
        return getVisitHistory(null, null, null);
    }

    // ------------------------------------------------------------- Feedback (TV2/TV5)
    @POST("api/feedback")
    Call<ApiResponse<Void>> submitFeedback(@Body FeedbackRequest request);
}
