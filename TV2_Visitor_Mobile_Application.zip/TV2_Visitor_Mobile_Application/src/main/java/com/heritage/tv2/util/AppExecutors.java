package com.heritage.tv2.util;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import javax.swing.SwingUtilities;

/**
 * Bo executor cua app (tuong duong Dispatchers.IO / Main ben Android).
 * <ul>
 *     <li>{@link #io()}: chay network / disk (khong bao gio tren EDT).</li>
 *     <li>{@link #main()}: day ket qua ve Swing Event Dispatch Thread.</li>
 * </ul>
 * Unit test dung {@link #direct()} de chay dong bo.
 */
public final class AppExecutors {

    private final Executor io;
    private final Executor main;

    public AppExecutors(Executor io, Executor main) {
        this.io = io;
        this.main = main;
    }

    public static AppExecutors swing() {
        AtomicInteger counter = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(4, r -> {
            Thread t = new Thread(r, "tv2-io-" + counter.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
        return new AppExecutors(pool, command -> {
            if (SwingUtilities.isEventDispatchThread()) {
                command.run();
            } else {
                SwingUtilities.invokeLater(command);
            }
        });
    }

    /** Chay moi thu ngay tren thread goi - cho Unit Test. */
    public static AppExecutors direct() {
        Executor direct = Runnable::run;
        return new AppExecutors(direct, direct);
    }

    public Executor io() {
        return io;
    }

    public Executor main() {
        return main;
    }
}
