package com.heritage.tv2.ui.auth;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.User;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.theme.UiTheme;
import com.heritage.tv2.util.I18n;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 * Man hinh Dang nhap:
 * <ul>
 *     <li>Nhap email / mat khau va goi {@code POST /api/auth/login}.</li>
 *     <li>Chon nhanh tai khoan demo da ngon ngu ({@code vi} / {@code en}) khi {@code USE_MOCK_DATA = true}.</li>
 *     <li>Chuyen sang man hinh Dang ky ({@link RegisterScreen}) hoac doi ngon ngu ngay tren man hinh.</li>
 * </ul>
 */
public class LoginScreen extends Screen {

    private final LoginViewModel viewModel;
    private final Navigator navigator;

    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton submitButton;

    public LoginScreen(LoginViewModel viewModel, Navigator navigator) {
        this.viewModel = viewModel;
        this.navigator = navigator;
        buildUi();
    }

    private void buildUi() {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UiTheme.BG_APP);
        content.setBorder(new EmptyBorder(24, 20, 24, 20));

        // Header
        JLabel appTitle = UiTheme.titleLabel("🏛 " + I18n.tr("app.title"));
        Component subtitle = UiTheme.wrappingText(I18n.tr("login.subtitle"), UiTheme.FONT_SMALL, UiTheme.TEXT_SECONDARY);

        content.add(appTitle);
        content.add(Box.createVerticalStrut(4));
        content.add(subtitle);
        content.add(Box.createVerticalStrut(16));

        // Card form dang nhap
        JPanel formCard = new JPanel();
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
        formCard.setBackground(UiTheme.BG_CARD);
        formCard.setBorder(UiTheme.cardBorder());
        formCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        formCard.add(UiTheme.sectionLabel(I18n.tr("login.title")));
        formCard.add(Box.createVerticalStrut(12));

        formCard.add(UiTheme.subtitleLabel(I18n.tr("login.email")));
        formCard.add(Box.createVerticalStrut(4));
        emailField = UiTheme.textField(MockBackendInterceptor.DEMO_EMAIL);
        emailField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(emailField);
        formCard.add(Box.createVerticalStrut(10));

        formCard.add(UiTheme.subtitleLabel(I18n.tr("login.password")));
        formCard.add(Box.createVerticalStrut(4));
        passwordField = UiTheme.passwordField();
        passwordField.setText(MockBackendInterceptor.DEMO_PASSWORD);
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(passwordField);
        formCard.add(Box.createVerticalStrut(14));

        submitButton = UiTheme.primaryButton(I18n.tr("login.submit"));
        submitButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        submitButton.addActionListener(e -> doLogin());
        formCard.add(submitButton);

        content.add(formCard);
        content.add(Box.createVerticalStrut(14));

        // Khu vuc 1-cham tai khoan demo (Mock mode)
        if (AppConfig.USE_MOCK_DATA) {
            JPanel demoCard = new JPanel();
            demoCard.setLayout(new BoxLayout(demoCard, BoxLayout.Y_AXIS));
            demoCard.setBackground(UiTheme.ACCENT_SOFT);
            demoCard.setBorder(UiTheme.cardBorder());
            demoCard.setAlignmentX(Component.LEFT_ALIGNMENT);

            demoCard.add(UiTheme.subtitleLabel(I18n.tr("login.demo_section")));
            demoCard.add(Box.createVerticalStrut(6));

            JPanel btnRow = new JPanel(new GridLayout(1, 2, 8, 0));
            btnRow.setOpaque(false);
            btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);

            JButton viDemo = UiTheme.secondaryButton(I18n.tr("login.demo_vi"));
            viDemo.addActionListener(e -> {
                emailField.setText(MockBackendInterceptor.DEMO_EMAIL);
                passwordField.setText(MockBackendInterceptor.DEMO_PASSWORD);
                doLogin();
            });

            JButton enDemo = UiTheme.secondaryButton(I18n.tr("login.demo_en"));
            enDemo.addActionListener(e -> {
                emailField.setText(MockBackendInterceptor.DEMO_EMAIL_EN);
                passwordField.setText(MockBackendInterceptor.DEMO_PASSWORD);
                doLogin();
            });

            btnRow.add(viDemo);
            btnRow.add(enDemo);
            demoCard.add(btnRow);
            content.add(demoCard);
            content.add(Box.createVerticalStrut(14));
        }

        // Doi ngon ngu nhanh tren man hinh Login
        JPanel langPanel = new JPanel(new BorderLayout(8, 0));
        langPanel.setOpaque(false);
        langPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        langPanel.add(UiTheme.subtitleLabel(I18n.tr("login.language_label")), BorderLayout.WEST);

        JComboBox<Language> langCombo = new JComboBox<>(
                viewModel.supportedLanguages().toArray(new Language[0]));
        for (int i = 0; i < langCombo.getItemCount(); i++) {
            if (langCombo.getItemAt(i).getCode().equalsIgnoreCase(viewModel.currentLanguage())) {
                langCombo.setSelectedIndex(i);
                break;
            }
        }
        langCombo.addActionListener(e -> {
            Language selected = (Language) langCombo.getSelectedItem();
            if (selected != null && !selected.getCode().equalsIgnoreCase(viewModel.currentLanguage())) {
                viewModel.switchLanguage(selected.getCode());
            }
        });
        langPanel.add(langCombo, BorderLayout.CENTER);
        content.add(langPanel);
        content.add(Box.createVerticalStrut(16));

        // Link sang Dang ky
        JPanel regRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        regRow.setOpaque(false);
        regRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        regRow.add(UiTheme.subtitleLabel(I18n.tr("login.no_account")));
        JButton goRegister = UiTheme.secondaryButton(I18n.tr("login.go_register"));
        goRegister.addActionListener(e -> navigator.navigateTo(Navigator.Route.REGISTER));
        regRow.add(goRegister);
        content.add(regRow);

        add(UiTheme.verticalScroll(content), BorderLayout.CENTER);
    }

    private void doLogin() {
        viewModel.login(emailField.getText(), new String(passwordField.getPassword()));
    }

    @Override
    public void onShow() {
        observe(viewModel.loading(), isLoading -> {
            boolean busy = Boolean.TRUE.equals(isLoading);
            submitButton.setEnabled(!busy);
            submitButton.setText(busy ? I18n.tr("login.submitting") : I18n.tr("login.submit"));
        });
        observe(viewModel.errorEvent(), event -> {
            String msg = event.getIfNotHandled();
            if (msg != null) {
                navigator.showToast(msg, true);
            }
        });
        observe(viewModel.loginSuccess(), event -> {
            User user = event.getIfNotHandled();
            if (user != null) {
                navigator.navigateTo(Navigator.Route.MAIN);
            }
        });
    }
}
