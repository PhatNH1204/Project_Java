package com.heritage.tv2.cache;

import java.io.IOException;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.Properties;

/**
 * Kho key-value luu xuong file {@code .properties} (UTF-8), ghi atomic qua file tam.
 *
 * <p>Ghi chu bao mat: ban desktop/Swing luu token dang plain-text trong thu muc nguoi dung.
 * Khi port sang Android se thay bang {@code EncryptedSharedPreferences} ma khong doi API
 * {@link SessionStorage}.</p>
 */
public class FileKeyValueStore implements KeyValueStore {

    private final Path file;
    private final Properties props = new Properties();

    public FileKeyValueStore(Path file) {
        this.file = file;
        load();
    }

    private void load() {
        if (!Files.exists(file)) {
            return;
        }
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            props.load(reader);
        } catch (IOException | IllegalArgumentException e) {
            // File hong -> bo qua, coi nhu phien moi.
            props.clear();
        }
    }

    @Override
    public synchronized String get(String key) {
        return props.getProperty(key);
    }

    @Override
    public synchronized void putAll(Map<String, String> values) {
        values.forEach((k, v) -> {
            if (v == null) {
                props.remove(k);
            } else {
                props.setProperty(k, v);
            }
        });
        persist();
    }

    private void persist() {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            try (Writer writer = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                props.store(writer, "Heritage TV2 session - do not edit");
            }
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicNotSupported) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Khong the luu session: " + file, e);
        }
    }

    public Path getFile() {
        return file;
    }
}
