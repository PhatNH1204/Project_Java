package com.heritage.tv2.ble;

/**
 * Hook phoi hop ghi nhan {@code Interaction} giua TV2 va TV3.
 *
 * <p>De tranh viec TV2 tu tao ban ghi {@code Interaction} trung lap voi TV3, TV2 cung cap
 * callback nay de thong bao cho module TV3 biet:</p>
 * <ol>
 *     <li>Thoi diem khach tham quan thuc su bam "Xem ngay" va mo noi dung hien vat tu goi y beacon.</li>
 *     <li>Thoi luong xem thuc te (giay) khi khach dong man hinh chi tiet hoac chuyen sang hien vat khac.</li>
 * </ol>
 * <p>Module TV3 dang ky implementation cua interface nay qua
 * {@link BleBridgeCoordinator#setInteractionCallback(InteractionCallback)}.</p>
 */
public interface InteractionCallback {

    /**
     * Goi ngay khi khach tham quan bam "Xem ngay" va mo man hinh {@code ArtifactDetail} tu beacon.
     *
     * @param beaconId          ma beacon kich hoat
     * @param artifactId        ID hien vat duoc mo
     * @param openedAtEpochMs   thoi diem mo (epoch millis)
     */
    void onContentOpened(String beaconId, long artifactId, long openedAtEpochMs);

    /**
     * Goi khi khach ket thuc luot xem hien vat duoc mo tu beacon.
     *
     * @param beaconId          ma beacon kich hoat
     * @param artifactId        ID hien vat da xem
     * @param openedAtEpochMs   thoi diem bat dau mo (epoch millis)
     * @param durationSeconds   thoi luong xem thuc te (giay, &gt;= 1)
     */
    void onContentViewed(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds);
}
