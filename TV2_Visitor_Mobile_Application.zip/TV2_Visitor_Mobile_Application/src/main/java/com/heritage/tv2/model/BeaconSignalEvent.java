package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Su kien tin hieu beacon - khop DTO {@code BeaconSignalEvent} cua TV3.
 */
public class BeaconSignalEvent {

    /** Loai su kien vung beacon. */
    public enum EventType {
        ENTER,
        EXIT,
        SWITCH
    }

    @SerializedName(value = "beaconId", alternate = {"beacon_id", "beaconCode", "beacon_code", "id"})
    private String beaconId;

    @SerializedName(value = "uuid", alternate = {"proximityUuid", "proximity_uuid"})
    private String uuid;

    @SerializedName(value = "major")
    private int major;

    @SerializedName(value = "minor")
    private int minor;

    /** Cuong do tin hieu (dBm, am). */
    @SerializedName(value = "rssi", alternate = {"filteredRssi", "filtered_rssi", "signalStrength"})
    private int rssi;

    @SerializedName(value = "eventType", alternate = {"event_type", "type", "transitionType"})
    private EventType eventType;

    /** Epoch millis (UTC). */
    @SerializedName(value = "timestamp", alternate = {"detectedAt", "detected_at", "eventTime"})
    private long timestamp;

    public BeaconSignalEvent() {
    }

    public BeaconSignalEvent(String beaconId, String uuid, int major, int minor, int rssi,
                             EventType eventType, long timestamp) {
        this.beaconId = beaconId;
        this.uuid = uuid;
        this.major = major;
        this.minor = minor;
        this.rssi = rssi;
        this.eventType = eventType;
        this.timestamp = timestamp;
    }

    public String getBeaconId() {
        return beaconId;
    }

    public void setBeaconId(String beaconId) {
        this.beaconId = beaconId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getMajor() {
        return major;
    }

    public void setMajor(int major) {
        this.major = major;
    }

    public int getMinor() {
        return minor;
    }

    public void setMinor(int minor) {
        this.minor = minor;
    }

    public int getRssi() {
        return rssi;
    }

    public void setRssi(int rssi) {
        this.rssi = rssi;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "BeaconSignalEvent{" + eventType + " " + beaconId + " rssi=" + rssi + '}';
    }
}
