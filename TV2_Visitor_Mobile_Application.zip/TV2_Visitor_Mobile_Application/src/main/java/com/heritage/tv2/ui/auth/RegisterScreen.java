package com.heritage.tv2.ui.auth;

import com.heritage.tv2.model.User;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.theme.UiTheme;
import com.heritage.tv2.util.I18n;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 * Man hinh Dang ky tai khoan moi ({@code POST /api/auth/register}).
 */
public class RegisterScreen extends Screen {

    private final RegisterViewModel viewModel;
    private final Navigator navigator;

    private JTextField nameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JPasswordField confirmField;
    private JButton submitButton;

    public RegisterScreen(RegisterViewModel viewModel, Navigator navigator) {
        this.viewModel = viewModel;
        this.navigator = navigator;
        buildUi();
    }

    private void buildUi() {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UiTheme.BG_APP);
        content.setBorder(new EmptyBorder(24, 20, 24, 20));

        content.add(UiTheme.titleLabel(I18n.tr("register.title")));
        content.add(Box.createVerticalStrut(4));
        content.add(UiTheme.subtitleLabel(I18n.tr("register.subtitle")));
        content.add(Box.createVerticalStrut(16));

        JPanel formCard = new JPanel();
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
        formCard.setBackground(UiTheme.BG_CARD);
        formCard.setBorder(UiTheme.cardBorder());
        formCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        formCard.add(UiTheme.subtitleLabel(I18n.tr("register.full_name")));
        formCard.add(Box.createVerticalStrut(4));
        nameField = UiTheme.textField("");
        nameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(nameField);
        formCard.add(Box.createVerticalStrut(10));

        formCard.add(UiTheme.subtitleLabel(I18n.tr("register.email")));
        formCard.add(Box.createVerticalStrut(4));
        emailField = UiTheme.textField("");
        emailField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(emailField);
        formCard.add(Box.createVerticalStrut(10));

        formCard.add(UiTheme.subtitleLabel(I18n.tr("register.password")));
        formCard.add(Box.createVerticalStrut(4));
        passwordField = UiTheme.passwordField();
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(passwordField);
        formCard.add(Box.createVerticalStrut(10));

        formCard.add(UiTheme.subtitleLabel(I18n.tr("register.confirm_password")));
        formCard.add(Box.createVerticalStrut(4));
        confirmField = UiTheme.passwordField();
        confirmField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(confirmField);
        formCard.add(Box.createVerticalStrut(14));

        submitButton = UiTheme.primaryButton(I18n.tr("register.submit"));
        submitButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        submitButton.addActionListener(e -> viewModel.register(
                nameField.getText(),
                emailField.getText(),
                new String(passwordField.getPassword()),
                new String(confirmField.getPassword())));
        formCard.add(submitButton);

        content.add(formCard);
        content.add(Box.createVerticalStrut(16));

        JPanel backRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        backRow.setOpaque(false);
        backRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        backRow.add(UiTheme.subtitleLabel(I18n.tr("register.have_account")));
        JButton goLogin = UiTheme.secondaryButton(I18n.tr("register.go_login"));
        goLogin.addActionListener(e -> navigator.navigateTo(Navigator.Route.LOGIN));
        backRow.add(goLogin);
        content.add(backRow);

        add(UiTheme.verticalScroll(content), BorderLayout.CENTER);
    }

    @Override
    public void onShow() {
        observe(viewModel.loading(), isLoading -> {
            boolean busy = Boolean.TRUE.equals(isLoading);
            submitButton.setEnabled(!busy);
            submitButton.setText(busy ? I18n.tr("register.submitting") : I18n.tr("register.submit"));
        });
        observe(viewModel.errorEvent(), event -> {
            String msg = event.getIfNotHandled();
            if (msg != null) {
                navigator.showToast(msg, true);
            }
        });
        observe(viewModel.registerSuccess(), event -> {
            User user = event.getIfNotHandled();
            if (user != null) {
                navigator.navigateTo(Navigator.Route.MAIN);
            }
        });
    }
}
