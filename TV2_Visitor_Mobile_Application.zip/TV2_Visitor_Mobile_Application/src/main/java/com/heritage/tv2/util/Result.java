package com.heritage.tv2.util;

/**
 * Ket qua mot thao tac repository: thanh cong (co data) hoac loi (co ma loi + thong diep).
 *
 * <p>Ma loi phia client: {@link #CODE_NETWORK}, {@link #CODE_PARSE}, {@link #CODE_UNKNOWN},
 * {@link #CODE_VALIDATION}; con lai la {@code error.code} do backend tra ve.</p>
 */
public final class Result<T> {

    public static final String CODE_NETWORK = "NETWORK_ERROR";
    public static final String CODE_PARSE = "PARSE_ERROR";
    public static final String CODE_UNKNOWN = "UNKNOWN_ERROR";
    public static final String CODE_VALIDATION = "VALIDATION_ERROR";
    public static final String CODE_UNAUTHORIZED = "UNAUTHORIZED";

    private final boolean success;
    private final T data;
    private final String errorCode;
    private final String errorMessage;
    private final int httpStatus;
    private final Throwable cause;

    private Result(boolean success, T data, String errorCode, String errorMessage, int httpStatus, Throwable cause) {
        this.success = success;
        this.data = data;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.httpStatus = httpStatus;
        this.cause = cause;
    }

    public static <T> Result<T> success(T data) {
        return new Result<>(true, data, null, null, 200, null);
    }

    public static <T> Result<T> error(String code, String message, int httpStatus) {
        return new Result<>(false, null, code == null ? CODE_UNKNOWN : code, message, httpStatus, null);
    }

    public static <T> Result<T> networkError(Throwable cause) {
        return new Result<>(false, null, CODE_NETWORK, cause == null ? null : cause.getMessage(), 0, cause);
    }

    /** Chuyen loi sang kieu khac (giu nguyen ma loi). */
    public <R> Result<R> castError() {
        if (success) {
            throw new IllegalStateException("Result is success");
        }
        return new Result<>(false, null, errorCode, errorMessage, httpStatus, cause);
    }

    public boolean isSuccess() {
        return success;
    }

    public T getData() {
        return data;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public int getHttpStatus() {
        return httpStatus;
    }

    public Throwable getCause() {
        return cause;
    }

    public boolean isNetworkError() {
        return CODE_NETWORK.equals(errorCode);
    }

    public boolean isUnauthorized() {
        return !success && httpStatus == 401;
    }

    @Override
    public String toString() {
        return success ? "Result.success(" + data + ")"
                : "Result.error(" + errorCode + ", " + httpStatus + ", " + errorMessage + ")";
    }
}
