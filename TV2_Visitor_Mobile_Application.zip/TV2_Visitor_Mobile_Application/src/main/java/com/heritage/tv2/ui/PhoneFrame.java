package com.heritage.tv2.ui;

import com.heritage.tv2.ble.BleBridgeCoordinator;
import com.heritage.tv2.ble.BleDebugSimulator;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.sql.SqlDatabaseInspectorDialog;
import com.heritage.tv2.ui.theme.UiTheme;
import com.heritage.tv2.util.I18n;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

/**
 * Khung gia lap dien thoai di dong kich thuoc chuan 390x844 (iPhone 13/14 viewport).
 *
 * <p>Bao gom:</p>
 * <ul>
 *     <li>Thanh trang thai (Status bar) phia tren: gio, huy hieu MOCK/LIVE va ngon ngu hien tai (VI/EN).</li>
 *     <li>Banner canh bao BLE khi Bluetooth dang tat hoac thieu quyen (nhung van cho dung app thu cong).</li>
 *     <li>Thanh thong bao nhanh (Toast banner) tu dong an sau 3.5 giay.</li>
 *     <li>Khu vuc noi dung chinh do {@link Navigator} dieu phoi.</li>
 *     <li>Banner/BottomSheet goi y Beacon khong gay gian doan (<i>"Phat hien hien vat gan ban — Xem ngay / Bo qua"</i>).</li>
 *     <li>Panel cong cu <b>BLE Debug Simulator</b> (4 kich ban test chuan Gate 4) khi {@code DEBUG}
 *     hoac {@code ENABLE_BLE_SIMULATOR = true}.</li>
 * </ul>
 */
public final class PhoneFrame extends JFrame {

    private final AppContainer container;
    private final JPanel screenContainer = new JPanel(new BorderLayout());
    private final JPanel toastPanel = new JPanel(new BorderLayout());
    private final JLabel toastLabel = new JLabel();
    private final JPanel bleWarningPanel = new JPanel(new BorderLayout(6, 0));
    private final JLabel bleWarningLabel = new JLabel();
    private final JPanel beaconPromptSheet = new JPanel(new BorderLayout(8, 6));
    private final JLabel beaconPromptLabel = new JLabel();
    private final JLabel langBadge = new JLabel("VI");
    private final JLabel modeBadge = new JLabel();
    private final Navigator navigator;
    private SqlDatabaseInspectorDialog sqlInspectorDialog;
    private Timer toastTimer;

    public PhoneFrame(AppContainer container) {
        super(AppConfig.APP_NAME + " - " + AppConfig.APP_VERSION);
        this.container = container;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setPreferredSize(new Dimension(AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT));
        root.setMinimumSize(new Dimension(AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT));
        root.setBackground(UiTheme.BG_APP);

        JPanel topStack = new JPanel();
        topStack.setLayout(new BoxLayout(topStack, BoxLayout.Y_AXIS));
        topStack.add(buildStatusBar());
        topStack.add(buildBleWarningBar());
        topStack.add(buildToastBar());

        JPanel bottomStack = new JPanel();
        bottomStack.setLayout(new BoxLayout(bottomStack, BoxLayout.Y_AXIS));
        bottomStack.add(buildBeaconPromptBottomSheet());
        if (AppConfig.DEBUG || AppConfig.ENABLE_BLE_SIMULATOR) {
            bottomStack.add(buildBleDebugSimulatorPanel());
        }

        root.add(topStack, BorderLayout.NORTH);
        root.add(screenContainer, BorderLayout.CENTER);
        root.add(bottomStack, BorderLayout.SOUTH);
        setContentPane(root);
        pack();
        setLocationRelativeTo(null);

        this.navigator = new Navigator(
                container,
                this::setScreen,
                this::showToast,
                this::updateLanguageBadge);

        bindBleBridgeEvents();
    }

    public void start() {
        navigator.navigateTo(Navigator.Route.SPLASH);
    }

    public Navigator navigator() {
        return navigator;
    }

    /** Mo cua so SQL Database &amp; Table Inspector (13 bang Entity). */
    public void openSqlDatabaseInspector() {
        if (sqlInspectorDialog == null) {
            sqlInspectorDialog = new SqlDatabaseInspectorDialog(this, container);
        } else {
            sqlInspectorDialog.reloadSnapshots();
        }
        sqlInspectorDialog.setVisible(true);
        sqlInspectorDialog.toFront();
    }

    private void bindBleBridgeEvents() {
        BleBridgeCoordinator bridge = container.bleBridge();

        // 1. Non-intrusive Beacon Suggestion Banner / BottomSheet
        bridge.pendingBeaconPrompt().observe(event -> {
            if (event != null) {
                beaconPromptLabel.setText("<html><b>" + I18n.tr("ble.prompt_title") + "</b><br>"
                        + bridge.formatPromptMessage(event) + "</html>");
                beaconPromptSheet.setVisible(true);
            } else {
                beaconPromptSheet.setVisible(false);
            }
            beaconPromptSheet.revalidate();
            beaconPromptSheet.repaint();
        });

        // 2. BLE Warning Banner (Bluetooth OFF / Permission Denied)
        bridge.warningBannerMessage().observe(warning -> {
            if (warning != null && !warning.isBlank()) {
                bleWarningLabel.setText("<html>" + warning + "</html>");
                bleWarningPanel.setVisible(true);
            } else {
                bleWarningPanel.setVisible(false);
            }
            bleWarningPanel.revalidate();
            bleWarningPanel.repaint();
        });
    }

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(UiTheme.STATUS_BAR_BG);
        bar.setBorder(new EmptyBorder(6, 12, 6, 12));

        JLabel clock = new JLabel(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        clock.setFont(UiTheme.FONT_BODY_BOLD);
        clock.setForeground(Color.WHITE);

        JLabel title = new JLabel("Heritage TV2", JLabel.CENTER);
        title.setFont(UiTheme.FONT_SMALL);
        title.setForeground(new Color(235, 220, 200));

        JPanel badges = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        badges.setOpaque(false);

        modeBadge.setText(AppConfig.USE_MOCK_DATA ? I18n.tr("app.badge.mock") : I18n.tr("app.badge.live"));
        modeBadge.setFont(UiTheme.FONT_BADGE);
        modeBadge.setOpaque(true);
        modeBadge.setBackground(AppConfig.USE_MOCK_DATA ? UiTheme.ACCENT_GOLD : UiTheme.SUCCESS);
        modeBadge.setForeground(Color.WHITE);
        modeBadge.setBorder(new EmptyBorder(2, 6, 2, 6));

        langBadge.setFont(UiTheme.FONT_BADGE);
        langBadge.setOpaque(true);
        langBadge.setBackground(UiTheme.PRIMARY);
        langBadge.setForeground(Color.WHITE);
        langBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                new EmptyBorder(1, 6, 1, 6)));

        badges.add(modeBadge);
        badges.add(langBadge);

        JButton sqlBtn = new JButton("🗄 SQL");
        sqlBtn.setFont(UiTheme.FONT_BADGE);
        sqlBtn.setBackground(new Color(42, 98, 154));
        sqlBtn.setForeground(Color.WHITE);
        sqlBtn.setFocusPainted(false);
        sqlBtn.setOpaque(true);
        sqlBtn.setBorder(new EmptyBorder(2, 6, 2, 6));
        sqlBtn.setToolTipText("Mở cửa sổ xem 13 bảng SQL (HeritageTV2DB)");
        sqlBtn.addActionListener(e -> openSqlDatabaseInspector());
        badges.add(sqlBtn);

        bar.add(clock, BorderLayout.WEST);
        bar.add(title, BorderLayout.CENTER);
        bar.add(badges, BorderLayout.EAST);
        return bar;
    }

    private JPanel buildBleWarningBar() {
        bleWarningPanel.setVisible(false);
        bleWarningPanel.setBackground(new Color(255, 243, 205));
        bleWarningPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UiTheme.ACCENT_GOLD),
                new EmptyBorder(6, 10, 6, 10)));
        bleWarningLabel.setFont(UiTheme.FONT_SMALL);
        bleWarningLabel.setForeground(UiTheme.PRIMARY_DARK);

        JButton enableBtn = UiTheme.primaryButton(I18n.tr("ble.enable_btn"));
        enableBtn.setFont(UiTheme.FONT_BADGE);
        enableBtn.addActionListener(e -> container.bleBridge().resolveBlePermissionsAndEnableBluetooth());

        bleWarningPanel.add(bleWarningLabel, BorderLayout.CENTER);
        bleWarningPanel.add(enableBtn, BorderLayout.EAST);
        return bleWarningPanel;
    }

    private JPanel buildToastBar() {
        toastPanel.setVisible(false);
        toastPanel.setBorder(new EmptyBorder(7, 12, 7, 12));
        toastLabel.setFont(UiTheme.FONT_SMALL);
        toastLabel.setForeground(Color.WHITE);
        toastPanel.add(toastLabel, BorderLayout.CENTER);
        return toastPanel;
    }

    /** Banner / BottomSheet khong gay gian doan khi phat hien Beacon gan nguoi dung. */
    private JPanel buildBeaconPromptBottomSheet() {
        beaconPromptSheet.setVisible(false);
        beaconPromptSheet.setBackground(new Color(44, 34, 28));
        beaconPromptSheet.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(2, 0, 0, 0, UiTheme.ACCENT_GOLD),
                new EmptyBorder(8, 12, 8, 12)));

        beaconPromptLabel.setFont(UiTheme.FONT_SMALL);
        beaconPromptLabel.setForeground(Color.WHITE);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        actions.setOpaque(false);

        JButton viewNowBtn = UiTheme.primaryButton(I18n.tr("ble.prompt_view_now"));
        viewNowBtn.setFont(UiTheme.FONT_BADGE);
        viewNowBtn.addActionListener(e -> navigator.acceptCurrentBeaconPrompt());

        JButton dismissBtn = UiTheme.secondaryButton(I18n.tr("ble.prompt_dismiss"));
        dismissBtn.setFont(UiTheme.FONT_BADGE);
        dismissBtn.addActionListener(e -> container.bleBridge().dismissBeaconPrompt());

        actions.add(viewNowBtn);
        actions.add(dismissBtn);

        beaconPromptSheet.add(beaconPromptLabel, BorderLayout.CENTER);
        beaconPromptSheet.add(actions, BorderLayout.EAST);
        return beaconPromptSheet;
    }

    /**
     * Panel noi BLE Debug Simulator (chi bat khi AppConfig.DEBUG hoac ENABLE_BLE_SIMULATOR = true)
     * gom 4 kich ban test chuan de phoi hop TV3 &amp; TV6.
     */
    private JPanel buildBleDebugSimulatorPanel() {
        BleDebugSimulator sim = container.bleDebugSimulator();
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        panel.setBackground(new Color(238, 232, 222));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, UiTheme.BORDER_COLOR),
                new EmptyBorder(5, 8, 5, 8)));

        JLabel title = new JLabel(I18n.tr("ble.sim_title"));
        title.setFont(UiTheme.FONT_BADGE);
        title.setForeground(UiTheme.PRIMARY_DARK);
        panel.add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 2, 4, 4));
        grid.setOpaque(false);

        JButton s1Enter = UiTheme.secondaryButton(I18n.tr("ble.sim_s1_enter"));
        s1Enter.setFont(UiTheme.FONT_BADGE);
        s1Enter.addActionListener(e -> sim.triggerScenario1EnterBeacon());

        JButton s2Out = UiTheme.secondaryButton(I18n.tr("ble.sim_s2_out"));
        s2Out.setFont(UiTheme.FONT_BADGE);
        s2Out.addActionListener(e -> sim.triggerScenario2OutOfRange());

        JButton s3Switch = UiTheme.secondaryButton(I18n.tr("ble.sim_s3_switch"));
        s3Switch.setFont(UiTheme.FONT_BADGE);
        s3Switch.addActionListener(e -> sim.triggerScenario3SwitchBeacon());

        JButton s4Err = UiTheme.dangerButton(I18n.tr("ble.sim_s4_err"));
        s4Err.setFont(UiTheme.FONT_BADGE);
        s4Err.addActionListener(e -> sim.triggerScenario4BluetoothOffOrPermissionDenied());

        grid.add(s1Enter);
        grid.add(s2Out);
        grid.add(s3Switch);
        grid.add(s4Err);
        panel.add(grid, BorderLayout.CENTER);
        return panel;
    }

    private void setScreen(Screen screen) {
        screenContainer.removeAll();
        screenContainer.add(screen, BorderLayout.CENTER);
        screenContainer.revalidate();
        screenContainer.repaint();
    }

    private void updateLanguageBadge(String lang) {
        langBadge.setText(lang == null ? "VI" : lang.toUpperCase(Locale.ROOT));
        modeBadge.setText(AppConfig.USE_MOCK_DATA ? I18n.tr("app.badge.mock") : I18n.tr("app.badge.live"));
        BeaconSignalEvent pending = container.bleBridge().pendingBeaconPrompt().getValue();
        if (pending != null) {
            beaconPromptLabel.setText("<html><b>" + I18n.tr("ble.prompt_title") + "</b><br>"
                    + container.bleBridge().formatPromptMessage(pending) + "</html>");
        }
        container.bleBridge().refreshWarningBanner();
    }

    private void showToast(String message, boolean isError) {
        toastLabel.setText(message);
        toastPanel.setBackground(isError ? UiTheme.DANGER : UiTheme.SUCCESS);
        toastPanel.setVisible(true);
        toastPanel.revalidate();
        toastPanel.repaint();

        if (toastTimer != null && toastTimer.isRunning()) {
            toastTimer.stop();
        }
        toastTimer = new Timer(3500, e -> toastPanel.setVisible(false));
        toastTimer.setRepeats(false);
        toastTimer.start();
    }
}
