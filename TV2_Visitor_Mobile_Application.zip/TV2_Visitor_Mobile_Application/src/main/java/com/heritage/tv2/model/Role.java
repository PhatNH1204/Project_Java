package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

/**
 * Vai tro nguoi dung - khop Entity {@code Role} cua TV1.
 */
public class Role {

    public static final String VISITOR = "VISITOR";
    public static final String STAFF = "STAFF";
    public static final String ADMIN = "ADMIN";

    @SerializedName(value = "id", alternate = {"roleId", "role_id"})
    private Long id;

    @SerializedName(value = "name", alternate = {"code", "roleName", "role_name"})
    private String name;

    @SerializedName(value = "description", alternate = {"desc"})
    private String description;

    public Role() {
    }

    public Role(Long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isVisitor() {
        return VISITOR.equalsIgnoreCase(name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Role)) return false;
        Role role = (Role) o;
        return Objects.equals(id, role.id) && Objects.equals(name, role.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    @Override
    public String toString() {
        return "Role{" + name + '}';
    }
}
