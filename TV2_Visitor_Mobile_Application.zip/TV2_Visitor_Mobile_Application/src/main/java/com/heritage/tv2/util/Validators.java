package com.heritage.tv2.util;

import java.util.regex.Pattern;

/** Kiem tra du lieu nhap phia client. */
public final class Validators {

    public static final int MIN_PASSWORD_LENGTH = 6;
    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");

    private Validators() {
    }

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL.matcher(email.trim()).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= MIN_PASSWORD_LENGTH;
    }

    public static boolean isNotBlank(String s) {
        return s != null && !s.isBlank();
    }
}
