package com.heritage.tv2.api;

import com.heritage.tv2.model.ApiResponse;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.request.RefreshTokenRequest;

import java.io.IOException;

import retrofit2.Response;

/**
 * Trien khai {@link AuthInterceptor.TokenRefresher} bang Retrofit.
 * {@code refreshApi} PHAI duoc tao tu OkHttpClient KHONG gan {@link AuthInterceptor}
 * de tranh de quy vo han khi chinh request refresh nhan 401.
 */
public class RetrofitTokenRefresher implements AuthInterceptor.TokenRefresher {

    private final HeritageApiService refreshApi;

    public RetrofitTokenRefresher(HeritageApiService refreshApi) {
        this.refreshApi = refreshApi;
    }

    @Override
    public AuthTokens refresh(String refreshToken) throws IOException {
        Response<ApiResponse<AuthTokens>> response =
                refreshApi.refresh(new RefreshTokenRequest(refreshToken)).execute();
        if (response.isSuccessful()) {
            ApiResponse<AuthTokens> body = response.body();
            return body != null && body.isSuccess() ? body.getData() : null;
        }
        int code = response.code();
        if (response.errorBody() != null) {
            response.errorBody().close();
        }
        if (code == 400 || code == 401 || code == 403) {
            return null; // refresh token bi tu choi -> het phien
        }
        throw new IOException("Token refresh failed: HTTP " + code);
    }
}
