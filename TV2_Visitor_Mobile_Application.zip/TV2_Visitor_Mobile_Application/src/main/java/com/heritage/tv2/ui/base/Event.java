package com.heritage.tv2.ui.base;

/**
 * Vo boc su kien mot lan (toast, dieu huong) - tranh xu ly lai khi Screen duoc tao lai
 * (vd: sau khi doi ngon ngu) va observe lai LiveData.
 */
public final class Event<T> {

    private final T content;
    private boolean handled;

    public Event(T content) {
        this.content = content;
    }

    /** @return noi dung neu chua xu ly, nguoc lai {@code null}. */
    public synchronized T getIfNotHandled() {
        if (handled) {
            return null;
        }
        handled = true;
        return content;
    }

    public T peek() {
        return content;
    }

    public synchronized boolean isHandled() {
        return handled;
    }
}
