package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Hien vat yeu thich cua nguoi dung - khop Entity {@code Favorite} (TV2/TV5).
 */
public class Favorite {

    @SerializedName(value = "id", alternate = {"favoriteId", "favorite_id"})
    private Long id;

    @SerializedName(value = "userId", alternate = {"user_id", "visitorId", "visitor_id"})
    private Long userId;

    @SerializedName(value = "artifactId", alternate = {"artifact_id"})
    private Long artifactId;

    /** Thong tin tom tat hien vat (backend co the nhung san de hien thi danh sach). */
    @SerializedName(value = "artifact", alternate = {"artifactSummary", "artifact_summary"})
    private Artifact artifact;

    /** ISO-8601. */
    @SerializedName(value = "createdAt", alternate = {"created_at", "favoritedAt", "favorited_at"})
    private String createdAt;

    public Favorite() {
    }

    public Favorite(Long id, Long userId, Long artifactId, Artifact artifact, String createdAt) {
        this.id = id;
        this.userId = userId;
        this.artifactId = artifactId;
        this.artifact = artifact;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Long artifactId) {
        this.artifactId = artifactId;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public void setArtifact(Artifact artifact) {
        this.artifact = artifact;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
