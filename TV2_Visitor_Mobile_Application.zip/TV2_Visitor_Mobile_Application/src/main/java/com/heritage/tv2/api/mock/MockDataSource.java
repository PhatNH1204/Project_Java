package com.heritage.tv2.api.mock;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.Content;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.MediaType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Bo du lieu mau DA NGON NGU (vi, en) cho che do {@code AppConfig.USE_MOCK_DATA}.
 * Moi chuoi hien thi luu dang {@link Text} va duoc "ban dia hoa" theo Accept-Language
 * dung nhu backend that cua TV4 se lam.
 */
public final class MockDataSource {

    private MockDataSource() {
    }

    /** Chuoi da ngon ngu. */
    public static final class Text {
        final String vi;
        final String en;

        Text(String vi, String en) {
            this.vi = vi;
            this.en = en;
        }

        public String in(String lang) {
            if (AppConfig.LANGUAGE_EN.equalsIgnoreCase(lang) && en != null && !en.isBlank()) {
                return en;
            }
            return vi;
        }
    }

    static Text t(String vi, String en) {
        return new Text(vi, en);
    }

    // ---------------------------------------------------------------- Languages
    public static List<Language> languages() {
        return List.of(
                new Language(1L, AppConfig.LANGUAGE_VI, "Tiếng Việt", true),
                new Language(2L, AppConfig.LANGUAGE_EN, "English", false));
    }

    // -------------------------------------------------------------------- Sites
    static final class SiteSeed {
        final long id;
        final String code;
        final String category;
        final Text region;
        final Text name;
        final Text description;
        final Text address;
        final double lat;
        final double lng;
        final String hours;

        SiteSeed(long id, String code, String category, Text region, Text name, Text description,
                 Text address, double lat, double lng, String hours) {
            this.id = id;
            this.code = code;
            this.category = category;
            this.region = region;
            this.name = name;
            this.description = description;
            this.address = address;
            this.lat = lat;
            this.lng = lng;
            this.hours = hours;
        }
    }

    static final List<SiteSeed> SITES = List.of(
            new SiteSeed(1, "HTTL", HeritageSite.CATEGORY_CITADEL,
                    t("Quận Ba Đình, Hà Nội", "Ba Dinh District, Hanoi"),
                    t("Hoàng thành Thăng Long", "Imperial Citadel of Thang Long"),
                    t("Quần thể di tích gắn với lịch sử kinh thành Thăng Long – Hà Nội, Di sản Văn hóa Thế giới UNESCO (2010).",
                            "A complex of relics tied to the history of Thang Long – Hanoi, a UNESCO World Heritage Site (2010)."),
                    t("19C Hoàng Diệu, Ba Đình, Hà Nội", "19C Hoang Dieu, Ba Dinh, Hanoi"),
                    21.0352, 105.8403, "08:00 - 17:00"),
            new SiteSeed(2, "VMQTG", HeritageSite.CATEGORY_TEMPLE,
                    t("Quận Đống Đa, Hà Nội", "Dong Da District, Hanoi"),
                    t("Văn Miếu – Quốc Tử Giám", "Temple of Literature"),
                    t("Trường đại học đầu tiên của Việt Nam, xây dựng năm 1070 thời Lý Thánh Tông.",
                            "Vietnam's first national university, founded in 1070 under Emperor Ly Thanh Tong."),
                    t("58 Quốc Tử Giám, Đống Đa, Hà Nội", "58 Quoc Tu Giam, Dong Da, Hanoi"),
                    21.0294, 105.8355, "08:00 - 17:00"),
            new SiteSeed(3, "BTLSQG", HeritageSite.CATEGORY_MUSEUM,
                    t("Quận Hoàn Kiếm, Hà Nội", "Hoan Kiem District, Hanoi"),
                    t("Bảo tàng Lịch sử Quốc gia", "National Museum of Vietnamese History"),
                    t("Lưu giữ hơn 200.000 hiện vật từ thời tiền sử đến triều Nguyễn.",
                            "Home to more than 200,000 artifacts from prehistory to the Nguyen Dynasty."),
                    t("1 Tràng Tiền, Hoàn Kiếm, Hà Nội", "1 Trang Tien, Hoan Kiem, Hanoi"),
                    21.0245, 105.8592, "08:00 - 12:00, 13:30 - 17:00"));

    // ---------------------------------------------------------------- Artifacts
    static final class ArtifactSeed {
        final long id;
        final long siteId;
        final String code;
        final String beaconId;
        final int minor;
        final Text name;
        final Text shortDescription;
        final Text period;
        final Text body;
        final int audioViSeconds;
        final int audioEnSeconds;
        final boolean hasVideo;
        final boolean includeFallbackDemoMedia;
        final boolean viTranslationOnly;

        ArtifactSeed(long id, long siteId, String code, String beaconId, int minor, Text name, Text shortDescription,
                     Text period, Text body, int audioViSeconds, int audioEnSeconds, boolean hasVideo,
                     boolean includeFallbackDemoMedia, boolean viTranslationOnly) {
            this.id = id;
            this.siteId = siteId;
            this.code = code;
            this.beaconId = beaconId;
            this.minor = minor;
            this.name = name;
            this.shortDescription = shortDescription;
            this.period = period;
            this.body = body;
            this.audioViSeconds = audioViSeconds;
            this.audioEnSeconds = audioEnSeconds;
            this.hasVideo = hasVideo;
            this.includeFallbackDemoMedia = includeFallbackDemoMedia;
            this.viTranslationOnly = viTranslationOnly;
        }
    }

    public static final String BEACON_UUID = "FDA50693-A4E2-4FB1-AFCF-C6EB07647825";
    public static final int BEACON_MAJOR = 1;

    static final List<ArtifactSeed> ARTIFACTS = List.of(
            new ArtifactSeed(101, 3, "AR-101", "B-101", 101,
                    t("Trống đồng Ngọc Lũ", "Ngoc Lu Bronze Drum"),
                    t("Bảo vật quốc gia tiêu biểu của văn hóa Đông Sơn.", "A national treasure of the Dong Son culture."),
                    t("Văn hóa Đông Sơn (~2.500 năm trước)", "Dong Son culture (~2,500 years ago)"),
                    t("Trống đồng Ngọc Lũ được phát hiện năm 1893 tại Lý Nhân, Hà Nam. Mặt trống trang trí ngôi sao 14 cánh, "
                                    + "chim Lạc bay và cảnh sinh hoạt của cư dân Việt cổ. Đây là chiếc trống đồng nguyên vẹn và tinh xảo bậc nhất.",
                            "The Ngoc Lu drum was discovered in 1893 in Ly Nhan, Ha Nam. Its tympanum features a 14-pointed star, "
                                    + "flying Lac birds and scenes of ancient Viet daily life. It is the best-preserved Dong Son bronze drum."),
                    185, 172, true, false, false),
            new ArtifactSeed(102, 1, "AR-102", "B-102", 102,
                    t("Rồng đá điện Kính Thiên", "Stone Dragons of Kinh Thien Palace"),
                    t("Đôi rồng đá chầu thềm điện Kính Thiên.", "A pair of stone dragons guarding the steps of Kinh Thien Palace."),
                    t("Thời Lê sơ (thế kỷ XV - 1467)", "Early Le Dynasty (15th century - 1467)"),
                    t("Đôi rồng đá dài 5,3 m chạm khắc năm 1467 thời vua Lê Thánh Tông là dấu tích nguyên bản còn lại của điện Kính Thiên, "
                                    + "nơi cử hành các đại lễ thiết triều của hoàng cung Thăng Long.",
                            "Carved in 1467 under Emperor Le Thanh Tong, these 5.3 m stone dragons are the remaining trace of Kinh Thien Palace, "
                                    + "where grand royal ceremonies were held in Thang Long Citadel."),
                    140, 131, true, false, false),
            new ArtifactSeed(103, 2, "AR-103", "B-103", 103,
                    t("Bia Tiến sĩ Văn Miếu", "Doctoral Steles of Temple of Literature"),
                    t("82 tấm bia đá đặt trên lưng rùa ghi danh tiến sĩ.", "82 steles mounted on stone turtles honouring doctoral laureates."),
                    t("Triều Lê - Mạc (1484 - 1780)", "Le - Mac Dynasties (1484 - 1780)"),
                    t("82 bia Tiến sĩ đặt trên lưng rùa đá, ghi tên 1.304 vị tiến sĩ đỗ đạt qua 82 khoa thi từ năm 1442 đến 1779; "
                                    + "được UNESCO công nhận là Di sản Tư liệu Thế giới.",
                            "82 steles mounted on stone turtles record 1,304 laureates of 82 imperial exams between 1442 and 1779; "
                                    + "inscribed by UNESCO as a Memory of the World Documentary Heritage."),
                    160, 150, true, true, false),
            new ArtifactSeed(104, 3, "AR-104", "B-104", 104,
                    t("Ấn vàng \"Hoàng đế chi bảo\"", "\"Hoang De Chi Bao\" Golden Seal"),
                    t("Quốc bảo triều Nguyễn, đúc năm Minh Mạng thứ 4 (1823).", "Imperial golden seal of the Nguyen Dynasty, cast in 1823."),
                    t("Triều Nguyễn (1823)", "Nguyen Dynasty (1823)"),
                    t("Ấn vàng nặng gần 10,8 kg, núm hình rồng cuộn 5 móng, được dùng đóng trên các sắc phong và văn bản ngoại giao "
                                    + "quan trọng bậc nhất của triều Nguyễn.",
                            "Weighing nearly 10.8 kg with a five-clawed coiled dragon knob, it sealed royal decrees and key diplomatic documents "
                                    + "of the Nguyen court."),
                    120, 118, true, false, false),
            new ArtifactSeed(105, 2, "AR-105", "B-105", 105,
                    t("Khuê Văn Các", "Khue Van Pavilion"),
                    t("Biểu tượng kiến trúc của thủ đô Hà Nội tại Văn Miếu.", "Architectural symbol of Hanoi inside the Temple of Literature."),
                    t("Triều Nguyễn (1805)", "Nguyen Dynasty (1805)"),
                    t("Khuê Văn Các dựng năm 1805 gồm hai tầng tám mái, tầng trên có bốn cửa sổ tròn tượng trưng cho sao Khuê tỏa sáng "
                                    + "bầu trời văn học đất Việt. (Hiện vật mẫu minh họa cơ chế fallback sang tiếng Việt khi thiếu bản dịch).",
                            null),
                    115, 115, false, false, true),
            new ArtifactSeed(106, 1, "AR-106", "B-106", 106,
                    t("Cổng Đoan Môn", "Doan Mon (Main South Gate)"),
                    t("Cổng chính dẫn vào Cấm thành Thăng Long.", "The main ceremonial southern entrance to the Forbidden Palace."),
                    t("Thời Lê - Nguyễn", "Le - Nguyen Dynasties"),
                    t("Đoan Môn xây theo lối tường thành 5 vòm cổng bằng đá thanh và gạch vồ, cửa giữa dành riêng cho nhà vua.",
                            "Doan Mon features five arched stone-and-brick gateways; the central arch was reserved exclusively for the Emperor."),
                    130, 125, true, false, false));

    // ---------------------------------------------------------------- Builders

    public static List<HeritageSite> sites(String lang) {
        List<HeritageSite> list = new ArrayList<>();
        for (SiteSeed s : SITES) {
            list.add(site(s, lang));
        }
        return list;
    }

    static HeritageSite site(SiteSeed s, String lang) {
        HeritageSite site = new HeritageSite(s.id, s.code, s.name.in(lang), s.description.in(lang),
                s.address.in(lang), s.lat, s.lng);
        site.setCategory(s.category);
        site.setRegion(s.region.in(lang));
        site.setOpeningHours(s.hours);
        site.setThumbnailUrl("https://cdn.heritage.local/sites/" + s.id + "/cover.jpg");
        List<Artifact> siteArtifacts = artifactsBySite(s.id, lang);
        site.setArtifacts(siteArtifacts);
        site.setArtifactCount(siteArtifacts.size());
        return site;
    }

    public static List<Artifact> artifactsBySite(long siteId, String lang) {
        return ARTIFACTS.stream()
                .filter(a -> a.siteId == siteId)
                .map(a -> artifactSummary(a, lang))
                .collect(Collectors.toList());
    }

    static SiteSeed findSite(long id) {
        return SITES.stream().filter(s -> s.id == id).findFirst().orElse(null);
    }

    static ArtifactSeed findArtifact(long id) {
        return ARTIFACTS.stream().filter(a -> a.id == id).findFirst().orElse(null);
    }

    static ArtifactSeed findArtifactByBeacon(String beaconId) {
        return ARTIFACTS.stream().filter(a -> a.beaconId.equalsIgnoreCase(beaconId)).findFirst().orElse(null);
    }

    /** Hien vat tom tat (khong kem Content) - dung cho danh sach theo dia diem &amp; yeu thich. */
    static Artifact artifactSummary(ArtifactSeed a, String lang) {
        Artifact artifact = new Artifact(a.id, a.siteId, a.code, a.name.in(lang), a.shortDescription.in(lang), a.period.in(lang));
        artifact.setThumbnailUrl("https://cdn.heritage.local/artifacts/" + a.id + "/thumb.jpg");
        return artifact;
    }

    /** Hien vat day du kem Content (ban dich + thu vien anh + audio + video). */
    static Artifact artifactDetail(ArtifactSeed a, String lang) {
        Artifact artifact = artifactSummary(a, lang);
        List<ContentTranslation> translations = new ArrayList<>();
        translations.add(new ContentTranslation(a.id * 10 + 1, AppConfig.LANGUAGE_VI, a.name.vi, a.body.vi));
        if (!a.viTranslationOnly && a.body.en != null) {
            translations.add(new ContentTranslation(a.id * 10 + 2, AppConfig.LANGUAGE_EN, a.name.en, a.body.en));
        }

        List<Media> media = new ArrayList<>();
        String base = "https://cdn.heritage.local/artifacts/" + a.id;
        // Thu vien hinh anh (2-3 anh / hien vat)
        media.add(new Media(a.id * 100 + 1, MediaType.IMAGE, base + "/photo-front.jpg", null, null));
        if (a.includeFallbackDemoMedia) {
            // Anh thu 2 co link broken de kiem thu anh du phong (fallback image)
            media.add(new Media(a.id * 100 + 2, MediaType.IMAGE, base + "/broken-photo.jpg", null, null));
        } else {
            media.add(new Media(a.id * 100 + 2, MediaType.IMAGE, base + "/photo-detail.jpg", null, null));
        }
        media.add(new Media(a.id * 100 + 3, MediaType.IMAGE, base + "/photo-panorama.jpg", null, null));

        // Audio thuyet minh theo ngon ngu
        media.add(new Media(a.id * 100 + 4, MediaType.AUDIO, base + "/audio-vi.mp3", a.audioViSeconds, AppConfig.LANGUAGE_VI));
        media.add(new Media(a.id * 100 + 5, MediaType.AUDIO, base + "/audio-en.mp3", a.audioEnSeconds, AppConfig.LANGUAGE_EN));

        // Video
        if (a.hasVideo) {
            String videoUrl = a.includeFallbackDemoMedia ? (base + "/broken-video.mp4") : (base + "/intro-360.mp4");
            media.add(new Media(a.id * 100 + 6, MediaType.VIDEO, videoUrl, 95, null));
        }
        artifact.setContent(new Content(a.id * 10, a.id, translations, media));
        return artifact;
    }

    /** Beacon -> (major, minor) phuc vu gia lap BLE. */
    public static Map<String, int[]> beacons() {
        Map<String, int[]> map = new LinkedHashMap<>();
        for (ArtifactSeed a : ARTIFACTS) {
            map.put(a.beaconId, new int[]{BEACON_MAJOR, a.minor});
        }
        return map;
    }
}
