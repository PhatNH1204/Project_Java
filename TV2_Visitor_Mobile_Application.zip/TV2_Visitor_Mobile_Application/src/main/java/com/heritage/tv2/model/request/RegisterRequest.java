package com.heritage.tv2.model.request;

/** Body {@code POST /api/auth/register}. */
public class RegisterRequest {

    private String email;
    private String password;
    private String fullName;
    private String preferredLanguage;

    public RegisterRequest() {
    }

    public RegisterRequest(String email, String password, String fullName, String preferredLanguage) {
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.preferredLanguage = preferredLanguage;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }
}
