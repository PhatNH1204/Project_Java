package com.heritage.tv2.ui;

import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.auth.LoginScreen;
import com.heritage.tv2.ui.auth.LoginViewModel;
import com.heritage.tv2.ui.auth.RegisterScreen;
import com.heritage.tv2.ui.auth.RegisterViewModel;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.base.ViewModel;
import com.heritage.tv2.ui.detail.ArtifactDetailScreen;
import com.heritage.tv2.ui.detail.ArtifactDetailViewModel;
import com.heritage.tv2.ui.main.MainScreen;
import com.heritage.tv2.ui.main.MainViewModel;
import com.heritage.tv2.ui.splash.SplashScreen;
import com.heritage.tv2.ui.splash.SplashViewModel;
import com.heritage.tv2.util.I18n;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Bo dieu huong trung tam (tuong duong Jetpack Navigation {@code NavController} trong Single-Activity).
 *
 * <p>So do dieu huong Gate 2 &amp; Gate 3 - Phan 1:</p>
 * <pre>
 *   SPLASH  --->  LOGIN  <--->  REGISTER
 *     |             |               |
 *     +-------------+---------------+--->  MAIN (4 Tabs)  <--->  ARTIFACT_DETAIL
 * </pre>
 */
public final class Navigator {

    public enum Route {
        SPLASH,
        LOGIN,
        REGISTER,
        MAIN,
        ARTIFACT_DETAIL
    }

    private final AppContainer container;
    private final Consumer<Screen> screenHost;
    private final BiConsumer<String, Boolean> toastHost;
    private final Consumer<String> languageBadgeHost;

    private Route currentRoute;
    private ViewModel currentViewModel;
    private Screen currentScreen;
    /** Giu MainViewModel khi mo man hinh con ARTIFACT_DETAIL de quay lai giu nguyen bo loc &amp; tab. */
    private MainViewModel retainedMainViewModel;
    private long currentArtifactDetailId = 101L;
    private String currentArtifactOpenSource = VisitHistory.SOURCE_MANUAL;
    private String currentAssociatedBeaconId = null;

    public Navigator(AppContainer container,
                     Consumer<Screen> screenHost,
                     BiConsumer<String, Boolean> toastHost,
                     Consumer<String> languageBadgeHost) {
        this.container = container;
        this.screenHost = screenHost;
        this.toastHost = toastHost;
        this.languageBadgeHost = languageBadgeHost;

        I18n.setLanguage(container.sessionStorage().getLanguage());
        languageBadgeHost.accept(container.sessionStorage().getLanguage());

        // Lang nghe doi ngon ngu -> cap nhat I18n + ve lai Screen hien tai tren EDT.
        container.sessionStorage().addLanguageListener(newLang ->
                container.executors().main().execute(() -> {
                    I18n.setLanguage(newLang);
                    languageBadgeHost.accept(newLang);
                    if (currentRoute != null) {
                        rebuildCurrentScreen();
                    }
                }));

        // Lang nghe het han phien (401 va refresh that bai) -> quay ve Login.
        container.addSessionExpiredListener(() ->
                container.executors().main().execute(() -> {
                    if (currentRoute != Route.LOGIN) {
                        navigateTo(Route.LOGIN);
                        showToast(I18n.tr("error.session_expired"), true);
                    }
                }));
    }

    public AppContainer container() {
        return container;
    }

    public Route currentRoute() {
        return currentRoute;
    }

    public Screen currentScreen() {
        return currentScreen;
    }

    public ViewModel currentViewModel() {
        return currentViewModel;
    }

    public void showToast(String message, boolean isError) {
        if (message != null && !message.isBlank()) {
            toastHost.accept(message, isError);
        }
    }

    /** Mo man hinh Chi tiet Hien vat ({@code GET /api/artifacts/{id}} + {@code ArtifactCache}). */
    public void openArtifactDetail(long artifactId) {
        openArtifactDetail(artifactId, VisitHistory.SOURCE_MANUAL, "B-" + artifactId);
    }

    /** Mo man hinh Chi tiet Hien vat kem nhan nguon mo (MANUAL hoac BEACON_BLE). */
    public void openArtifactDetail(long artifactId, String openSource) {
        openArtifactDetail(artifactId, openSource, "B-" + artifactId);
    }

    /** Mo man hinh Chi tiet Hien vat tu su kien Beacon BLE cu the. */
    public void openArtifactDetailFromBeacon(long artifactId, String beaconId) {
        openArtifactDetail(artifactId, VisitHistory.SOURCE_BEACON_BLE, beaconId);
    }

    public void openArtifactDetail(long artifactId, String openSource, String associatedBeaconId) {
        this.currentArtifactDetailId = artifactId;
        this.currentArtifactOpenSource = (openSource == null || openSource.isBlank())
                ? VisitHistory.SOURCE_MANUAL : openSource;
        this.currentAssociatedBeaconId = (associatedBeaconId == null || associatedBeaconId.isBlank())
                ? ("B-" + artifactId) : associatedBeaconId;
        if (currentRoute == Route.MAIN && currentViewModel instanceof MainViewModel) {
            retainedMainViewModel = (MainViewModel) currentViewModel;
        }
        if (currentScreen != null) {
            currentScreen.onHide();
        }
        if (currentViewModel != null && currentViewModel != retainedMainViewModel) {
            currentViewModel.clear();
        }
        currentRoute = Route.ARTIFACT_DETAIL;
        container.tv3BleAdapter().notifyScreenViewingBeacon(this.currentAssociatedBeaconId, artifactId);
        currentViewModel = new ArtifactDetailViewModel(
                artifactId, this.currentArtifactOpenSource, this.currentAssociatedBeaconId, container);
        currentScreen = new ArtifactDetailScreen((ArtifactDetailViewModel) currentViewModel, this);
        screenHost.accept(currentScreen);
        currentScreen.onShow();
    }

    /**
     * Nguoi dung bam "Xem ngay" tren Banner/BottomSheet goi y Beacon:
     * Goi {@code GET /api/beacons/{id}/content?lang={lang}} va mo {@code ArtifactDetailScreen}.
     */
    public void acceptCurrentBeaconPrompt() {
        container.bleBridge().acceptBeaconPrompt(
                (artifact, beaconId) -> openArtifactDetailFromBeacon(artifact.getId(), beaconId));
    }

    /** Quay lai man hinh Main tu ArtifactDetailScreen (giu nguyen Tab, dong bo Yeu thich &amp; Lich su). */
    public void navigateBackToMain() {
        container.tv3BleAdapter().notifyScreenClosed();
        if (currentScreen != null) {
            currentScreen.onHide();
        }
        if (currentViewModel != null && currentViewModel != retainedMainViewModel) {
            currentViewModel.clear();
        }
        currentRoute = Route.MAIN;
        MainViewModel mainVm = retainedMainViewModel != null ? retainedMainViewModel : new MainViewModel(container);
        retainedMainViewModel = mainVm;
        currentViewModel = mainVm;
        mainVm.loadFavorites();
        mainVm.loadVisitHistory();
        currentScreen = new MainScreen(mainVm, this);
        screenHost.accept(currentScreen);
        currentScreen.onShow();
    }

    /** Chuyen sang route moi va khoi tao ViewModel tuong ung. */
    public void navigateTo(Route route) {
        if (route == Route.ARTIFACT_DETAIL) {
            openArtifactDetail(currentArtifactDetailId);
            return;
        }
        container.tv3BleAdapter().notifyScreenClosed();
        if (currentScreen != null) {
            currentScreen.onHide();
        }
        if (currentViewModel != null) {
            currentViewModel.clear();
        }
        if (route != Route.MAIN && retainedMainViewModel != null) {
            retainedMainViewModel.clear();
            retainedMainViewModel = null;
        }
        currentRoute = route;
        currentViewModel = createViewModel(route);
        if (route == Route.MAIN) {
            retainedMainViewModel = (MainViewModel) currentViewModel;
        }
        currentScreen = createScreen(route, currentViewModel);
        screenHost.accept(currentScreen);
        currentScreen.onShow();
    }

    /** Dung lai Screen voi cung ViewModel (khi doi ngon ngu vi <-> en). */
    private void rebuildCurrentScreen() {
        if (currentScreen != null) {
            currentScreen.onHide();
        }
        if (currentViewModel instanceof MainViewModel) {
            ((MainViewModel) currentViewModel).reloadForLanguageChange();
        }
        currentScreen = createScreen(currentRoute, currentViewModel);
        screenHost.accept(currentScreen);
        currentScreen.onShow();
    }

    private ViewModel createViewModel(Route route) {
        switch (route) {
            case SPLASH:
                return new SplashViewModel(container.authRepository(), container.executors());
            case LOGIN:
                return new LoginViewModel(container.authRepository(), container.languageRepository(), container.executors());
            case REGISTER:
                return new RegisterViewModel(container.authRepository(), container.executors());
            case MAIN:
                return new MainViewModel(container);
            case ARTIFACT_DETAIL:
                return new ArtifactDetailViewModel(
                        currentArtifactDetailId, currentArtifactOpenSource, currentAssociatedBeaconId, container);
            default:
                throw new IllegalArgumentException("Unknown route: " + route);
        }
    }

    private Screen createScreen(Route route, ViewModel vm) {
        switch (route) {
            case SPLASH:
                return new SplashScreen((SplashViewModel) vm, this);
            case LOGIN:
                return new LoginScreen((LoginViewModel) vm, this);
            case REGISTER:
                return new RegisterScreen((RegisterViewModel) vm, this);
            case MAIN:
                return new MainScreen((MainViewModel) vm, this);
            case ARTIFACT_DETAIL:
                return new ArtifactDetailScreen((ArtifactDetailViewModel) vm, this);
            default:
                throw new IllegalArgumentException("Unknown route: " + route);
        }
    }
}
