package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Di tich / dia diem di san - khop Entity {@code HeritageSite} cua TV4.
 * Ho tro day du schema JSON that (camelCase &amp; snake_case) tu Swagger/OpenAPI.
 */
public class HeritageSite {

    public static final String CATEGORY_ALL = "ALL";
    public static final String CATEGORY_CITADEL = "CITADEL";
    public static final String CATEGORY_TEMPLE = "TEMPLE";
    public static final String CATEGORY_MUSEUM = "MUSEUM";

    @SerializedName(value = "id", alternate = {"siteId", "site_id"})
    private Long id;

    @SerializedName(value = "code", alternate = {"siteCode", "site_code"})
    private String code;

    @SerializedName(value = "name", alternate = {"title", "siteName", "site_name"})
    private String name;

    @SerializedName(value = "description", alternate = {"summary", "shortDescription", "short_description"})
    private String description;

    @SerializedName(value = "address", alternate = {"locationAddress", "location_address"})
    private String address;

    /** Khu vuc / quan (phuc vu tim kiem theo ten / khu vuc). */
    @SerializedName(value = "region", alternate = {"district", "area"})
    private String region;

    /** Danh muc di san: CITADEL, TEMPLE, MUSEUM. */
    @SerializedName(value = "category", alternate = {"siteType", "site_type", "type"})
    private String category;

    @SerializedName(value = "latitude", alternate = {"lat"})
    private Double latitude;

    @SerializedName(value = "longitude", alternate = {"lng", "lon"})
    private Double longitude;

    @SerializedName(value = "thumbnailUrl", alternate = {"thumbnail_url", "imageUrl", "image_url", "coverUrl"})
    private String thumbnailUrl;

    @SerializedName(value = "openingHours", alternate = {"opening_hours", "openHours"})
    private String openingHours;

    @SerializedName(value = "artifactCount", alternate = {"artifact_count", "totalArtifacts"})
    private Integer artifactCount;

    /** Danh sach hien vat thuoc dia diem nay (tom tat). */
    @SerializedName(value = "artifacts", alternate = {"artifactList", "artifact_list"})
    private List<Artifact> artifacts = new ArrayList<>();

    public HeritageSite() {
    }

    public HeritageSite(Long id, String code, String name, String description, String address,
                        Double latitude, Double longitude) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.description = description;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getOpeningHours() {
        return openingHours;
    }

    public void setOpeningHours(String openingHours) {
        this.openingHours = openingHours;
    }

    public Integer getArtifactCount() {
        return artifactCount;
    }

    public void setArtifactCount(Integer artifactCount) {
        this.artifactCount = artifactCount;
    }

    public List<Artifact> getArtifacts() {
        return artifacts;
    }

    public void setArtifacts(List<Artifact> artifacts) {
        this.artifacts = artifacts == null ? new ArrayList<>() : new ArrayList<>(artifacts);
    }

    @Override
    public String toString() {
        return "HeritageSite{id=" + id + ", name='" + name + "', category='" + category + "'}";
    }
}
