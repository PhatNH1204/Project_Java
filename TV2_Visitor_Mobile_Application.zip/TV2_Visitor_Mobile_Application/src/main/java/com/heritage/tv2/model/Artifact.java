package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

/**
 * Hien vat - khop Entity {@code Artifact} cua TV4.
 * {@code GET /api/artifacts/{id}} tra ve kem {@link Content} (translations + media).
 */
public class Artifact {

    @SerializedName(value = "id", alternate = {"artifactId", "artifact_id"})
    private Long id;

    @SerializedName(value = "siteId", alternate = {"site_id", "heritageSiteId", "heritage_site_id"})
    private Long siteId;

    @SerializedName(value = "code", alternate = {"artifactCode", "artifact_code"})
    private String code;

    /** Ten da ban dia hoa theo Accept-Language. */
    @SerializedName(value = "name", alternate = {"title", "artifactName", "artifact_name"})
    private String name;

    @SerializedName(value = "shortDescription", alternate = {"short_description", "summary", "description"})
    private String shortDescription;

    /** Nien dai / thoi ky. */
    @SerializedName(value = "period", alternate = {"era", "historicalPeriod", "historical_period"})
    private String period;

    @SerializedName(value = "thumbnailUrl", alternate = {"thumbnail_url", "imageUrl", "image_url"})
    private String thumbnailUrl;

    @SerializedName(value = "content", alternate = {"artifactContent", "artifact_content"})
    private Content content;

    public Artifact() {
    }

    public Artifact(Long id, Long siteId, String code, String name, String shortDescription, String period) {
        this.id = id;
        this.siteId = siteId;
        this.code = code;
        this.name = name;
        this.shortDescription = shortDescription;
        this.period = period;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "Artifact{id=" + id + ", name='" + name + "'}";
    }
}
