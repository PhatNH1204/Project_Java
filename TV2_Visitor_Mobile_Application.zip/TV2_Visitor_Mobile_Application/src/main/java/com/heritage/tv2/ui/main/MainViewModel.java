package com.heritage.tv2.ui.main;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.api.mock.MockDataSource;
import com.heritage.tv2.ble.BleBridgeCoordinator;
import com.heritage.tv2.ble.SimulatedBeaconScanner;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.repository.AuthRepository;
import com.heritage.tv2.repository.FavoriteRepository;
import com.heritage.tv2.repository.FeedbackRepository;
import com.heritage.tv2.repository.HeritageRepository;
import com.heritage.tv2.repository.LanguageRepository;
import com.heritage.tv2.repository.UserRepository;
import com.heritage.tv2.repository.VisitHistoryRepository;
import com.heritage.tv2.ui.base.Event;
import com.heritage.tv2.ui.base.LiveData;
import com.heritage.tv2.ui.base.UiState;
import com.heritage.tv2.ui.base.ViewModel;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;
import com.heritage.tv2.util.Validators;

import java.util.List;

/**
 * ViewModel cho man hinh Main (4 Tab: Kham pha, Ban do, Yeu thich &amp; Lich su, Ho so &amp; Ngon ngu).
 *
 * <p>Ho tro day du yeu cau Gate 3 - Phan 1:</p>
 * <ul>
 *     <li>Tab 1: Tim kiem theo ten/khu vuc, loc theo danh muc, va 4 trang thai UI
 *     ({@code LOADING}, {@code SUCCESS}, {@code EMPTY}, {@code ERROR} + Retry).</li>
 *     <li>Tab 2: Kiem tra quyen vi tri GPS (Granted / Denied), hien thi Marker theo latitude/longitude,
 *     bam vao dia diem mo danh sach {@link Artifact} thuoc dia diem do.</li>
 * </ul>
 */
public class MainViewModel extends ViewModel {

    public static final int TAB_EXPLORE = 0;
    public static final int TAB_MAP = 1;
    public static final int TAB_FAV_HISTORY = 2;
    public static final int TAB_PROFILE = 3;

    public static final int SUB_TAB_FAVORITES = 0;
    public static final int SUB_TAB_HISTORY = 1;

    /** Vi tri GPS gia lap cua nguoi dung tai trung tam Ha Noi (khi da cap quyen). */
    public static final double USER_GPS_LAT = 21.0315;
    public static final double USER_GPS_LNG = 105.8420;

    private final AuthRepository authRepository;
    private final UserRepository userRepository;
    private final LanguageRepository languageRepository;
    private final HeritageRepository heritageRepository;
    private final FavoriteRepository favoriteRepository;
    private final VisitHistoryRepository visitHistoryRepository;
    private final FeedbackRepository feedbackRepository;
    private final MockBackendInterceptor mockBackend;
    private final BleBridgeCoordinator bleBridge;
    private final SimulatedBeaconScanner beaconScanner;

    private int activeTab = TAB_EXPLORE;
    private int favHistorySubTab = SUB_TAB_FAVORITES;
    private long selectedArtifactId = 101L;
    private Long selectedSiteId = 1L;
    private String searchQuery = "";
    private String selectedCategory = HeritageSite.CATEGORY_ALL;

    /** Danh sach goc tai tu GET /api/sites (chua loc). */
    private List<HeritageSite> allSites = List.of();

    private final LiveData<List<HeritageSite>> sites = new LiveData<>(List.of());
    private final LiveData<UiState<List<HeritageSite>>> sitesUiState = new LiveData<>(UiState.loading());
    private final LiveData<List<Artifact>> selectedSiteArtifacts = new LiveData<>(List.of());
    private final LiveData<Boolean> locationPermissionGranted = new LiveData<>(true);

    private final LiveData<Artifact> selectedArtifact = new LiveData<>();
    private final LiveData<BeaconSignalEvent> lastBeaconEvent = new LiveData<>();
    private final LiveData<List<Favorite>> favorites = new LiveData<>(List.of());
    private final LiveData<List<VisitHistory>> visitHistory = new LiveData<>(List.of());
    private final LiveData<User> user = new LiveData<>();
    private final LiveData<Boolean> busy = new LiveData<>(false);
    private final LiveData<Event<String>> toastEvent = new LiveData<>();
    private final LiveData<Event<String>> errorEvent = new LiveData<>();
    private final LiveData<Event<Boolean>> loggedOutEvent = new LiveData<>();

    private boolean initialized;

    public MainViewModel(AppContainer container) {
        super(container.executors());
        this.authRepository = container.authRepository();
        this.userRepository = container.userRepository();
        this.languageRepository = container.languageRepository();
        this.heritageRepository = container.heritageRepository();
        this.favoriteRepository = container.favoriteRepository();
        this.visitHistoryRepository = container.visitHistoryRepository();
        this.feedbackRepository = container.feedbackRepository();
        this.mockBackend = container.mockBackend();
        this.bleBridge = container.bleBridge();
        this.beaconScanner = new SimulatedBeaconScanner(
                MockDataSource.BEACON_UUID, MockDataSource.beacons(), 3000L);

        User cached = userRepository.getCachedUser();
        if (cached != null) {
            user.setValue(cached);
        }
    }

    public int getActiveTab() {
        return activeTab;
    }

    public void setActiveTab(int activeTab) {
        this.activeTab = activeTab;
    }

    public int getFavHistorySubTab() {
        return favHistorySubTab;
    }

    public void setFavHistorySubTab(int favHistorySubTab) {
        this.favHistorySubTab = favHistorySubTab;
    }

    public LiveData<List<HeritageSite>> sites() {
        return sites;
    }

    /** Trang thai 4-state cua Tab 1 (LOADING, SUCCESS, EMPTY, ERROR). */
    public LiveData<UiState<List<HeritageSite>>> sitesUiState() {
        return sitesUiState;
    }

    /** Danh sach hien vat cua dia diem dang chon tren Tab 1 / Tab 2. */
    public LiveData<List<Artifact>> selectedSiteArtifacts() {
        return selectedSiteArtifacts;
    }

    /** Trang thai quyen vi tri GPS (true = da cap quyen, false = nguoi dung tu choi). */
    public LiveData<Boolean> locationPermissionGranted() {
        return locationPermissionGranted;
    }

    public boolean isLocationPermissionGranted() {
        return Boolean.TRUE.equals(locationPermissionGranted.getValue());
    }

    public void setLocationPermissionGranted(boolean granted) {
        locationPermissionGranted.setValue(granted);
    }

    public String getSearchQuery() {
        return searchQuery;
    }

    public String getSelectedCategory() {
        return selectedCategory;
    }

    public Long getSelectedSiteId() {
        return selectedSiteId;
    }

    public LiveData<Artifact> selectedArtifact() {
        return selectedArtifact;
    }

    public LiveData<BeaconSignalEvent> lastBeaconEvent() {
        return lastBeaconEvent;
    }

    public LiveData<List<Favorite>> favorites() {
        return favorites;
    }

    public LiveData<List<VisitHistory>> visitHistory() {
        return visitHistory;
    }

    public LiveData<User> user() {
        return user;
    }

    public LiveData<Boolean> busy() {
        return busy;
    }

    public LiveData<Event<String>> toastEvent() {
        return toastEvent;
    }

    public LiveData<Event<String>> errorEvent() {
        return errorEvent;
    }

    public LiveData<Event<Boolean>> loggedOutEvent() {
        return loggedOutEvent;
    }

    public List<Language> supportedLanguages() {
        return languageRepository.getSupportedLanguages();
    }

    public String currentLanguage() {
        return languageRepository.getCurrentLanguage();
    }

    public boolean hasMockBackend() {
        return mockBackend != null;
    }

    public void ensureLoaded() {
        if (!initialized) {
            initialized = true;
            refreshAll(false);
        }
    }

    /** Goi khi ngon ngu vua thay doi de tai lai du lieu da ban dia hoa tu backend. */
    public void reloadForLanguageChange() {
        refreshAll(true);
    }

    public void refreshAll(boolean forceRefresh) {
        loadSites(forceRefresh);
        loadArtifact(selectedArtifactId);
        loadFavorites();
        loadVisitHistory();
        loadProfile();
    }

    /** Tai danh sach HeritageSite va cap nhat 4 trang thai LOADING -> SUCCESS / EMPTY / ERROR. */
    public void loadSites(boolean forceRefresh) {
        sitesUiState.setValue(UiState.loading());
        launch(() -> heritageRepository.getSites(forceRefresh), res -> {
            if (res.isSuccess() && res.getData() != null) {
                allSites = res.getData();
                sites.setValue(allSites);
                applySiteFilters();
                if (!allSites.isEmpty()) {
                    long targetSite = selectedSiteId != null ? selectedSiteId : allSites.get(0).getId();
                    selectSite(targetSite);
                }
            } else {
                String msg = I18n.errorMessage(res);
                sitesUiState.setValue(UiState.error(msg));
                errorEvent.setValue(new Event<>(msg));
            }
        });
    }

    /** Nut Thu lai (Retry) khi Tab 1 o trang thai Error. */
    public void retryLoadSites() {
        if (mockBackend != null && mockBackend.isSimulateNetworkError()) {
            mockBackend.setSimulateNetworkError(false);
        }
        loadSites(true);
    }

    /** Gia lap loi mang khi tai danh sach dia diem de kiem thu trang thai Error + Retry. */
    public void simulateSitesNetworkError() {
        if (mockBackend != null) {
            mockBackend.setSimulateNetworkError(true);
            loadSites(true);
        }
    }

    /** Tim kiem theo ten/khu vuc va loc theo danh muc tren Tab 1. */
    public void setSearchAndCategory(String query, String category) {
        this.searchQuery = query == null ? "" : query.trim();
        this.selectedCategory = (category == null || category.isBlank())
                ? HeritageSite.CATEGORY_ALL : category.trim();
        applySiteFilters();
    }

    public void clearFilters() {
        setSearchAndCategory("", HeritageSite.CATEGORY_ALL);
    }

    private void applySiteFilters() {
        List<HeritageSite> filtered = heritageRepository.filterSites(allSites, searchQuery, selectedCategory);
        if (filtered.isEmpty()) {
            sitesUiState.setValue(UiState.empty());
        } else {
            sitesUiState.setValue(UiState.success(filtered));
        }
    }

    /**
     * Chon mot dia diem (tu Tab 1 hoac bam Marker tren Tab 2) -> mo danh sach Artifact thuoc dia diem do.
     */
    public void selectSite(long siteId) {
        this.selectedSiteId = siteId;
        for (HeritageSite s : allSites) {
            if (s.getId() != null && s.getId() == siteId && s.getArtifacts() != null && !s.getArtifacts().isEmpty()) {
                selectedSiteArtifacts.setValue(s.getArtifacts());
                return;
            }
        }
        launch(() -> heritageRepository.getSiteArtifacts(siteId), res -> {
            if (res.isSuccess() && res.getData() != null) {
                selectedSiteArtifacts.setValue(res.getData());
            }
        });
    }

    public HeritageSite findSiteById(Long siteId) {
        if (siteId == null) {
            return null;
        }
        for (HeritageSite s : allSites) {
            if (siteId.equals(s.getId())) {
                return s;
            }
        }
        return allSites.isEmpty() ? null : allSites.get(0);
    }

    /** Tinh khoang cach (km) tu vi tri GPS cua nguoi dung toi dia diem di san. */
    public double distanceFromUserKm(HeritageSite site) {
        if (site == null || site.getLatitude() == null || site.getLongitude() == null) {
            return 0.0;
        }
        double dLat = Math.toRadians(site.getLatitude() - USER_GPS_LAT);
        double dLng = Math.toRadians(site.getLongitude() - USER_GPS_LNG);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(USER_GPS_LAT)) * Math.cos(Math.toRadians(site.getLatitude()))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return 6371.0 * 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(1.0 - a));
    }

    public void loadArtifact(long artifactId) {
        this.selectedArtifactId = artifactId;
        launch(() -> heritageRepository.getArtifact(artifactId), res -> {
            if (res.isSuccess() && res.getData() != null) {
                selectedArtifact.setValue(res.getData());
            }
        });
    }

    /** Chon hien vat tieu bieu cua khu di san. */
    public void inspectSiteFeaturedArtifact(long siteId) {
        selectSite(siteId);
        long artifactId = siteId == 1L ? 102L : (siteId == 2L ? 103L : 101L);
        loadArtifact(artifactId);
    }

    /** Gia lap tin hieu BLE Beacon (TV3) va goi GET /api/beacons/{id}/content. */
    public void simulateBeaconSignal() {
        BeaconSignalEvent event = beaconScanner.next();
        lastBeaconEvent.setValue(event);
        if (event.getEventType() == BeaconSignalEvent.EventType.EXIT) {
            bleBridge.onBeaconOutOfRange(event.getBeaconId());
        } else {
            bleBridge.onBeaconTriggered(event);
            launch(() -> heritageRepository.getBeaconContent(event.getBeaconId()), res -> {
                if (res.isSuccess() && res.getData() != null) {
                    Artifact art = res.getData();
                    selectedArtifactId = art.getId();
                    selectedArtifact.setValue(art);
                    HeritageSite site = findSiteById(art.getSiteId());
                    String siteName = site != null ? site.getName() : "";
                    visitHistoryRepository.recordArtifactView(art, siteName, VisitHistory.SOURCE_BEACON_BLE);
                    loadVisitHistory();
                }
            });
        }
    }

    public void loadFavorites() {
        launch(favoriteRepository::getFavorites, res -> {
            if (res.isSuccess() && res.getData() != null) {
                favorites.setValue(res.getData());
            }
        });
    }

    public boolean isFavorite(long artifactId) {
        List<Favorite> list = favorites.getValue();
        if (list == null) {
            return false;
        }
        return list.stream().anyMatch(f -> f.getArtifactId() != null && f.getArtifactId() == artifactId);
    }

    public void toggleFavorite(long artifactId) {
        boolean currentlyFav = isFavorite(artifactId);
        if (currentlyFav) {
            removeFavorite(artifactId);
        } else {
            launch(() -> favoriteRepository.addFavorite(artifactId), res -> {
                if (res.isSuccess()) {
                    loadFavorites();
                } else {
                    errorEvent.setValue(new Event<>(I18n.errorMessage(res)));
                }
            });
        }
    }

    public void removeFavorite(long artifactId) {
        launch(() -> favoriteRepository.removeFavorite(artifactId), res -> {
            if (res.isSuccess()) {
                loadFavorites();
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(res)));
            }
        });
    }

    /** Doc lich su tham quan qua GET /api/visit-history (khong nhan ban Interaction cua TV3). */
    public void loadVisitHistory() {
        launch(visitHistoryRepository::getVisitHistory, res -> {
            if (res.isSuccess() && res.getData() != null) {
                visitHistory.setValue(res.getData());
            }
        });
    }

    public void sendFiveStarFeedback(long artifactId) {
        FeedbackRequest req = new FeedbackRequest(artifactId, 5, "Great heritage artifact guide!");
        launch(() -> feedbackRepository.submit(req), res -> {
            if (res.isSuccess()) {
                toastEvent.setValue(new Event<>(I18n.tr("explore.feedback_sent")));
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(res)));
            }
        });
    }

    public void loadProfile() {
        launch(userRepository::getProfile, res -> {
            if (res.isSuccess() && res.getData() != null) {
                user.setValue(res.getData());
            }
        });
    }

    public void saveProfile(String fullName, String phone) {
        if (!Validators.isNotBlank(fullName)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.invalid_name")));
            return;
        }
        busy.setValue(true);
        launch(() -> userRepository.updateProfile(fullName, phone), res -> {
            busy.setValue(false);
            if (res.isSuccess() && res.getData() != null) {
                user.setValue(res.getData());
                toastEvent.setValue(new Event<>(I18n.tr("profile.saved_toast")));
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(res)));
            }
        });
    }

    /**
     * Doi ngon ngu: goi {@code PUT /api/users/me} voi {@code preferredLanguage},
     * cap nhat {@code SessionStorage} -> {@code Navigator} tu dong ve lai UI va tai du lieu ngon ngu moi.
     */
    public void changeLanguage(String languageCode) {
        if (languageCode == null || languageCode.equalsIgnoreCase(currentLanguage())) {
            return;
        }
        busy.setValue(true);
        launch(() -> languageRepository.changeLanguage(languageCode), (Result<User> res) -> {
            busy.setValue(false);
            Language langObj = languageRepository.findLanguage(languageCode);
            if (res.isSuccess()) {
                if (res.getData() != null) {
                    user.setValue(res.getData());
                }
                toastEvent.setValue(new Event<>(I18n.tr("profile.language_changed_toast", langObj.toString())));
            } else if (LanguageRepository.CODE_SAVED_LOCALLY.equals(res.getErrorCode())) {
                toastEvent.setValue(new Event<>(I18n.tr("profile.language_saved_local_toast")));
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(res)));
            }
        });
    }

    /**
     * Kiem thu truc quan AuthInterceptor: lam het han Access Token tren MockBackend
     * roi goi GET /api/users/me -> nhan 401 -> tu dong refresh token -> thanh cong.
     */
    public void simulateTokenExpiryAndVerifyRefresh() {
        if (mockBackend == null) {
            return;
        }
        mockBackend.expireAllAccessTokens();
        launch(userRepository::getProfile, res -> {
            if (res.isSuccess()) {
                user.setValue(res.getData());
                toastEvent.setValue(new Event<>(I18n.tr("profile.refresh_ok_toast")));
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(res)));
            }
        });
    }

    public void logout() {
        busy.setValue(true);
        launch(authRepository::logout, res -> {
            busy.setValue(false);
            loggedOutEvent.setValue(new Event<>(true));
        });
    }

    @Override
    protected void onCleared() {
        beaconScanner.stop();
    }
}
