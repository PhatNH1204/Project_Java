package com.heritage.tv2.ui.detail;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.Screen;
import com.heritage.tv2.ui.base.UiState;
import com.heritage.tv2.ui.theme.UiTheme;
import com.heritage.tv2.util.I18n;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

/**
 * Man hinh Chi tiet Hien vat ({@code ArtifactDetailScreen} - Gate 3 Phan 1 &amp; Phan 2).
 *
 * <p>Hien thi day du 5 thanh phan:</p>
 * <ol>
 *     <li><b>Van ban thuyet minh</b> + <b>Nut Yeu thich (Optimistic UI)</b>.</li>
 *     <li><b>Thu vien hinh anh</b> (co anh du phong / fallback placeholder khi link anh bi loi).</li>
 *     <li><b>Trinh phat Am thanh</b> (Play / Pause / Seek {@link JSlider} + bao loi rieng neu file hong).</li>
 *     <li><b>Trinh phat Video</b> (Play / Pause / Seek {@link JSlider} + bao loi rieng neu file hong).</li>
 *     <li><b>Danh gia hien vat / Gui phan hoi (Phoi hop TV5)</b>: chon so sao (1-5) + nhap nhan xet,
 *     validate bat buoc va goi {@code POST /api/feedback}.</li>
 * </ol>
 */
public class ArtifactDetailScreen extends Screen {

    private final ArtifactDetailViewModel viewModel;
    private final Navigator navigator;

    private final JPanel bodyHost = new JPanel();
    private final JPanel outOfRangeBannerPanel = new JPanel(new BorderLayout());
    private final JLabel outOfRangeNoticeLabel = UiTheme.subtitleLabel("");
    private JPanel cacheBadgePanel;
    private JLabel cacheBadgeLabel;
    private Timer playbackTimer;

    // Live references for timer ticks & dynamic state updates
    private JSlider audioSlider;
    private JLabel audioTimeLabel;
    private JButton audioPlayBtn;
    private JSlider videoSlider;
    private JLabel videoTimeLabel;
    private JButton videoPlayBtn;
    private VideoCanvasPanel videoCanvas;
    private JButton favoriteBtn;

    // Feedback form components
    private final List<JButton> starButtons = new ArrayList<>();
    private JTextArea feedbackCommentArea;
    private JButton feedbackSubmitBtn;
    private JLabel feedbackStatusLabel;

    public ArtifactDetailScreen(ArtifactDetailViewModel viewModel, Navigator navigator) {
        this.viewModel = viewModel;
        this.navigator = navigator;
        buildUi();
    }

    private void buildUi() {
        JPanel topBar = new JPanel(new BorderLayout(8, 0));
        topBar.setBackground(UiTheme.BG_CARD);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UiTheme.BORDER_COLOR),
                new EmptyBorder(8, 12, 8, 12)));

        JButton backBtn = UiTheme.secondaryButton(I18n.tr("detail.back_btn"));
        backBtn.addActionListener(e -> navigator.navigateBackToMain());
        topBar.add(backBtn, BorderLayout.WEST);

        JLabel title = UiTheme.sectionLabel(I18n.tr("detail.header"));
        topBar.add(title, BorderLayout.CENTER);

        // Nhan trang thai nho khi roi vung phu song Beacon (an mac dinh, hien in-place khong anh huong Audio/Video)
        outOfRangeBannerPanel.setBackground(new Color(255, 243, 205));
        outOfRangeBannerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UiTheme.ACCENT_GOLD),
                new EmptyBorder(6, 12, 6, 12)));
        outOfRangeNoticeLabel.setForeground(UiTheme.PRIMARY_DARK);
        outOfRangeBannerPanel.add(outOfRangeNoticeLabel, BorderLayout.CENTER);
        outOfRangeBannerPanel.setVisible(false);

        JPanel northWrapper = new JPanel(new BorderLayout());
        northWrapper.add(topBar, BorderLayout.NORTH);
        northWrapper.add(outOfRangeBannerPanel, BorderLayout.SOUTH);

        bodyHost.setLayout(new BoxLayout(bodyHost, BoxLayout.Y_AXIS));
        bodyHost.setBackground(UiTheme.BG_APP);
        bodyHost.setBorder(new EmptyBorder(12, 14, 16, 14));

        add(northWrapper, BorderLayout.NORTH);
        add(UiTheme.verticalScroll(bodyHost), BorderLayout.CENTER);

        playbackTimer = new Timer(1000, e -> onPlaybackTick());
    }

    private void onPlaybackTick() {
        UiState<Artifact> state = viewModel.artifactState().getValue();
        if (state == null || !state.isSuccess() || state.getData() == null) {
            return;
        }
        Artifact artifact = state.getData();

        if (viewModel.isAudioPlaying()) {
            Media audio = viewModel.resolveAudioMedia(artifact);
            int max = audio != null && audio.getDuration() != null ? audio.getDuration() : 120;
            int next = viewModel.getAudioPositionSeconds() + 1;
            if (next >= max) {
                viewModel.seekAudio(0, max);
                viewModel.setAudioPlaying(false);
                if (audioPlayBtn != null) {
                    audioPlayBtn.setText(I18n.tr("detail.media_play"));
                }
            } else {
                viewModel.seekAudio(next, max);
            }
            if (audioSlider != null && !audioSlider.getValueIsAdjusting()) {
                audioSlider.setValue(viewModel.getAudioPositionSeconds());
            }
            if (audioTimeLabel != null) {
                audioTimeLabel.setText(formatDuration(viewModel.getAudioPositionSeconds()) + " / " + formatDuration(max));
            }
        }

        if (viewModel.isVideoPlaying()) {
            Media video = viewModel.resolveVideoMedia(artifact);
            int max = video != null && video.getDuration() != null ? video.getDuration() : 90;
            int next = viewModel.getVideoPositionSeconds() + 1;
            if (next >= max) {
                viewModel.seekVideo(0, max);
                viewModel.setVideoPlaying(false);
                if (videoPlayBtn != null) {
                    videoPlayBtn.setText(I18n.tr("detail.media_play"));
                }
            } else {
                viewModel.seekVideo(next, max);
            }
            if (videoSlider != null && !videoSlider.getValueIsAdjusting()) {
                videoSlider.setValue(viewModel.getVideoPositionSeconds());
            }
            if (videoTimeLabel != null) {
                videoTimeLabel.setText(formatDuration(viewModel.getVideoPositionSeconds()) + " / " + formatDuration(max));
            }
            if (videoCanvas != null) {
                videoCanvas.repaint();
            }
        }
    }

    private void renderState(UiState<Artifact> state) {
        bodyHost.removeAll();
        if (state == null || state.isLoading()) {
            JPanel loadingCard = UiTheme.cardPanel();
            loadingCard.setLayout(new BoxLayout(loadingCard, BoxLayout.Y_AXIS));
            loadingCard.add(UiTheme.sectionLabel(I18n.tr("app.loading")));
            loadingCard.add(Box.createVerticalStrut(8));
            JProgressBar bar = new JProgressBar();
            bar.setIndeterminate(true);
            bar.setAlignmentX(Component.LEFT_ALIGNMENT);
            loadingCard.add(bar);
            bodyHost.add(loadingCard);
        } else if (state.isError()) {
            JPanel errCard = UiTheme.cardPanel();
            errCard.setLayout(new BoxLayout(errCard, BoxLayout.Y_AXIS));
            errCard.setBackground(new Color(253, 237, 237));
            errCard.add(UiTheme.sectionLabel("⚠ " + I18n.tr("explore.state_error_title")));
            errCard.add(Box.createVerticalStrut(4));
            errCard.add(UiTheme.wrappingText(state.getErrorMessage(), UiTheme.FONT_BODY, UiTheme.DANGER));
            errCard.add(Box.createVerticalStrut(8));
            JButton retry = UiTheme.primaryButton(I18n.tr("explore.retry_btn"));
            retry.addActionListener(e -> viewModel.loadArtifact());
            errCard.add(retry);
            bodyHost.add(errCard);
        } else if (state.getData() != null) {
            renderArtifactContent(state.getData());
        }
        bodyHost.revalidate();
        bodyHost.repaint();
    }

    private void renderArtifactContent(Artifact artifact) {
        // 0. ArtifactCache status badge
        boolean offline = Boolean.TRUE.equals(viewModel.fromOfflineCache().getValue());
        cacheBadgePanel = new JPanel(new BorderLayout());
        cacheBadgePanel.setBackground(offline ? new Color(255, 243, 205) : new Color(228, 245, 233));
        cacheBadgePanel.setBorder(UiTheme.cardBorder());
        cacheBadgePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        cacheBadgeLabel = UiTheme.subtitleLabel(
                offline ? I18n.tr("detail.badge_offline") : I18n.tr("detail.badge_cached"));
        cacheBadgeLabel.setForeground(offline ? UiTheme.PRIMARY_DARK : UiTheme.SUCCESS);
        cacheBadgePanel.add(cacheBadgeLabel, BorderLayout.CENTER);
        bodyHost.add(cacheBadgePanel);
        bodyHost.add(Box.createVerticalStrut(8));

        // 1. Narrative Text Section + Optimistic Favorite Button
        bodyHost.add(buildNarrativeSection(artifact));
        bodyHost.add(Box.createVerticalStrut(10));

        // 2. Photo Gallery Section (with fallback image on error)
        bodyHost.add(buildPhotoGallerySection(artifact));
        bodyHost.add(Box.createVerticalStrut(10));

        // 3. Audio Player Section (Play/Pause/Seek + isolated error handling)
        bodyHost.add(buildAudioPlayerSection(artifact));
        bodyHost.add(Box.createVerticalStrut(10));

        // 4. Video Player Section (Play/Pause/Seek + isolated error handling)
        bodyHost.add(buildVideoPlayerSection(artifact));
        bodyHost.add(Box.createVerticalStrut(10));

        // 5. Rating & Feedback Section (Gate 3 - Part 2 / TV5)
        bodyHost.add(buildFeedbackSection());
    }

    // ============================================ 1. Narrative Text Section
    private JPanel buildNarrativeSection(Artifact artifact) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UiTheme.BG_CARD);
        card.setBorder(UiTheme.cardBorder());
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        ContentTranslation tr = viewModel.resolveTranslation(artifact);
        String title = tr != null && tr.getTitle() != null ? tr.getTitle() : artifact.getName();
        String body = tr != null && tr.getBodyText() != null ? tr.getBodyText() : artifact.getShortDescription();

        card.add(UiTheme.subtitleLabel(I18n.tr("detail.section_text") + " • " + artifact.getCode()));
        card.add(Box.createVerticalStrut(3));
        card.add(UiTheme.titleLabel("🏺 " + title));
        card.add(Box.createVerticalStrut(3));
        card.add(UiTheme.subtitleLabel(I18n.tr("explore.period", artifact.getPeriod())));

        if (viewModel.isUsingFallbackTranslation(artifact)) {
            card.add(Box.createVerticalStrut(6));
            JPanel fbBanner = new JPanel(new BorderLayout());
            fbBanner.setBackground(UiTheme.ACCENT_SOFT);
            fbBanner.setBorder(new EmptyBorder(6, 8, 6, 8));
            fbBanner.setAlignmentX(Component.LEFT_ALIGNMENT);
            fbBanner.add(UiTheme.wrappingText(
                    I18n.tr("detail.badge_fallback_lang",
                            viewModel.currentLanguage().toUpperCase(Locale.ROOT),
                            AppConfig.DEFAULT_LANGUAGE.toUpperCase(Locale.ROOT)),
                    UiTheme.FONT_SMALL, UiTheme.PRIMARY_DARK), BorderLayout.CENTER);
            card.add(fbBanner);
        }

        card.add(Box.createVerticalStrut(8));
        card.add(UiTheme.wrappingText(body, UiTheme.FONT_BODY, UiTheme.TEXT_PRIMARY));
        card.add(Box.createVerticalStrut(10));

        // Optimistic Favorite Button
        favoriteBtn = UiTheme.primaryButton(I18n.tr("explore.fav_add"));
        favoriteBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        updateFavoriteButtonVisual(Boolean.TRUE.equals(viewModel.favoriteState().getValue()));
        favoriteBtn.addActionListener(e -> viewModel.toggleFavorite());
        card.add(favoriteBtn);

        return card;
    }

    private void updateFavoriteButtonVisual(boolean isFav) {
        if (favoriteBtn == null) {
            return;
        }
        if (isFav) {
            favoriteBtn.setText(I18n.tr("explore.fav_remove"));
            favoriteBtn.setBackground(new Color(253, 237, 237));
            favoriteBtn.setForeground(UiTheme.DANGER);
            favoriteBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UiTheme.DANGER, 1, true),
                    new EmptyBorder(7, 12, 7, 12)));
        } else {
            favoriteBtn.setText(I18n.tr("explore.fav_add"));
            favoriteBtn.setBackground(UiTheme.PRIMARY);
            favoriteBtn.setForeground(Color.WHITE);
            favoriteBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UiTheme.PRIMARY_DARK, 1, true),
                    new EmptyBorder(8, 14, 8, 14)));
        }
    }

    // ============================================ 2. Photo Gallery Section
    private JPanel buildPhotoGallerySection(Artifact artifact) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UiTheme.BG_CARD);
        card.setBorder(UiTheme.cardBorder());
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        List<Media> images = viewModel.imageMediaList(artifact);
        int total = images.size();
        int idx = total == 0 ? 0 : Math.min(viewModel.getCurrentImageIndex(), total - 1);
        Media currentMedia = total == 0 ? null : images.get(idx);
        boolean broken = viewModel.isImageBroken(currentMedia);

        JPanel headerRow = new JPanel(new BorderLayout());
        headerRow.setOpaque(false);
        headerRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerRow.add(UiTheme.sectionLabel(
                I18n.tr("detail.section_gallery", total == 0 ? 0 : (idx + 1), total)), BorderLayout.WEST);

        JButton toggleErrBtn = UiTheme.secondaryButton(I18n.tr("detail.img_toggle_broken"));
        toggleErrBtn.setFont(UiTheme.FONT_BADGE);
        toggleErrBtn.addActionListener(e -> {
            viewModel.toggleForceCurrentImageBroken();
            renderState(viewModel.artifactState().getValue());
        });
        headerRow.add(toggleErrBtn, BorderLayout.EAST);
        card.add(headerRow);
        card.add(Box.createVerticalStrut(6));

        ImageCanvasPanel imgCanvas = new ImageCanvasPanel(artifact, currentMedia, idx, broken);
        imgCanvas.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(imgCanvas);
        card.add(Box.createVerticalStrut(6));

        if (currentMedia != null) {
            card.add(UiTheme.subtitleLabel("URL: " + currentMedia.getUrl()));
        }
        if (broken && currentMedia != null) {
            card.add(Box.createVerticalStrut(3));
            card.add(UiTheme.wrappingText(
                    I18n.tr("detail.img_fallback_sub", currentMedia.getUrl()),
                    UiTheme.FONT_SMALL, UiTheme.DANGER));
        }

        if (total > 1) {
            card.add(Box.createVerticalStrut(6));
            JPanel navRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            navRow.setOpaque(false);
            navRow.setAlignmentX(Component.LEFT_ALIGNMENT);

            JButton prevBtn = UiTheme.secondaryButton(I18n.tr("detail.img_prev"));
            prevBtn.addActionListener(e -> {
                viewModel.previousImage(total);
                renderState(viewModel.artifactState().getValue());
            });
            JButton nextBtn = UiTheme.secondaryButton(I18n.tr("detail.img_next"));
            nextBtn.addActionListener(e -> {
                viewModel.nextImage(total);
                renderState(viewModel.artifactState().getValue());
            });
            navRow.add(prevBtn);
            navRow.add(nextBtn);
            card.add(navRow);
        }
        return card;
    }

    // ============================================ 3. Audio Player Section
    private JPanel buildAudioPlayerSection(Artifact artifact) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UiTheme.BG_CARD);
        card.setBorder(UiTheme.cardBorder());
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        Media audio = viewModel.resolveAudioMedia(artifact);
        boolean broken = viewModel.isAudioBroken(artifact);

        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        topRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        topRow.add(UiTheme.sectionLabel(I18n.tr("detail.section_audio")), BorderLayout.WEST);

        JButton simBrokenBtn = UiTheme.secondaryButton(I18n.tr("detail.media_sim_broken"));
        simBrokenBtn.setFont(UiTheme.FONT_BADGE);
        simBrokenBtn.addActionListener(e -> {
            viewModel.setForceAudioBroken(!viewModel.isAudioBroken(artifact));
            renderState(viewModel.artifactState().getValue());
        });
        topRow.add(simBrokenBtn, BorderLayout.EAST);
        card.add(topRow);
        card.add(Box.createVerticalStrut(6));

        if (audio == null || broken) {
            card.add(buildIsolatedMediaErrorBox(
                    audio != null ? audio.getUrl() : "audio-missing.mp3",
                    () -> {
                        viewModel.setForceAudioBroken(false);
                        renderState(viewModel.artifactState().getValue());
                    }));
            return card;
        }

        int duration = audio.getDuration() != null ? audio.getDuration() : 120;
        int pos = Math.min(viewModel.getAudioPositionSeconds(), duration);

        card.add(UiTheme.subtitleLabel("🎵 " + audio.getUrl()));
        card.add(Box.createVerticalStrut(6));

        audioSlider = new JSlider(0, duration, pos);
        audioSlider.setOpaque(false);
        audioSlider.setAlignmentX(Component.LEFT_ALIGNMENT);
        audioSlider.addChangeListener(e -> {
            viewModel.seekAudio(audioSlider.getValue(), duration);
            if (audioTimeLabel != null) {
                audioTimeLabel.setText(formatDuration(viewModel.getAudioPositionSeconds())
                        + " / " + formatDuration(duration));
            }
        });
        card.add(audioSlider);

        JPanel ctrlRow = new JPanel(new BorderLayout(8, 0));
        ctrlRow.setOpaque(false);
        ctrlRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        audioPlayBtn = UiTheme.primaryButton(
                viewModel.isAudioPlaying() ? I18n.tr("detail.media_pause") : I18n.tr("detail.media_play"));
        audioPlayBtn.addActionListener(e -> {
            boolean nextState = !viewModel.isAudioPlaying();
            viewModel.setAudioPlaying(nextState);
            audioPlayBtn.setText(nextState ? I18n.tr("detail.media_pause") : I18n.tr("detail.media_play"));
        });

        audioTimeLabel = UiTheme.subtitleLabel(formatDuration(pos) + " / " + formatDuration(duration));
        ctrlRow.add(audioPlayBtn, BorderLayout.WEST);
        ctrlRow.add(audioTimeLabel, BorderLayout.EAST);
        card.add(ctrlRow);
        return card;
    }

    // ============================================ 4. Video Player Section
    private JPanel buildVideoPlayerSection(Artifact artifact) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UiTheme.BG_CARD);
        card.setBorder(UiTheme.cardBorder());
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        Media video = viewModel.resolveVideoMedia(artifact);
        boolean broken = viewModel.isVideoBroken(artifact);

        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        topRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        topRow.add(UiTheme.sectionLabel(I18n.tr("detail.section_video")), BorderLayout.WEST);

        if (video != null) {
            JButton simBrokenBtn = UiTheme.secondaryButton(I18n.tr("detail.media_sim_broken"));
            simBrokenBtn.setFont(UiTheme.FONT_BADGE);
            simBrokenBtn.addActionListener(e -> {
                viewModel.setForceVideoBroken(!viewModel.isVideoBroken(artifact));
                renderState(viewModel.artifactState().getValue());
            });
            topRow.add(simBrokenBtn, BorderLayout.EAST);
        }
        card.add(topRow);
        card.add(Box.createVerticalStrut(6));

        if (video == null) {
            card.add(UiTheme.subtitleLabel(I18n.tr("detail.no_video")));
            return card;
        }

        if (broken) {
            card.add(buildIsolatedMediaErrorBox(
                    video.getUrl(),
                    () -> {
                        viewModel.setForceVideoBroken(false);
                        renderState(viewModel.artifactState().getValue());
                    }));
            return card;
        }

        int duration = video.getDuration() != null ? video.getDuration() : 90;
        int pos = Math.min(viewModel.getVideoPositionSeconds(), duration);

        videoCanvas = new VideoCanvasPanel(artifact.getName(), video.getUrl());
        videoCanvas.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(videoCanvas);
        card.add(Box.createVerticalStrut(6));

        videoSlider = new JSlider(0, duration, pos);
        videoSlider.setOpaque(false);
        videoSlider.setAlignmentX(Component.LEFT_ALIGNMENT);
        videoSlider.addChangeListener(e -> {
            viewModel.seekVideo(videoSlider.getValue(), duration);
            if (videoTimeLabel != null) {
                videoTimeLabel.setText(formatDuration(viewModel.getVideoPositionSeconds())
                        + " / " + formatDuration(duration));
            }
            if (videoCanvas != null) {
                videoCanvas.repaint();
            }
        });
        card.add(videoSlider);

        JPanel ctrlRow = new JPanel(new BorderLayout(8, 0));
        ctrlRow.setOpaque(false);
        ctrlRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        videoPlayBtn = UiTheme.primaryButton(
                viewModel.isVideoPlaying() ? I18n.tr("detail.media_pause") : I18n.tr("detail.media_play"));
        videoPlayBtn.addActionListener(e -> {
            boolean nextState = !viewModel.isVideoPlaying();
            viewModel.setVideoPlaying(nextState);
            videoPlayBtn.setText(nextState ? I18n.tr("detail.media_pause") : I18n.tr("detail.media_play"));
            if (videoCanvas != null) {
                videoCanvas.repaint();
            }
        });

        videoTimeLabel = UiTheme.subtitleLabel(formatDuration(pos) + " / " + formatDuration(duration));
        ctrlRow.add(videoPlayBtn, BorderLayout.WEST);
        ctrlRow.add(videoTimeLabel, BorderLayout.EAST);
        card.add(ctrlRow);
        return card;
    }

    // ===================================== 5. Rating & Feedback Section (TV5)
    private JPanel buildFeedbackSection() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UiTheme.BG_CARD);
        card.setBorder(UiTheme.cardBorder());
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(UiTheme.sectionLabel(I18n.tr("feedback.section_title")));
        card.add(Box.createVerticalStrut(6));
        card.add(UiTheme.subtitleLabel(I18n.tr("feedback.rating_label")));
        card.add(Box.createVerticalStrut(4));

        // 5 interactive star buttons (1..5)
        JPanel starRow = new JPanel(new GridLayout(1, 5, 4, 0));
        starRow.setOpaque(false);
        starRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        starRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        starButtons.clear();
        for (int s = 1; s <= 5; s++) {
            final int starValue = s;
            JButton starBtn = new JButton(starValue + " ★");
            starBtn.setFont(UiTheme.FONT_BODY_BOLD);
            starBtn.setFocusPainted(false);
            starBtn.setOpaque(true);
            starBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            starBtn.addActionListener(e -> {
                viewModel.setSelectedRating(starValue);
                refreshStarButtonsVisual();
            });
            starButtons.add(starBtn);
            starRow.add(starBtn);
        }
        refreshStarButtonsVisual();
        card.add(starRow);
        card.add(Box.createVerticalStrut(8));

        card.add(UiTheme.subtitleLabel(I18n.tr("feedback.comment_label")));
        card.add(Box.createVerticalStrut(4));

        feedbackCommentArea = new JTextArea(viewModel.getDraftComment(), 3, 24);
        feedbackCommentArea.setFont(UiTheme.FONT_BODY);
        feedbackCommentArea.setLineWrap(true);
        feedbackCommentArea.setWrapStyleWord(true);
        JScrollPane commentScroll = new JScrollPane(feedbackCommentArea);
        commentScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentScroll.setBorder(BorderFactory.createLineBorder(UiTheme.BORDER_COLOR, 1, true));
        commentScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        card.add(commentScroll);
        card.add(Box.createVerticalStrut(8));

        feedbackStatusLabel = UiTheme.subtitleLabel("");
        feedbackStatusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        updateFeedbackStatusLabel();
        card.add(feedbackStatusLabel);
        card.add(Box.createVerticalStrut(6));

        boolean busy = Boolean.TRUE.equals(viewModel.feedbackSubmitting().getValue());
        feedbackSubmitBtn = UiTheme.primaryButton(
                busy ? I18n.tr("feedback.submitting") : I18n.tr("feedback.submit_btn"));
        feedbackSubmitBtn.setEnabled(!busy);
        feedbackSubmitBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        feedbackSubmitBtn.addActionListener(e ->
                viewModel.submitFeedback(viewModel.getSelectedRating(), feedbackCommentArea.getText()));
        card.add(feedbackSubmitBtn);

        return card;
    }

    private void refreshStarButtonsVisual() {
        Integer rating = viewModel.getSelectedRating();
        int current = rating == null ? 0 : rating;
        for (int i = 0; i < starButtons.size(); i++) {
            int starVal = i + 1;
            JButton btn = starButtons.get(i);
            boolean active = starVal <= current;
            btn.setBackground(active ? UiTheme.ACCENT_GOLD : UiTheme.ACCENT_SOFT);
            btn.setForeground(active ? Color.WHITE : UiTheme.PRIMARY_DARK);
            btn.setBorder(BorderFactory.createLineBorder(UiTheme.ACCENT_GOLD, 1, true));
        }
    }

    private void updateFeedbackStatusLabel() {
        if (feedbackStatusLabel == null) {
            return;
        }
        String err = viewModel.feedbackErrorMessage().getValue();
        String ok = viewModel.feedbackSuccessMessage().getValue();
        if (err != null && !err.isBlank()) {
            feedbackStatusLabel.setText("⚠ " + err);
            feedbackStatusLabel.setForeground(UiTheme.DANGER);
        } else if (ok != null && !ok.isBlank()) {
            feedbackStatusLabel.setText(ok);
            feedbackStatusLabel.setForeground(UiTheme.SUCCESS);
        } else {
            feedbackStatusLabel.setText("");
        }
    }

    private JPanel buildIsolatedMediaErrorBox(String brokenUrl, Runnable onRetry) {
        JPanel box = new JPanel();
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.setBackground(new Color(253, 237, 237));
        box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiTheme.DANGER, 1, true),
                new EmptyBorder(8, 10, 8, 10)));
        box.setAlignmentX(Component.LEFT_ALIGNMENT);

        box.add(UiTheme.wrappingText(
                I18n.tr("detail.media_error_msg", brokenUrl),
                UiTheme.FONT_SMALL, UiTheme.DANGER));
        box.add(Box.createVerticalStrut(6));

        JButton retryBtn = UiTheme.secondaryButton(I18n.tr("detail.media_retry"));
        retryBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        retryBtn.addActionListener(e -> onRetry.run());
        box.add(retryBtn);
        return box;
    }

    private static String formatDuration(int totalSeconds) {
        int m = Math.max(0, totalSeconds) / 60;
        int s = Math.max(0, totalSeconds) % 60;
        return String.format(Locale.US, "%02d:%02d", m, s);
    }

    @Override
    public void onShow() {
        observe(viewModel.artifactState(), this::renderState);
        observe(viewModel.fromOfflineCache(), offline -> {
            boolean isOffline = Boolean.TRUE.equals(offline);
            if (cacheBadgePanel != null && cacheBadgeLabel != null) {
                cacheBadgePanel.setBackground(isOffline ? new Color(255, 243, 205) : new Color(228, 245, 233));
                cacheBadgeLabel.setText(isOffline ? I18n.tr("detail.badge_offline") : I18n.tr("detail.badge_cached"));
                cacheBadgeLabel.setForeground(isOffline ? UiTheme.PRIMARY_DARK : UiTheme.SUCCESS);
            }
        });
        observe(viewModel.beaconOutOfRangeNotice(), notice -> {
            if (notice != null && !notice.isBlank()) {
                outOfRangeNoticeLabel.setText("📶 " + notice);
                outOfRangeBannerPanel.setVisible(true);
            } else {
                outOfRangeBannerPanel.setVisible(false);
            }
            revalidate();
            repaint();
        });
        observe(viewModel.favoriteState(), fav ->
                updateFavoriteButtonVisual(Boolean.TRUE.equals(fav)));
        observe(viewModel.feedbackSubmitting(), submitting -> {
            boolean b = Boolean.TRUE.equals(submitting);
            if (feedbackSubmitBtn != null) {
                feedbackSubmitBtn.setEnabled(!b);
                feedbackSubmitBtn.setText(b ? I18n.tr("feedback.submitting") : I18n.tr("feedback.submit_btn"));
            }
        });
        observe(viewModel.feedbackSuccessMessage(), ok -> {
            updateFeedbackStatusLabel();
            if (ok != null && feedbackCommentArea != null) {
                feedbackCommentArea.setText("");
            }
        });
        observe(viewModel.feedbackErrorMessage(), err -> updateFeedbackStatusLabel());
        observe(viewModel.toastEvent(), ev -> {
            String msg = ev.getIfNotHandled();
            if (msg != null) {
                navigator.showToast(msg, false);
            }
        });
        observe(viewModel.errorEvent(), ev -> {
            String msg = ev.getIfNotHandled();
            if (msg != null) {
                navigator.showToast(msg, true);
            }
        });

        viewModel.loadArtifact();
        playbackTimer.start();
    }

    @Override
    public void onHide() {
        playbackTimer.stop();
        viewModel.setAudioPlaying(false);
        viewModel.setVideoPlaying(false);
        super.onHide();
    }

    /** Canvas hien thi hinh anh hien vat hoac Anh du phong (Fallback Image) khi URL bi loi. */
    private static final class ImageCanvasPanel extends JPanel {
        private final Artifact artifact;
        private final Media media;
        private final int imageIndex;
        private final boolean fallbackPlaceholder;

        ImageCanvasPanel(Artifact artifact, Media media, int imageIndex, boolean fallbackPlaceholder) {
            this.artifact = artifact;
            this.media = media;
            this.imageIndex = imageIndex;
            this.fallbackPlaceholder = fallbackPlaceholder;
            setPreferredSize(new Dimension(320, 145));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 145));
            setBorder(BorderFactory.createLineBorder(UiTheme.BORDER_COLOR, 1, true));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            if (fallbackPlaceholder) {
                g2.setColor(new Color(242, 234, 228));
                g2.fillRect(0, 0, w, h);
                g2.setColor(new Color(205, 185, 170));
                g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                        10f, new float[]{6f, 6f}, 0f));
                g2.drawRoundRect(10, 10, w - 20, h - 20, 12, 12);

                g2.setColor(UiTheme.PRIMARY_DARK);
                g2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
                g2.drawString("🏛 " + I18n.tr("detail.img_fallback_title"), 22, h / 2 - 4);

                g2.setColor(UiTheme.TEXT_SECONDARY);
                g2.setFont(UiTheme.FONT_SMALL);
                g2.drawString(artifact.getName() + " (" + artifact.getCode() + ")", 22, h / 2 + 18);
                g2.dispose();
                return;
            }

            Color c1 = imageIndex == 0 ? new Color(115, 38, 24)
                    : (imageIndex == 1 ? new Color(68, 92, 72) : new Color(92, 68, 36));
            Color c2 = new Color(197, 151, 62);
            g2.setPaint(new GradientPaint(0, 0, c1, w, h, c2));
            g2.fillRect(0, 0, w, h);

            g2.setColor(new Color(255, 245, 220, 90));
            g2.setStroke(new BasicStroke(2f));
            int cx = w - 65;
            int cy = h / 2;
            g2.drawOval(cx - 42, cy - 42, 84, 84);
            g2.drawOval(cx - 26, cy - 26, 52, 52);
            g2.fillOval(cx - 8, cy - 8, 16, 16);

            g2.setColor(Color.WHITE);
            g2.setFont(UiTheme.FONT_H2);
            g2.drawString(artifact.getName(), 16, 36);

            g2.setColor(UiTheme.ACCENT_SOFT);
            g2.setFont(UiTheme.FONT_SMALL);
            g2.drawString(artifact.getPeriod() != null ? artifact.getPeriod() : "", 16, 58);

            if (media != null) {
                g2.setFont(UiTheme.FONT_BADGE);
                g2.drawString("Photo #" + (imageIndex + 1) + " • " + media.getUrl(), 16, h - 16);
            }
            g2.dispose();
        }
    }

    /** Khung man hinh trinh phat Video 360. */
    private final class VideoCanvasPanel extends JPanel {
        private final String artifactName;
        private final String videoUrl;

        VideoCanvasPanel(String artifactName, String videoUrl) {
            this.artifactName = artifactName;
            this.videoUrl = videoUrl;
            setPreferredSize(new Dimension(320, 125));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 125));
            setBackground(new Color(24, 22, 26));
            setBorder(BorderFactory.createLineBorder(UiTheme.BORDER_COLOR, 1, true));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int pos = viewModel.getVideoPositionSeconds();
            boolean playing = viewModel.isVideoPlaying();

            int barX = (pos * 17) % Math.max(w - 40, 1);
            g2.setColor(new Color(197, 151, 62, 65));
            g2.fillRect(barX, 0, 40, h);

            g2.setColor(Color.WHITE);
            g2.setFont(UiTheme.FONT_BODY_BOLD);
            String status = playing ? ("▶ " + I18n.tr("detail.media_playing"))
                    : ("⏸ " + I18n.tr("detail.media_paused"));
            g2.drawString(status + " (" + formatDuration(pos) + ")", 14, 30);

            g2.setColor(UiTheme.ACCENT_GOLD);
            g2.setFont(UiTheme.FONT_SMALL);
            g2.drawString("360° • " + artifactName, 14, 54);

            g2.setColor(new Color(190, 190, 190));
            g2.setFont(UiTheme.FONT_BADGE);
            g2.drawString(videoUrl, 14, h - 14);
            g2.dispose();
        }
    }
}
