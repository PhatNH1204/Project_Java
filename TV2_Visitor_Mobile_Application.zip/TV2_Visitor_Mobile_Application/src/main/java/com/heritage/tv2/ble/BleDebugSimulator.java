package com.heritage.tv2.ble;

import com.heritage.tv2.api.mock.MockDataSource;
import com.heritage.tv2.model.BeaconSignalEvent;

import java.util.List;

/**
 * Cong cu Debug Simulator phuc vu kiem thu tich hop TV2 - TV3 - TV6 (Gate 4).
 *
 * <p>Chi bat khi {@code AppConfig.DEBUG} hoac {@code AppConfig.ENABLE_BLE_SIMULATOR = true}.
 * Gia lap truc tiep 4 kich ban test chuan bang cach goi vao {@link BleBridgeListener}
 * (TUYET DOI KHONG chua thuat toan quet BLE, loc RSSI hay chong lap cua TV3):</p>
 * <ol>
 *     <li><b>Kich ban 1</b>: Beacon moi vao vung ({@code ENTER}).</li>
 *     <li><b>Kich ban 2</b>: Beacon roi vung phu song ({@code onBeaconOutOfRange}).</li>
 *     <li><b>Kich ban 3</b>: Chuyen vung sang Beacon khac ({@code SWITCH}).</li>
 *     <li><b>Kich ban 4</b>: Gia lap tat Bluetooth / tu choi quyen ({@code onBleError}).</li>
 * </ol>
 */
public class BleDebugSimulator {

    private static final List<String> BEACON_IDS = List.of("B-101", "B-102", "B-103", "B-104");

    private final BleBridgeListener bridgeListener;
    private int currentIndex = 0;
    private boolean toggleErrorType = false;

    public BleDebugSimulator(BleBridgeListener bridgeListener) {
        this.bridgeListener = bridgeListener;
    }

    public String currentBeaconId() {
        return BEACON_IDS.get(currentIndex);
    }

    /** (1) Kich ban 1: Beacon moi vao vung (ENTER). */
    public BeaconSignalEvent triggerScenario1EnterBeacon() {
        return triggerEnterBeacon(BEACON_IDS.get(currentIndex));
    }

    public BeaconSignalEvent triggerEnterBeacon(String beaconId) {
        int idx = BEACON_IDS.indexOf(beaconId);
        if (idx >= 0) {
            currentIndex = idx;
        }
        int minor = 101 + Math.max(0, idx);
        BeaconSignalEvent event = new BeaconSignalEvent(
                beaconId,
                MockDataSource.BEACON_UUID,
                MockDataSource.BEACON_MAJOR,
                minor,
                -58,
                BeaconSignalEvent.EventType.ENTER,
                System.currentTimeMillis());
        bridgeListener.onBeaconTriggered(event);
        return event;
    }

    /** (2) Kich ban 2: Beacon hien tai roi vung phu song (Out of Range). */
    public String triggerScenario2OutOfRange() {
        String beaconId = BEACON_IDS.get(currentIndex);
        bridgeListener.onBeaconOutOfRange(beaconId);
        return beaconId;
    }

    public void triggerOutOfRange(String beaconId) {
        bridgeListener.onBeaconOutOfRange(beaconId);
    }

    /** (3) Kich ban 3: Chuyen vung sang Beacon khac (SWITCH). */
    public BeaconSignalEvent triggerScenario3SwitchBeacon() {
        currentIndex = (currentIndex + 1) % BEACON_IDS.size();
        String nextBeaconId = BEACON_IDS.get(currentIndex);
        int minor = 101 + currentIndex;
        BeaconSignalEvent event = new BeaconSignalEvent(
                nextBeaconId,
                MockDataSource.BEACON_UUID,
                MockDataSource.BEACON_MAJOR,
                minor,
                -62,
                BeaconSignalEvent.EventType.SWITCH,
                System.currentTimeMillis());
        bridgeListener.onBeaconTriggered(event);
        return event;
    }

    /** (4) Kich ban 4: Gia lap tat Bluetooth hoac tu choi quyen BLE. */
    public BleErrorCode triggerScenario4BluetoothOffOrPermissionDenied() {
        BleErrorCode code = toggleErrorType ? BleErrorCode.PERMISSION_DENIED : BleErrorCode.BLUETOOTH_OFF;
        toggleErrorType = !toggleErrorType;
        bridgeListener.onBleError(code, null);
        return code;
    }
}
