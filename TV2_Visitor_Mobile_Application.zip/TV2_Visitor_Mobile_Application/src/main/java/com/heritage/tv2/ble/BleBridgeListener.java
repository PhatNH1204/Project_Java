package com.heritage.tv2.ble;

import com.heritage.tv2.model.BeaconSignalEvent;

/**
 * Cong giao tiep (Bridge Contract) ban giao cho phan he TV3 goi vao TV2.
 *
 * <p><b>RANG BUOC KIEN TRUC:</b> TV2 TUYET DOI KHONG viet lai thuat toan quet BLE,
 * loc nhiễu RSSI (Kalman/Moving Average) hay quy tac chong lap (cooldown/hysteresis) cua TV3.
 * Toan bo xu ly tin hieu thô nam ben module TV3; TV3 chi goi 3 callback duoi day sang TV2
 * sau khi da xac dinh ket qua.</p>
 */
public interface BleBridgeListener {

    /**
     * TV3 goi khi da xac dinh beacon gan nhat va vuot qua quy tac chong lap.
     *
     * @param event su kien tin hieu beacon (ENTER hoac SWITCH)
     */
    void onBeaconTriggered(BeaconSignalEvent event);

    /**
     * TV3 goi khi mat tin hieu beacon (khach tham quan da roi khoi vung phu song).
     *
     * @param beaconId ma dinh danh beacon vua mat song (vd: {@code "B-101"})
     */
    void onBeaconOutOfRange(String beaconId);

    /**
     * TV3 bao khi thiet bi tat Bluetooth, thieu quyen hoac phan cung khong ho tro.
     *
     * @param code    ma loi BLE chuan
     * @param message thong diep mo ta chi tiet (co the null)
     */
    void onBleError(BleErrorCode code, String message);
}
