package com.heritage.tv2.ble;

import com.heritage.tv2.model.BeaconSignalEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Gia lap quet beacon: lan luot "di qua" danh sach beacon theo chu ky, phat
 * ENTER (beacon dau) -> SWITCH (doi beacon) -> ... -> EXIT. Phuc vu demo/test khi chua co phan cung.
 * (Khung cho Tuan 3+; Gate 2 chua noi vao UI.)
 */
public class SimulatedBeaconScanner implements BeaconScanner {

    private final String uuid;
    private final List<Map.Entry<String, int[]>> beacons;
    private final long intervalMs;
    private ScheduledExecutorService scheduler;
    private ScheduledFuture<?> task;
    private int index = -1;

    /**
     * @param beacons beaconId -> {major, minor}
     */
    public SimulatedBeaconScanner(String uuid, Map<String, int[]> beacons, long intervalMs) {
        this.uuid = uuid;
        this.beacons = new ArrayList<>(beacons.entrySet());
        this.intervalMs = intervalMs;
    }

    @Override
    public synchronized void start(Listener listener) {
        if (isScanning() || beacons.isEmpty()) {
            return;
        }
        index = -1;
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "tv2-ble-sim");
            t.setDaemon(true);
            return t;
        });
        task = scheduler.scheduleAtFixedRate(() -> listener.onBeaconEvent(next()), 0, intervalMs, TimeUnit.MILLISECONDS);
    }

    /** Sinh su kien ke tiep (public de unit test khong can thread). */
    public synchronized BeaconSignalEvent next() {
        BeaconSignalEvent.EventType type;
        if (index < 0) {
            type = BeaconSignalEvent.EventType.ENTER;
            index = 0;
        } else if (index >= beacons.size() - 1) {
            type = BeaconSignalEvent.EventType.EXIT;
            index = -1;
            Map.Entry<String, int[]> last = beacons.get(beacons.size() - 1);
            return event(last, -95, type);
        } else {
            type = BeaconSignalEvent.EventType.SWITCH;
            index++;
        }
        return event(beacons.get(index), -60 - index * 3, type);
    }

    private BeaconSignalEvent event(Map.Entry<String, int[]> beacon, int rssi, BeaconSignalEvent.EventType type) {
        return new BeaconSignalEvent(beacon.getKey(), uuid, beacon.getValue()[0], beacon.getValue()[1],
                rssi, type, System.currentTimeMillis());
    }

    @Override
    public synchronized void stop() {
        if (task != null) {
            task.cancel(true);
            task = null;
        }
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
    }

    @Override
    public synchronized boolean isScanning() {
        return task != null && !task.isCancelled();
    }
}
