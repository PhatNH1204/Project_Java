package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.request.LoginRequest;
import com.heritage.tv2.model.request.RefreshTokenRequest;
import com.heritage.tv2.model.request.RegisterRequest;
import com.heritage.tv2.util.Result;

import java.util.Locale;

/**
 * Nghiep vu xac thuc: dang nhap, dang ky, dang xuat, khoi phuc phien.
 * Cac ham deu DONG BO (blocking) - ViewModel goi tren executor IO.
 */
public class AuthRepository {

    private final HeritageApiService api;
    private final SessionStorage session;

    public AuthRepository(HeritageApiService api, SessionStorage session) {
        this.api = api;
        this.session = session;
    }

    public Result<User> login(String email, String password) {
        Result<AuthTokens> tokens = ApiCaller.execute(
                api.login(new LoginRequest(email.trim().toLowerCase(Locale.ROOT), password)));
        return completeAuthentication(tokens);
    }

    public Result<User> register(String email, String password, String fullName) {
        RegisterRequest request = new RegisterRequest(email.trim().toLowerCase(Locale.ROOT), password,
                fullName.trim(), session.getLanguage());
        return completeAuthentication(ApiCaller.execute(api.register(request)));
    }

    /**
     * Sau khi co token: luu token -> lay ho so {@code /api/users/me} -> ap dung ngon ngu uu tien
     * cua tai khoan (server la nguon su that khi dang nhap moi).
     */
    private Result<User> completeAuthentication(Result<AuthTokens> tokens) {
        if (!tokens.isSuccess()) {
            return tokens.castError();
        }
        if (tokens.getData() == null || !tokens.getData().hasAccessToken()) {
            return Result.error(Result.CODE_PARSE, null, 200);
        }
        session.saveTokens(tokens.getData());
        Result<User> me = ApiCaller.execute(api.getMe());
        if (!me.isSuccess()) {
            session.clearSession();
            return me;
        }
        User user = me.getData();
        session.saveUser(user);
        if (user != null && AppConfig.isSupportedLanguage(user.getPreferredLanguage())) {
            session.setLanguage(user.getPreferredLanguage());
        }
        return me;
    }

    /**
     * Khoi phuc phien khi mo app (Splash).
     * <ul>
     *     <li>Khong co token -> loi {@code UNAUTHORIZED}.</li>
     *     <li>Mat mang -> dung user da cache (che do offline).</li>
     *     <li>401 khong refresh duoc -> AuthInterceptor da xoa phien -> loi.</li>
     * </ul>
     * Ngon ngu cuc bo duoc giu nguyen (nguoi dung co the da doi khi offline).
     */
    public Result<User> restoreSession() {
        if (!session.isLoggedIn()) {
            return Result.error(Result.CODE_UNAUTHORIZED, null, 401);
        }
        Result<User> me = ApiCaller.execute(api.getMe());
        if (me.isSuccess()) {
            session.saveUser(me.getData());
            return me;
        }
        if (me.isNetworkError()) {
            User cached = session.getUser();
            if (cached != null) {
                return Result.success(cached);
            }
        }
        return me;
    }

    /** Dang xuat: thu hoi refresh token tren server (best-effort) roi xoa phien cuc bo. */
    public Result<Void> logout() {
        String refreshToken = session.getRefreshToken();
        if (session.getAccessToken() != null) {
            ApiCaller.execute(api.logout(new RefreshTokenRequest(refreshToken)));
        }
        session.clearSession();
        return Result.success(null);
    }

    public boolean hasSession() {
        return session.isLoggedIn();
    }

    public User getCachedUser() {
        return session.getUser();
    }
}
