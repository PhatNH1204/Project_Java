package com.heritage.tv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Vo boc response chuan cua backend (TV1 - Tich hop Tuan 5-6).
 *
 * <p>Ho tro day du cac bien the ten truong JSON (camelCase &amp; snake_case) tu Swagger/OpenAPI that
 * cua nhom qua {@link SerializedName#alternate()}.</p>
 *
 * @param <T> kieu du lieu cua truong {@code data}
 */
public class ApiResponse<T> {

    @SerializedName(value = "success", alternate = {"ok", "is_success"})
    private boolean success;

    @SerializedName(value = "message", alternate = {"msg", "detail"})
    private String message;

    @SerializedName(value = "data", alternate = {"result", "payload"})
    private T data;

    @SerializedName(value = "error", alternate = {"err", "api_error", "apiError"})
    private ApiError error;

    @SerializedName(value = "timestamp", alternate = {"time", "server_time", "created_at"})
    private String timestamp;

    public ApiResponse() {
    }

    public static <T> ApiResponse<T> ok(T data) {
        return ok(data, "OK");
    }

    public static <T> ApiResponse<T> ok(T data, String message) {
        ApiResponse<T> r = new ApiResponse<>();
        r.success = true;
        r.data = data;
        r.message = message;
        r.timestamp = java.time.Instant.now().toString();
        return r;
    }

    public static <T> ApiResponse<T> fail(int status, String code, String message, String path) {
        ApiResponse<T> r = new ApiResponse<>();
        r.success = false;
        r.message = message;
        r.error = new ApiError(status, code, message, path);
        r.timestamp = java.time.Instant.now().toString();
        return r;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public ApiError getError() {
        return error;
    }

    public void setError(ApiError error) {
        this.error = error;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /** Chi tiet loi chuan cua backend. */
    public static class ApiError {
        @SerializedName(value = "status", alternate = {"statusCode", "status_code", "httpStatus"})
        private int status;

        @SerializedName(value = "code", alternate = {"errorCode", "error_code"})
        private String code;

        @SerializedName(value = "message", alternate = {"errorMessage", "error_message", "detail"})
        private String message;

        @SerializedName(value = "path", alternate = {"uri", "endpoint"})
        private String path;

        @SerializedName(value = "details", alternate = {"errors", "fieldErrors", "field_errors"})
        private List<FieldError> details;

        public ApiError() {
        }

        public ApiError(int status, String code, String message, String path) {
            this.status = status;
            this.code = code;
            this.message = message;
            this.path = path;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public List<FieldError> getDetails() {
            return details;
        }

        public void setDetails(List<FieldError> details) {
            this.details = details;
        }
    }

    /** Loi validate theo tung truong (Bean Validation). */
    public static class FieldError {
        @SerializedName(value = "field", alternate = {"fieldName", "field_name", "property"})
        private String field;

        @SerializedName(value = "message", alternate = {"defaultMessage", "error_message"})
        private String message;

        public FieldError() {
        }

        public FieldError(String field, String message) {
            this.field = field;
            this.message = message;
        }

        public String getField() {
            return field;
        }

        public String getMessage() {
            return message;
        }
    }
}
