package com.heritage.tv2.cache;

import com.google.gson.JsonParseException;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.util.JsonProvider;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Local Cache ben vung luu ban sao {@link Artifact} + {@code Content} ({@link ContentTranslation} + {@code Media})
 * (tuong duong Room DB tren Android).
 *
 * <p>Ngay khi {@code GET /api/artifacts/{id}} hoac {@code GET /api/beacons/{id}/content} tai thanh cong,
 * repository luu ban sao JSON vao {@link ArtifactCache} de san sang xem tiep van ban thuyet minh &amp; media
 * khi mat mang hoac mat song BLE beacon.</p>
 */
public class ArtifactCache {

    private static final String KEY_PREFIX = "artifact.";
    private static final String BEACON_KEY_PREFIX = "beacon.map.";

    private final KeyValueStore store;
    private final Map<Long, String> memoryMirror = new ConcurrentHashMap<>();
    private final Map<String, Long> beaconToArtifactId = new ConcurrentHashMap<>();

    public ArtifactCache(KeyValueStore store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
    }

    /** Luu ban sao day du cua Artifact (kem Content, ContentTranslation, Media). */
    public synchronized void save(Artifact artifact) {
        if (artifact == null || artifact.getId() == null) {
            return;
        }
        String json = JsonProvider.gson().toJson(artifact);
        long id = artifact.getId();
        memoryMirror.put(id, json);
        store.put(key(id), json);
    }

    /** Doc ban sao Artifact tu cache; tra ve {@code null} neu chua co. */
    public synchronized Artifact get(long artifactId) {
        String json = memoryMirror.get(artifactId);
        if (json == null) {
            json = store.get(key(artifactId));
            if (json != null && !json.isBlank()) {
                memoryMirror.put(artifactId, json);
            }
        }
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            return JsonProvider.gson().fromJson(json, Artifact.class);
        } catch (JsonParseException e) {
            return null;
        }
    }

    /**
     * Doc ban sao Artifact va dong bo tieu de theo {@code languageCode}
     * (fallback sang {@code fallbackLanguageCode} neu thieu ban dich).
     */
    public synchronized Artifact getLocalized(long artifactId, String languageCode, String fallbackLanguageCode) {
        Artifact artifact = get(artifactId);
        if (artifact == null) {
            return null;
        }
        if (artifact.getContent() != null) {
            String fb = fallbackLanguageCode != null ? fallbackLanguageCode : AppConfig.DEFAULT_LANGUAGE;
            ContentTranslation tr = artifact.getContent().findTranslation(languageCode, fb);
            if (tr != null && tr.getTitle() != null && !tr.getTitle().isBlank()) {
                artifact.setName(tr.getTitle());
            }
        }
        return artifact;
    }

    /** Luu anh xa beaconId -> artifactId va ban sao Artifact vao cache. */
    public synchronized void saveBeaconMapping(String beaconId, Artifact artifact) {
        if (artifact == null || artifact.getId() == null) {
            return;
        }
        save(artifact);
        if (beaconId != null && !beaconId.isBlank()) {
            String norm = beaconId.trim().toUpperCase();
            beaconToArtifactId.put(norm, artifact.getId());
            store.put(BEACON_KEY_PREFIX + norm, String.valueOf(artifact.getId()));
        }
    }

    /** Doc Artifact tu cache theo ma beaconId (dung khi roi vung phu song / mat mang). */
    public synchronized Artifact getByBeaconLocalized(String beaconId, String languageCode, String fallbackLanguageCode) {
        if (beaconId == null || beaconId.isBlank()) {
            return null;
        }
        String norm = beaconId.trim().toUpperCase();
        Long artifactId = beaconToArtifactId.get(norm);
        if (artifactId == null) {
            String storedId = store.get(BEACON_KEY_PREFIX + norm);
            if (storedId != null) {
                try {
                    artifactId = Long.parseLong(storedId.trim());
                    beaconToArtifactId.put(norm, artifactId);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return artifactId == null ? null : getLocalized(artifactId, languageCode, fallbackLanguageCode);
    }

    public synchronized boolean contains(long artifactId) {
        return get(artifactId) != null;
    }

    public synchronized void remove(long artifactId) {
        memoryMirror.remove(artifactId);
        store.remove(key(artifactId));
    }

    public synchronized void clear() {
        for (Long id : memoryMirror.keySet()) {
            store.remove(key(id));
        }
        memoryMirror.clear();
    }

    public int cachedCountInMemory() {
        return memoryMirror.size();
    }

    private static String key(long artifactId) {
        return KEY_PREFIX + artifactId;
    }
}
