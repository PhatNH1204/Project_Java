package com.heritage.tv2.api;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.util.JsonProvider;

import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Lap rap tang mang: {@link OkHttpClient} + {@link AuthInterceptor} + Retrofit.
 *
 * <pre>
 *  Request -> AuthInterceptor (Bearer + Accept-Language, refresh 401)
 *          -> [HttpLoggingInterceptor]
 *          -> [MockBackendInterceptor neu USE_MOCK_DATA] -> Network
 * </pre>
 *
 * Request refresh token di qua mot client rieng KHONG co AuthInterceptor.
 */
public final class ApiClient {

    private final OkHttpClient httpClient;
    private final HeritageApiService service;

    /**
     * @param baseUrl          base URL (ket thuc bang "/")
     * @param sessionStorage   noi doc/ghi token + ngon ngu
     * @param expiredListener  callback dieu huong ve Login khi het phien
     * @param backendOverride  interceptor tra loi thay backend (mock) - {@code null} de goi mang that
     */
    public ApiClient(String baseUrl,
                     SessionStorage sessionStorage,
                     AuthInterceptor.SessionExpiredListener expiredListener,
                     Interceptor backendOverride) {
        OkHttpClient base = new OkHttpClient.Builder()
                .connectTimeout(AppConfig.CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(AppConfig.READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(AppConfig.WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .build();

        // Client "tran" cho refresh token (khong AuthInterceptor).
        OkHttpClient.Builder plainBuilder = base.newBuilder();
        if (backendOverride != null) {
            plainBuilder.addInterceptor(backendOverride);
        }
        HeritageApiService refreshApi = retrofit(baseUrl, plainBuilder.build()).create(HeritageApiService.class);

        // Client chinh.
        OkHttpClient.Builder builder = base.newBuilder()
                .addInterceptor(new AuthInterceptor(sessionStorage,
                        new RetrofitTokenRefresher(refreshApi), expiredListener));
        if (AppConfig.HTTP_LOGGING) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
            logging.redactHeader(AuthInterceptor.HEADER_AUTHORIZATION);
            builder.addInterceptor(logging);
        }
        if (backendOverride != null) {
            builder.addInterceptor(backendOverride);
        }
        this.httpClient = builder.build();
        this.service = retrofit(baseUrl, httpClient).create(HeritageApiService.class);
    }

    /** Tao client theo {@link AppConfig}: mock backend neu {@code USE_MOCK_DATA = true}. */
    public static ApiClient fromConfig(SessionStorage sessionStorage,
                                       AuthInterceptor.SessionExpiredListener expiredListener,
                                       MockBackendInterceptor mockBackend) {
        return new ApiClient(AppConfig.effectiveBaseUrl(), sessionStorage, expiredListener,
                AppConfig.USE_MOCK_DATA ? mockBackend : null);
    }

    private static Retrofit retrofit(String baseUrl, OkHttpClient client) {
        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(JsonProvider.gson()))
                .build();
    }

    public HeritageApiService service() {
        return service;
    }

    public OkHttpClient httpClient() {
        return httpClient;
    }
}
