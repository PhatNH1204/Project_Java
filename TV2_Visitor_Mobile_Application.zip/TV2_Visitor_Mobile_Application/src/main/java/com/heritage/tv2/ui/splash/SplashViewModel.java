package com.heritage.tv2.ui.splash;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.User;
import com.heritage.tv2.repository.AuthRepository;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.Event;
import com.heritage.tv2.ui.base.LiveData;
import com.heritage.tv2.ui.base.ViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.Result;

/**
 * ViewModel man hinh Splash: kiem tra phien dang nhap va dieu huong sang {@code MAIN} hoac {@code LOGIN}.
 */
public class SplashViewModel extends ViewModel {

    private final AuthRepository authRepository;
    private final LiveData<Event<Navigator.Route>> nextRoute = new LiveData<>();

    public SplashViewModel(AuthRepository authRepository, AppExecutors executors) {
        super(executors);
        this.authRepository = authRepository;
    }

    public LiveData<Event<Navigator.Route>> nextRoute() {
        return nextRoute;
    }

    public void checkSession() {
        launch(() -> {
            if (AppConfig.SPLASH_DURATION_MS > 0) {
                try {
                    Thread.sleep(Math.min(AppConfig.SPLASH_DURATION_MS, 500L));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            return authRepository.restoreSession();
        }, (Result<User> res) -> {
            Navigator.Route target = res.isSuccess() ? Navigator.Route.MAIN : Navigator.Route.LOGIN;
            nextRoute.setValue(new Event<>(target));
        });
    }
}
