package com.heritage.tv2.ui.auth;

import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.User;
import com.heritage.tv2.repository.AuthRepository;
import com.heritage.tv2.repository.LanguageRepository;
import com.heritage.tv2.ui.base.Event;
import com.heritage.tv2.ui.base.LiveData;
import com.heritage.tv2.ui.base.ViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Validators;

import java.util.List;

/**
 * ViewModel man hinh Dang nhap ({@code POST /api/auth/login} -> {@code GET /api/users/me}).
 */
public class LoginViewModel extends ViewModel {

    private final AuthRepository authRepository;
    private final LanguageRepository languageRepository;

    private final LiveData<Boolean> loading = new LiveData<>(false);
    private final LiveData<Event<String>> errorEvent = new LiveData<>();
    private final LiveData<Event<User>> loginSuccess = new LiveData<>();

    public LoginViewModel(AuthRepository authRepository,
                          LanguageRepository languageRepository,
                          AppExecutors executors) {
        super(executors);
        this.authRepository = authRepository;
        this.languageRepository = languageRepository;
    }

    public LiveData<Boolean> loading() {
        return loading;
    }

    public LiveData<Event<String>> errorEvent() {
        return errorEvent;
    }

    public LiveData<Event<User>> loginSuccess() {
        return loginSuccess;
    }

    public List<Language> supportedLanguages() {
        return languageRepository.getSupportedLanguages();
    }

    public String currentLanguage() {
        return languageRepository.getCurrentLanguage();
    }

    public void switchLanguage(String code) {
        languageRepository.changeLanguage(code);
    }

    public void login(String email, String password) {
        if (!Validators.isValidEmail(email)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.invalid_email")));
            return;
        }
        if (!Validators.isValidPassword(password)) {
            errorEvent.setValue(new Event<>(I18n.tr("error.invalid_password")));
            return;
        }
        loading.setValue(true);
        launch(() -> authRepository.login(email, password), result -> {
            loading.setValue(false);
            if (result.isSuccess()) {
                loginSuccess.setValue(new Event<>(result.getData()));
            } else {
                errorEvent.setValue(new Event<>(I18n.errorMessage(result)));
            }
        });
    }
}
