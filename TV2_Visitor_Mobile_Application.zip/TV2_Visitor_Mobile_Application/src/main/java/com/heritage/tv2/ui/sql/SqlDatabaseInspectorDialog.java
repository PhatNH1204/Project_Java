package com.heritage.tv2.ui.sql;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.theme.UiTheme;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/**
 * Cua so SQL Database &amp; Table Inspector truc quan cho phan he TV2 (HeritageTV2DB).
 *
 * <p>Hien thi toan bo 13 bang CSDL tuong ung voi bo Entity/Model cua du an:</p>
 * <ol>
 *     <li>{@code roles} (TV1 - {@code Role})</li>
 *     <li>{@code languages} (TV1 - {@code Language})</li>
 *     <li>{@code users} (TV1 - {@code User})</li>
 *     <li>{@code auth_tokens} (TV1 - {@code AuthTokens})</li>
 *     <li>{@code heritage_sites} (TV4 - {@code HeritageSite})</li>
 *     <li>{@code artifacts} (TV4 - {@code Artifact})</li>
 *     <li>{@code contents} (TV4 - {@code Content})</li>
 *     <li>{@code content_translations} (TV4 - {@code ContentTranslation})</li>
 *     <li>{@code media} (TV4 - {@code Media})</li>
 *     <li>{@code favorites} (TV2/TV5 - {@code Favorite})</li>
 *     <li>{@code visit_history} (TV2/TV5 - {@code VisitHistory})</li>
 *     <li>{@code feedbacks} (TV2/TV5 - {@code Feedback} / {@code FeedbackRequest})</li>
 *     <li>{@code beacon_signal_events} (TV3 - {@code BeaconSignalEvent})</li>
 * </ol>
 */
public final class SqlDatabaseInspectorDialog extends JDialog {

    /** Mo ta 1 bang SQL gom ten bang, nhom phan cong, cau lenh DDL va cac dong du lieu. */
    public static final class SqlTableSnapshot {
        private final String tableName;
        private final String entityName;
        private final String ownerModule;
        private final String ddlSql;
        private final String[] columns;
        private final List<Object[]> rows;

        public SqlTableSnapshot(String tableName,
                                String entityName,
                                String ownerModule,
                                String ddlSql,
                                String[] columns,
                                List<Object[]> rows) {
            this.tableName = tableName;
            this.entityName = entityName;
            this.ownerModule = ownerModule;
            this.ddlSql = ddlSql;
            this.columns = columns;
            this.rows = rows;
        }

        public String getTableName() {
            return tableName;
        }

        public String getEntityName() {
            return entityName;
        }

        public String getOwnerModule() {
            return ownerModule;
        }

        public String getDdlSql() {
            return ddlSql;
        }

        public String[] getColumns() {
            return columns;
        }

        public List<Object[]> getRows() {
            return rows;
        }

        @Override
        public String toString() {
            return tableName + " (" + rows.size() + " rows) — [" + entityName + "]";
        }
    }

    private final AppContainer container;
    private final Map<String, SqlTableSnapshot> tableMap = new LinkedHashMap<>();
    private final DefaultListModel<SqlTableSnapshot> listModel = new DefaultListModel<>();
    private final JList<SqlTableSnapshot> tableList = new JList<>(listModel);
    private final JTextField sqlQueryField = new JTextField("SELECT * FROM heritage_sites;");
    private final DefaultTableModel dataTableModel = new DefaultTableModel();
    private final JTable dataTable = new JTable(dataTableModel);
    private final JTextArea ddlTextArea = new JTextArea();
    private final JLabel statusLabel = new JLabel();

    public SqlDatabaseInspectorDialog(Frame owner, AppContainer container) {
        super(owner, "🗄 HeritageTV2DB — SQL Table Inspector (13 Tables)", false);
        this.container = container;
        setSize(new Dimension(920, 620));
        setLocationRelativeTo(owner);
        buildUi();
        reloadSnapshots();
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBackground(UiTheme.BG_APP);
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Top SQL Query Console bar
        JPanel queryBar = new JPanel(new BorderLayout(6, 0));
        queryBar.setBackground(UiTheme.BG_CARD);
        queryBar.setBorder(UiTheme.cardBorder());

        JLabel sqlLbl = new JLabel("SQL > ");
        sqlLbl.setFont(new Font(Font.MONOSPACED, Font.BOLD, 13));
        sqlLbl.setForeground(UiTheme.PRIMARY_DARK);

        sqlQueryField.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        sqlQueryField.addActionListener(e -> executeSqlQuery(sqlQueryField.getText()));

        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btnGroup.setOpaque(false);

        JButton runBtn = UiTheme.primaryButton("▶ Run SQL");
        runBtn.addActionListener(e -> executeSqlQuery(sqlQueryField.getText()));

        JButton showTablesBtn = UiTheme.secondaryButton("SHOW TABLES");
        showTablesBtn.addActionListener(e -> {
            sqlQueryField.setText("SHOW TABLES;");
            executeSqlQuery("SHOW TABLES;");
        });

        JButton refreshBtn = UiTheme.secondaryButton("↻ Làm mới DB");
        refreshBtn.addActionListener(e -> reloadSnapshots());

        btnGroup.add(runBtn);
        btnGroup.add(showTablesBtn);
        btnGroup.add(refreshBtn);

        queryBar.add(sqlLbl, BorderLayout.WEST);
        queryBar.add(sqlQueryField, BorderLayout.CENTER);
        queryBar.add(btnGroup, BorderLayout.EAST);

        // Left Sidebar: List of 13 SQL tables
        tableList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableList.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        tableList.setBackground(Color.WHITE);
        tableList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                SqlTableSnapshot selected = tableList.getSelectedValue();
                if (selected != null) {
                    sqlQueryField.setText("SELECT * FROM " + selected.getTableName() + ";");
                    displaySnapshot(selected);
                }
            }
        });
        JScrollPane leftScroll = new JScrollPane(tableList);
        leftScroll.setPreferredSize(new Dimension(280, 480));
        leftScroll.setBorder(BorderFactory.createTitledBorder("Danh sách Bảng (HeritageTV2DB)"));

        // Center: Tabs for Data Grid (JTable) and CREATE TABLE DDL
        dataTable.setFont(UiTheme.FONT_BODY);
        dataTable.setRowHeight(24);
        dataTable.getTableHeader().setFont(UiTheme.FONT_BODY_BOLD);
        dataTable.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);

        ddlTextArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        ddlTextArea.setEditable(false);
        ddlTextArea.setBackground(new Color(30, 30, 34));
        ddlTextArea.setForeground(new Color(230, 235, 240));
        ddlTextArea.setBorder(new EmptyBorder(10, 10, 10, 10));

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(UiTheme.FONT_BODY_BOLD);
        tabs.addTab("📊 Dữ liệu Bảng (Table Rows)", new JScrollPane(dataTable));
        tabs.addTab("📜 Cấu trúc SQL (CREATE TABLE DDL)", new JScrollPane(ddlTextArea));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScroll, tabs);
        split.setDividerLocation(285);

        // Bottom Status bar
        statusLabel.setFont(UiTheme.FONT_SMALL);
        statusLabel.setForeground(UiTheme.TEXT_SECONDARY);
        statusLabel.setBorder(new EmptyBorder(4, 4, 0, 4));

        root.add(queryBar, BorderLayout.NORTH);
        root.add(split, BorderLayout.CENTER);
        root.add(statusLabel, BorderLayout.SOUTH);
        setContentPane(root);
    }

    public void reloadSnapshots() {
        tableMap.clear();
        listModel.clear();
        for (SqlTableSnapshot snap : buildAllTableSnapshots(container)) {
            tableMap.put(snap.getTableName().toLowerCase(Locale.ROOT), snap);
            listModel.addElement(snap);
        }
        if (!listModel.isEmpty()) {
            tableList.setSelectedIndex(0);
        }
    }

    public void executeSqlQuery(String rawSql) {
        if (rawSql == null || rawSql.isBlank()) {
            return;
        }
        String norm = rawSql.trim().replace(";", "").trim().toLowerCase(Locale.ROOT);
        if (norm.equals("show tables") || norm.contains("information_schema.tables") || norm.contains("sys.tables")) {
            String[] cols = {"STT", "TABLE_NAME", "ENTITY_CLASS", "MODULE", "ROW_COUNT"};
            List<Object[]> rows = new ArrayList<>();
            int idx = 1;
            for (SqlTableSnapshot s : tableMap.values()) {
                rows.add(new Object[]{idx++, s.getTableName(), s.getEntityName(), s.getOwnerModule(), s.getRows().size()});
            }
            setTableData(cols, rows);
            statusLabel.setText("✔ SHOW TABLES: Hiển thị " + rows.size() + " bảng trong CSDL HeritageTV2DB.");
            return;
        }

        for (SqlTableSnapshot s : tableMap.values()) {
            if (norm.contains("from " + s.getTableName().toLowerCase(Locale.ROOT))
                    || norm.contains("from dbo." + s.getTableName().toLowerCase(Locale.ROOT))
                    || norm.equals(s.getTableName().toLowerCase(Locale.ROOT))) {
                displaySnapshot(s);
                return;
            }
        }
        statusLabel.setText("ℹ Không tìm thấy bảng khớp câu lệnh: " + rawSql + " (Gợi ý: bấm SHOW TABLES hoặc chọn bảng bên trái)");
    }

    private void displaySnapshot(SqlTableSnapshot snap) {
        setTableData(snap.getColumns(), snap.getRows());
        ddlTextArea.setText(snap.getDdlSql());
        ddlTextArea.setCaretPosition(0);
        statusLabel.setText("✔ Bảng: dbo." + snap.getTableName()
                + " | Entity: " + snap.getEntityName()
                + " (" + snap.getOwnerModule() + ")"
                + " | Số bản ghi: " + snap.getRows().size()
                + " | File SQL: sql/heritage_tv2_sqlserver.sql");
    }

    private void setTableData(String[] columns, List<Object[]> rows) {
        dataTableModel.setRowCount(0);
        dataTableModel.setColumnIdentifiers(columns);
        for (Object[] r : rows) {
            dataTableModel.addRow(r);
        }
    }

    /**
     * Trich xuat toan bo 13 bang SQL va du lieu thuc te tu container hien tai.
     */
    public static List<SqlTableSnapshot> buildAllTableSnapshots(AppContainer container) {
        if (!container.sessionStorage().isLoggedIn()) {
            container.authRepository().login("visitor@heritage.vn", "123456");
        }
        String lang = container.sessionStorage().getLanguage();
        List<HeritageSite> sites = container.heritageRepository().getSites(true).getData();
        if (sites == null) {
            sites = List.of();
        }
        List<Artifact> fullArtifacts = new ArrayList<>();
        for (long aid : new long[]{101L, 102L, 103L, 104L, 105L, 106L}) {
            var res = container.heritageRepository().getArtifact(aid);
            if (res.isSuccess() && res.getData() != null) {
                fullArtifacts.add(res.getData());
            }
        }
        List<Favorite> favs = container.favoriteRepository().getFavorites().getData();
        if (favs == null) {
            favs = List.of();
        }
        List<VisitHistory> history = container.visitHistoryRepository().getVisitHistory().getData();
        if (history == null) {
            history = List.of();
        }
        User me = container.userRepository().getProfile().getData();

        List<SqlTableSnapshot> list = new ArrayList<>();

        // 1. roles
        list.add(new SqlTableSnapshot(
                "roles", "Role", "TV1",
                "CREATE TABLE dbo.roles (\n    id BIGINT PRIMARY KEY,\n    name NVARCHAR(50) NOT NULL UNIQUE,\n    description NVARCHAR(255)\n);",
                new String[]{"id", "name", "description"},
                List.of(
                        new Object[]{1L, "ADMIN", "Quản trị hệ thống"},
                        new Object[]{2L, "STAFF", "Nhân viên bảo tàng"},
                        new Object[]{3L, "VISITOR", "Khách tham quan"}
                )));

        // 2. languages
        List<Object[]> langRows = new ArrayList<>();
        for (Language l : container.languageRepository().getSupportedLanguages()) {
            langRows.add(new Object[]{l.getId(), l.getCode(), l.getName(), l.isActive(), l.isDefault()});
        }
        list.add(new SqlTableSnapshot(
                "languages", "Language", "TV1",
                "CREATE TABLE dbo.languages (\n    id BIGINT PRIMARY KEY,\n    code NVARCHAR(10) NOT NULL UNIQUE,\n    name NVARCHAR(100) NOT NULL,\n    active BIT NOT NULL DEFAULT 1,\n    is_default BIT NOT NULL DEFAULT 0\n);",
                new String[]{"id", "code", "name", "active", "is_default"},
                langRows));

        // 3. users
        List<Object[]> userRows = new ArrayList<>();
        if (me != null) {
            userRows.add(new Object[]{
                    me.getId(), me.getEmail(), me.getFullName(), me.getPhone(),
                    me.getRole() != null ? me.getRole().getName() : "VISITOR",
                    me.getPreferredLanguage(), me.getCreatedAt()
            });
        }
        userRows.add(new Object[]{2L, "tourist@heritage.vn", "John Smith", "+1-555-0199", "VISITOR", "en", "2026-11-01T08:00:00Z"});
        list.add(new SqlTableSnapshot(
                "users", "User", "TV1",
                "CREATE TABLE dbo.users (\n    id BIGINT PRIMARY KEY,\n    email NVARCHAR(150) NOT NULL UNIQUE,\n    full_name NVARCHAR(150) NOT NULL,\n    phone NVARCHAR(30),\n    role_id BIGINT NOT NULL REFERENCES dbo.roles(id),\n    preferred_language NVARCHAR(10) NOT NULL,\n    created_at NVARCHAR(40) NOT NULL\n);",
                new String[]{"id", "email", "full_name", "phone", "role", "preferred_language", "created_at"},
                userRows));

        // 4. auth_tokens
        String at = container.sessionStorage().getAccessToken();
        String rt = container.sessionStorage().getRefreshToken();
        list.add(new SqlTableSnapshot(
                "auth_tokens", "AuthTokens", "TV1",
                "CREATE TABLE dbo.auth_tokens (\n    id BIGINT IDENTITY(1,1) PRIMARY KEY,\n    user_id BIGINT NOT NULL REFERENCES dbo.users(id),\n    access_token NVARCHAR(500) NOT NULL,\n    refresh_token NVARCHAR(500) NOT NULL,\n    token_type NVARCHAR(20) NOT NULL DEFAULT 'Bearer',\n    expires_in BIGINT NOT NULL\n);",
                new String[]{"user_id", "token_type", "access_token", "refresh_token", "expires_in"},
                List.<Object[]>of(new Object[]{1L, "Bearer", at != null ? at : "(none)", rt != null ? rt : "(none)", AppConfig.MOCK_ACCESS_TOKEN_TTL_SECONDS})));

        // 5. heritage_sites
        List<Object[]> siteRows = new ArrayList<>();
        for (HeritageSite s : sites) {
            siteRows.add(new Object[]{
                    s.getId(), s.getCode(), s.getCategory(), s.getName(),
                    s.getRegion(), s.getLatitude(), s.getLongitude(), s.getOpeningHours(), s.getArtifactCount()
            });
        }
        list.add(new SqlTableSnapshot(
                "heritage_sites", "HeritageSite", "TV4",
                "CREATE TABLE dbo.heritage_sites (\n    id BIGINT PRIMARY KEY,\n    code NVARCHAR(30) NOT NULL UNIQUE,\n    category NVARCHAR(30) NOT NULL,\n    name NVARCHAR(200) NOT NULL,\n    region NVARCHAR(150) NOT NULL,\n    address NVARCHAR(300) NOT NULL,\n    latitude FLOAT NOT NULL,\n    longitude FLOAT NOT NULL,\n    opening_hours NVARCHAR(100),\n    artifact_count INT NOT NULL\n);",
                new String[]{"id", "code", "category", "name", "region", "latitude", "longitude", "opening_hours", "artifact_count"},
                siteRows));

        // 6. artifacts
        List<Object[]> artRows = new ArrayList<>();
        for (Artifact a : fullArtifacts) {
            artRows.add(new Object[]{
                    a.getId(), a.getSiteId(), a.getCode(), "B-" + a.getId(),
                    a.getName(), a.getPeriod(), a.getShortDescription()
            });
        }
        list.add(new SqlTableSnapshot(
                "artifacts", "Artifact", "TV4",
                "CREATE TABLE dbo.artifacts (\n    id BIGINT PRIMARY KEY,\n    site_id BIGINT NOT NULL REFERENCES dbo.heritage_sites(id),\n    code NVARCHAR(30) NOT NULL UNIQUE,\n    beacon_id NVARCHAR(30),\n    name NVARCHAR(200) NOT NULL,\n    period NVARCHAR(150) NOT NULL,\n    short_description NVARCHAR(500) NOT NULL\n);",
                new String[]{"id", "site_id", "code", "beacon_id", "name", "period", "short_description"},
                artRows));

        // 7. contents
        List<Object[]> contentRows = new ArrayList<>();
        for (Artifact a : fullArtifacts) {
            if (a.getContent() != null) {
                contentRows.add(new Object[]{
                        a.getContent().getId(), a.getId(),
                        a.getContent().getTranslations().size(),
                        a.getContent().getMedia().size()
                });
            }
        }
        list.add(new SqlTableSnapshot(
                "contents", "Content", "TV4",
                "CREATE TABLE dbo.contents (\n    id BIGINT PRIMARY KEY,\n    artifact_id BIGINT NOT NULL UNIQUE REFERENCES dbo.artifacts(id)\n);",
                new String[]{"id", "artifact_id", "translation_count", "media_count"},
                contentRows));

        // 8. content_translations
        List<Object[]> trRows = new ArrayList<>();
        for (Artifact a : fullArtifacts) {
            if (a.getContent() != null) {
                for (ContentTranslation t : a.getContent().getTranslations()) {
                    trRows.add(new Object[]{
                            t.getId(), a.getContent().getId(), t.getLanguageCode(),
                            t.getTitle(), t.getBodyText()
                    });
                }
            }
        }
        list.add(new SqlTableSnapshot(
                "content_translations", "ContentTranslation", "TV4",
                "CREATE TABLE dbo.content_translations (\n    id BIGINT PRIMARY KEY,\n    content_id BIGINT NOT NULL REFERENCES dbo.contents(id),\n    language_code NVARCHAR(10) NOT NULL,\n    title NVARCHAR(250) NOT NULL,\n    body_text NVARCHAR(MAX) NOT NULL\n);",
                new String[]{"id", "content_id", "language_code", "title", "body_text"},
                trRows));

        // 9. media
        List<Object[]> mediaRows = new ArrayList<>();
        for (Artifact a : fullArtifacts) {
            if (a.getContent() != null) {
                for (Media m : a.getContent().getMedia()) {
                    mediaRows.add(new Object[]{
                            m.getId(), a.getContent().getId(), m.getMediaType(),
                            m.getUrl(), m.getDuration(), m.getLanguageCode()
                    });
                }
            }
        }
        list.add(new SqlTableSnapshot(
                "media", "Media", "TV4",
                "CREATE TABLE dbo.media (\n    id BIGINT PRIMARY KEY,\n    content_id BIGINT NOT NULL REFERENCES dbo.contents(id),\n    media_type NVARCHAR(20) NOT NULL,\n    url NVARCHAR(500) NOT NULL,\n    duration INT NULL,\n    language_code NVARCHAR(10) NULL\n);",
                new String[]{"id", "content_id", "media_type", "url", "duration_sec", "language_code"},
                mediaRows));

        // 10. favorites
        List<Object[]> favRows = new ArrayList<>();
        for (Favorite f : favs) {
            favRows.add(new Object[]{
                    f.getId(), f.getUserId(), f.getArtifactId(),
                    f.getArtifact() != null ? f.getArtifact().getName() : "", f.getCreatedAt()
            });
        }
        list.add(new SqlTableSnapshot(
                "favorites", "Favorite", "TV2 / TV5",
                "CREATE TABLE dbo.favorites (\n    id BIGINT PRIMARY KEY,\n    user_id BIGINT NOT NULL REFERENCES dbo.users(id),\n    artifact_id BIGINT NOT NULL REFERENCES dbo.artifacts(id),\n    created_at NVARCHAR(40) NOT NULL\n);",
                new String[]{"id", "user_id", "artifact_id", "artifact_name", "created_at"},
                favRows));

        // 11. visit_history
        List<Object[]> vhRows = new ArrayList<>();
        for (VisitHistory v : history) {
            vhRows.add(new Object[]{
                    v.getId(), v.getUserId(), v.getSiteId(), v.getArtifactId(),
                    v.getArtifactName(), v.getSiteName(), v.getVisitedAt(),
                    v.getDurationSeconds(), v.getSource()
            });
        }
        list.add(new SqlTableSnapshot(
                "visit_history", "VisitHistory", "TV2 / TV5",
                "CREATE TABLE dbo.visit_history (\n    id BIGINT PRIMARY KEY,\n    user_id BIGINT NOT NULL,\n    site_id BIGINT NOT NULL,\n    artifact_id BIGINT NOT NULL,\n    artifact_name NVARCHAR(200) NOT NULL,\n    site_name NVARCHAR(200) NOT NULL,\n    visited_at NVARCHAR(40) NOT NULL,\n    duration_seconds INT NOT NULL,\n    source NVARCHAR(20) NOT NULL\n);",
                new String[]{"id", "user_id", "site_id", "artifact_id", "artifact_name", "site_name", "visited_at", "duration_seconds", "source"},
                vhRows));

        // 12. feedbacks
        List<Object[]> fbRows = new ArrayList<>();
        fbRows.add(new Object[]{1L, 1L, 101L, 5, "Thuyết minh âm thanh Trống đồng Ngọc Lũ rất rõ ràng và hấp dẫn!", "2026-11-18T11:20:00Z"});
        fbRows.add(new Object[]{2L, 1L, 102L, 5, "Đôi rồng đá điện Kính Thiên rất uy nghiêm.", "2026-11-19T09:15:00Z"});
        if (container.mockBackend() != null) {
            long seq = 3L;
            for (FeedbackRequest fb : container.mockBackend().getFeedbacks()) {
                fbRows.add(new Object[]{seq++, 1L, fb.getArtifactId(), fb.getRating(), fb.getComment(), "2026-11-27T16:40:00Z"});
            }
        }
        list.add(new SqlTableSnapshot(
                "feedbacks", "Feedback / FeedbackRequest", "TV2 / TV5",
                "CREATE TABLE dbo.feedbacks (\n    id BIGINT IDENTITY(1,1) PRIMARY KEY,\n    user_id BIGINT NOT NULL REFERENCES dbo.users(id),\n    artifact_id BIGINT NOT NULL REFERENCES dbo.artifacts(id),\n    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),\n    comment NVARCHAR(1000) NOT NULL,\n    created_at NVARCHAR(40) NOT NULL\n);",
                new String[]{"id", "user_id", "artifact_id", "rating", "comment", "created_at"},
                fbRows));

        // 13. beacon_signal_events
        list.add(new SqlTableSnapshot(
                "beacon_signal_events", "BeaconSignalEvent", "TV3",
                "CREATE TABLE dbo.beacon_signal_events (\n    id BIGINT IDENTITY(1,1) PRIMARY KEY,\n    beacon_id NVARCHAR(30) NOT NULL,\n    uuid NVARCHAR(64) NOT NULL,\n    major INT NOT NULL,\n    minor INT NOT NULL,\n    rssi INT NOT NULL,\n    event_type NVARCHAR(20) NOT NULL,\n    event_timestamp BIGINT NOT NULL\n);",
                new String[]{"id", "beacon_id", "uuid", "major", "minor", "rssi", "event_type", "event_timestamp"},
                List.of(
                        new Object[]{1L, "B-101", "FDA50693-A4E2-4FB1-AFCF-C6EB07647825", 1, 101, -58, "ENTER", 1763546400000L},
                        new Object[]{2L, "B-102", "FDA50693-A4E2-4FB1-AFCF-C6EB07647825", 1, 102, -62, "SWITCH", 1763546460000L},
                        new Object[]{3L, "B-102", "FDA50693-A4E2-4FB1-AFCF-C6EB07647825", 1, 102, -95, "EXIT", 1763546520000L}
                )));

        return list;
    }

    /** In danh sach 13 bang SQL va du lieu ra Console (cho lenh --show-sql-tables). */
    public static void printAllTablesToConsole(AppContainer container) {
        List<SqlTableSnapshot> snapshots = buildAllTableSnapshots(container);
        System.out.println("=====================================================================================");
        System.out.println("  HERITAGE TV2 DATABASE — DANH SACH 13 BANG SQL (SHOW TABLES FROM HeritageTV2DB)");
        System.out.println("=====================================================================================");
        System.out.printf("  %-4s | %-24s | %-26s | %-10s | %-8s%n",
                "STT", "TABLE_NAME", "ENTITY_CLASS", "MODULE", "ROWS");
        System.out.println("-------+--------------------------+----------------------------+------------+--------");
        int idx = 1;
        for (SqlTableSnapshot s : snapshots) {
            System.out.printf("  %-4d | %-24s | %-26s | %-10s | %-8d%n",
                    idx++, s.getTableName(), s.getEntityName(), s.getOwnerModule(), s.getRows().size());
        }
        System.out.println("=====================================================================================");

        for (SqlTableSnapshot s : snapshots) {
            System.out.println("\n>>> SELECT * FROM dbo." + s.getTableName()
                    + "  -- [" + s.getEntityName() + " | " + s.getRows().size() + " rows]");
            System.out.println("    Columns: " + String.join(" | ", s.getColumns()));
            int shown = 0;
            for (Object[] row : s.getRows()) {
                if (shown++ >= 6) {
                    System.out.println("    ... (" + (s.getRows().size() - 6) + " more rows)");
                    break;
                }
                List<String> cells = new ArrayList<>();
                for (Object cell : row) {
                    String str = cell == null ? "NULL" : String.valueOf(cell);
                    if (str.length() > 42) {
                        str = str.substring(0, 39) + "...";
                    }
                    cells.add(str);
                }
                System.out.println("    Row " + shown + ": " + String.join(" | ", cells));
            }
        }
        System.out.println("\n=== SQL SCRIPT FILE: sql/heritage_tv2_sqlserver.sql ===");
    }
}
