package com.heritage.tv2.api;

import com.google.gson.JsonParseException;
import com.heritage.tv2.model.ApiResponse;
import com.heritage.tv2.util.JsonProvider;
import com.heritage.tv2.util.Result;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Thuc thi dong bo mot {@link Call} va chuyen {@link ApiResponse} chuan cua backend
 * thanh {@link Result} thong qua {@link ErrorMapper}. Repository goi ham nay tren thread nen (IO).
 */
public final class ApiCaller {

    private ApiCaller() {
    }

    public static <T> Result<T> execute(Call<ApiResponse<T>> call) {
        try {
            Response<ApiResponse<T>> response = call.execute();
            if (response.isSuccessful()) {
                ApiResponse<T> body = response.body();
                if (body == null) {
                    return Result.success(null);
                }
                if (!body.isSuccess()) {
                    return ErrorMapper.mapHttpError(body, response.code());
                }
                return Result.success(body.getData());
            }
            return ErrorMapper.mapHttpError(parseErrorBody(response.errorBody()), response.code());
        } catch (IOException e) {
            return ErrorMapper.mapNetworkException(e);
        } catch (JsonParseException e) {
            return Result.error(Result.CODE_PARSE, e.getMessage(), 0);
        }
    }

    private static ApiResponse<?> parseErrorBody(ResponseBody errorBody) {
        if (errorBody == null) {
            return null;
        }
        try (errorBody) {
            String json = errorBody.string();
            if (json.isBlank()) {
                return null;
            }
            return JsonProvider.gson().fromJson(json, ApiResponse.class);
        } catch (IOException | JsonParseException e) {
            return null;
        }
    }
}
