package com.heritage.tv2.util;

import com.heritage.tv2.config.AppConfig;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Chuoi giao dien da ngon ngu (tuong duong {@code res/values-xx/strings.xml}).
 * Doc tu {@code /i18n/strings_vi.properties} va {@code /i18n/strings_en.properties} (UTF-8).
 */
public final class I18n {

    private static final String BUNDLE = "i18n.strings";
    private static volatile ResourceBundle bundle = load(AppConfig.DEFAULT_LANGUAGE);
    private static volatile String language = AppConfig.DEFAULT_LANGUAGE;

    private I18n() {
    }

    private static ResourceBundle load(String lang) {
        // Khong fallback theo Locale he dieu hanh: luon dung dung bundle cua lang.
        return ResourceBundle.getBundle(BUNDLE, Locale.forLanguageTag(lang),
                ResourceBundle.Control.getNoFallbackControl(ResourceBundle.Control.FORMAT_PROPERTIES));
    }

    public static synchronized void setLanguage(String lang) {
        String code = AppConfig.isSupportedLanguage(lang) ? lang.toLowerCase(Locale.ROOT) : AppConfig.DEFAULT_LANGUAGE;
        bundle = load(code);
        language = code;
    }

    public static String getLanguage() {
        return language;
    }

    /** Lay chuoi theo key; tra ve "!key!" neu thieu de de phat hien khi test UI. */
    public static String tr(String key) {
        try {
            return bundle.getString(key);
        } catch (MissingResourceException e) {
            return "!" + key + "!";
        }
    }

    public static String tr(String key, Object... args) {
        return new MessageFormat(tr(key), Locale.forLanguageTag(language)).format(args);
    }

    /**
     * Thong diep loi than thien cho {@link Result}: uu tien message backend da ban dia hoa,
     * loi mang / khong xac dinh dung chuoi cuc bo.
     */
    public static String errorMessage(Result<?> result) {
        if (result == null || result.isSuccess()) {
            return "";
        }
        if (result.isNetworkError()) {
            return tr("error.network");
        }
        if (result.getErrorMessage() != null && !result.getErrorMessage().isBlank()
                && !Result.CODE_PARSE.equals(result.getErrorCode())) {
            return result.getErrorMessage();
        }
        return tr("error.unknown");
    }
}
