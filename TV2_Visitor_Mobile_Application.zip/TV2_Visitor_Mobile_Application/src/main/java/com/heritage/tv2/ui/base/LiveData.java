package com.heritage.tv2.ui.base;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Observable toi gian kieu Android {@code LiveData}.
 *
 * <p>Quy uoc: ViewModel chi goi {@link #setValue(Object)} tren main executor (Swing EDT),
 * vi vay observer luon chay tren EDT va co the cap nhat component truc tiep.</p>
 */
public class LiveData<T> {

    private volatile T value;
    private final List<Consumer<T>> observers = new CopyOnWriteArrayList<>();

    public LiveData() {
    }

    public LiveData(T initial) {
        this.value = initial;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T newValue) {
        this.value = newValue;
        for (Consumer<T> o : observers) {
            o.accept(newValue);
        }
    }

    /**
     * Dang ky observer; nhan ngay gia tri hien tai (neu khac null).
     *
     * @return ham huy dang ky - Screen goi trong {@code onHide()}
     */
    public Runnable observe(Consumer<T> observer) {
        Objects.requireNonNull(observer);
        observers.add(observer);
        T current = value;
        if (current != null) {
            observer.accept(current);
        }
        return () -> observers.remove(observer);
    }

    public int observerCount() {
        return observers.size();
    }
}
