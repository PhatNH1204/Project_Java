package com.heritage.tv2.cache;

import com.google.gson.JsonParseException;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.User;
import com.heritage.tv2.util.JsonProvider;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Luu tru phien dang nhap: access/refresh token, nguoi dung hien tai va ngon ngu giao dien.
 *
 * <p>Thread-safe: duoc goi dong thoi tu {@code AuthInterceptor} (thread OkHttp) va UI.
 * Khi dang xuat / het phien, {@link #clearSession()} xoa token + user nhung GIU ngon ngu.</p>
 */
public class SessionStorage {

    static final String KEY_ACCESS_TOKEN = "auth.accessToken";
    static final String KEY_REFRESH_TOKEN = "auth.refreshToken";
    static final String KEY_TOKEN_TYPE = "auth.tokenType";
    static final String KEY_USER = "user.json";
    static final String KEY_LANGUAGE = "app.language";

    private final KeyValueStore store;
    private final List<Consumer<String>> languageListeners = new CopyOnWriteArrayList<>();

    public SessionStorage(KeyValueStore store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
    }

    // ------------------------------------------------------------------ Tokens

    /**
     * Luu cap token. Neu {@code refreshToken} moi rong (mot so backend khong xoay vong
     * refresh token) thi giu refresh token cu.
     */
    public synchronized void saveTokens(AuthTokens tokens) {
        if (tokens == null || !tokens.hasAccessToken()) {
            throw new IllegalArgumentException("accessToken is required");
        }
        Map<String, String> values = new HashMap<>();
        values.put(KEY_ACCESS_TOKEN, tokens.getAccessToken());
        String refresh = tokens.getRefreshToken();
        if (refresh != null && !refresh.isBlank()) {
            values.put(KEY_REFRESH_TOKEN, refresh);
        }
        values.put(KEY_TOKEN_TYPE, tokens.getTokenType() == null ? "Bearer" : tokens.getTokenType());
        store.putAll(values);
    }

    public synchronized String getAccessToken() {
        return blankToNull(store.get(KEY_ACCESS_TOKEN));
    }

    public synchronized String getRefreshToken() {
        return blankToNull(store.get(KEY_REFRESH_TOKEN));
    }

    public synchronized AuthTokens getTokens() {
        String access = getAccessToken();
        if (access == null) {
            return null;
        }
        AuthTokens tokens = new AuthTokens(access, getRefreshToken());
        String type = store.get(KEY_TOKEN_TYPE);
        if (type != null) {
            tokens.setTokenType(type);
        }
        return tokens;
    }

    /** Da dang nhap neu con access token hoac refresh token (co the tu lam moi). */
    public synchronized boolean isLoggedIn() {
        return getAccessToken() != null || getRefreshToken() != null;
    }

    // -------------------------------------------------------------------- User

    public synchronized void saveUser(User user) {
        store.put(KEY_USER, user == null ? null : JsonProvider.gson().toJson(user));
    }

    /** @return user da cache, hoac {@code null} neu chua co / du lieu hong. */
    public synchronized User getUser() {
        String json = store.get(KEY_USER);
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            return JsonProvider.gson().fromJson(json, User.class);
        } catch (JsonParseException e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- Language

    /** Ngon ngu hien tai (luon hop le), mac dinh {@link AppConfig#DEFAULT_LANGUAGE}. */
    public synchronized String getLanguage() {
        String code = store.get(KEY_LANGUAGE);
        return AppConfig.isSupportedLanguage(code) ? normalize(code) : AppConfig.DEFAULT_LANGUAGE;
    }

    /**
     * Doi ngon ngu va thong bao listener (neu thuc su thay doi).
     *
     * @throws IllegalArgumentException neu ma ngon ngu khong duoc ho tro
     */
    public void setLanguage(String code) {
        if (!AppConfig.isSupportedLanguage(code)) {
            throw new IllegalArgumentException("Unsupported language: " + code);
        }
        String normalized = normalize(code);
        boolean changed;
        synchronized (this) {
            changed = !normalized.equals(getLanguage()) || store.get(KEY_LANGUAGE) == null;
            store.put(KEY_LANGUAGE, normalized);
        }
        if (changed) {
            for (Consumer<String> l : languageListeners) {
                l.accept(normalized);
            }
        }
    }

    public void addLanguageListener(Consumer<String> listener) {
        languageListeners.add(listener);
    }

    public void removeLanguageListener(Consumer<String> listener) {
        languageListeners.remove(listener);
    }

    // ------------------------------------------------------------------- Clear

    /** Xoa token + user (dang xuat / het phien). Ngon ngu duoc giu lai. */
    public synchronized void clearSession() {
        Map<String, String> values = new HashMap<>();
        values.put(KEY_ACCESS_TOKEN, null);
        values.put(KEY_REFRESH_TOKEN, null);
        values.put(KEY_TOKEN_TYPE, null);
        values.put(KEY_USER, null);
        store.putAll(values);
    }

    private static String normalize(String code) {
        return code.trim().toLowerCase(Locale.ROOT);
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s;
    }
}
