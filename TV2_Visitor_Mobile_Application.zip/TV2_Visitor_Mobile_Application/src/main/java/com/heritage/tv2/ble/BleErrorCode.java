package com.heritage.tv2.ble;

/**
 * Ma loi BLE do module TV3 bao sang TV2 qua {@link BleBridgeListener#onBleError(BleErrorCode, String)}.
 */
public enum BleErrorCode {
    /** Thiet bi dang tat Bluetooth. */
    BLUETOOTH_OFF,
    /** Nguoi dung tu choi quyen Bluetooth (BLUETOOTH_SCAN/CONNECT) hoac Vi tri (ACCESS_FINE_LOCATION). */
    PERMISSION_DENIED,
    /** Phan cung thiet bi khong ho tro Bluetooth Low Energy. */
    HARDWARE_UNSUPPORTED,
    /** Loi he thong khi khoi dong quet BLE. */
    SCAN_FAILED
}
