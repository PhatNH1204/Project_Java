package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Language;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.request.UpdateProfileRequest;
import com.heritage.tv2.util.Result;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Quan ly ngon ngu giao dien + noi dung.
 *
 * <p>Doi ngon ngu = (1) dong bo {@code preferredLanguage} len server qua {@code PUT /api/users/me},
 * (2) luu cuc bo vao {@link SessionStorage} -> {@code AuthInterceptor} gui {@code Accept-Language} moi
 * cho moi request tiep theo, (3) phat su kien cho UI ve lai.</p>
 */
public class LanguageRepository {

    /** Ma loi: da doi tren thiet bi nhung chua dong bo duoc len server (mat mang). */
    public static final String CODE_SAVED_LOCALLY = "LANGUAGE_SAVED_LOCALLY";

    private static final List<Language> SUPPORTED = List.of(
            new Language(1L, AppConfig.LANGUAGE_VI, "Tiếng Việt", true),
            new Language(2L, AppConfig.LANGUAGE_EN, "English", false));

    private final HeritageApiService api;
    private final SessionStorage session;

    public LanguageRepository(HeritageApiService api, SessionStorage session) {
        this.api = api;
        this.session = session;
    }

    public List<Language> getSupportedLanguages() {
        return SUPPORTED;
    }

    public String getCurrentLanguage() {
        return session.getLanguage();
    }

    public Language findLanguage(String code) {
        return SUPPORTED.stream().filter(l -> l.getCode().equalsIgnoreCase(code)).findFirst().orElse(SUPPORTED.get(0));
    }

    /**
     * Doi ngon ngu.
     *
     * @return user moi tu server; neu mat mang -> loi {@link #CODE_SAVED_LOCALLY} (ngon ngu VAN duoc doi cuc bo)
     */
    public Result<User> changeLanguage(String code) {
        if (!AppConfig.isSupportedLanguage(code)) {
            return Result.error("LANGUAGE_NOT_SUPPORTED", null, 0);
        }
        String normalized = code.trim().toLowerCase(Locale.ROOT);
        if (!session.isLoggedIn()) {
            // Chua dang nhap (vd: man hinh Login) -> chi doi cuc bo.
            session.setLanguage(normalized);
            return Result.success(null);
        }
        Result<User> result = ApiCaller.execute(api.updateMe(UpdateProfileRequest.language(normalized)));
        if (result.isSuccess()) {
            session.saveUser(result.getData());
            session.setLanguage(normalized);
            return result;
        }
        if (result.isNetworkError()) {
            session.setLanguage(normalized);
            User cached = session.getUser();
            if (cached != null) {
                cached.setPreferredLanguage(normalized);
                session.saveUser(cached);
            }
            return Result.error(CODE_SAVED_LOCALLY, null, 0);
        }
        return result;
    }

    public void addLanguageListener(Consumer<String> listener) {
        session.addLanguageListener(listener);
    }

    public void removeLanguageListener(Consumer<String> listener) {
        session.removeLanguageListener(listener);
    }
}
