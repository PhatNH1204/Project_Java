package com.heritage.tv2.repository;

import com.heritage.tv2.api.ApiCaller;
import com.heritage.tv2.api.HeritageApiService;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

/**
 * Gui danh gia &amp; phan hoi hien vat: {@code POST /api/feedback} (Phoi hop TV5).
 * Validate bat buoc so sao (1..5) va nhan xet (khong trong, &lt;= 1000 ky tu) truoc khi goi API.
 */
public class FeedbackRepository {

    public static final String CODE_INVALID_RATING = "VALIDATION_INVALID_RATING";
    public static final String CODE_EMPTY_COMMENT = "VALIDATION_EMPTY_COMMENT";
    public static final String CODE_COMMENT_TOO_LONG = "VALIDATION_COMMENT_TOO_LONG";

    private final HeritageApiService api;

    public FeedbackRepository(HeritageApiService api) {
        this.api = api;
    }

    public Result<Void> submit(FeedbackRequest request) {
        if (request == null) {
            return Result.error(Result.CODE_VALIDATION, I18n.tr("feedback.error_invalid_rating"), 0);
        }
        FeedbackRequest.ValidationError err = request.validate();
        if (err != null) {
            switch (err) {
                case INVALID_RATING:
                    return Result.error(CODE_INVALID_RATING, I18n.tr("feedback.error_invalid_rating"), 0);
                case EMPTY_COMMENT:
                    return Result.error(CODE_EMPTY_COMMENT, I18n.tr("feedback.error_empty_comment"), 0);
                case COMMENT_TOO_LONG:
                    return Result.error(CODE_COMMENT_TOO_LONG, I18n.tr("feedback.error_comment_too_long"), 0);
                default:
                    return Result.error(Result.CODE_VALIDATION, I18n.tr("error.unknown"), 0);
            }
        }
        return ApiCaller.execute(api.submitFeedback(
                new FeedbackRequest(request.getArtifactId(), request.getRating(), request.getComment().trim())));
    }
}
