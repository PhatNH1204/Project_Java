package com.heritage.tv2.ble;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.model.User;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.detail.ArtifactDetailScreen;
import com.heritage.tv2.ui.detail.ArtifactDetailViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit &amp; Integration Test {@code BleResilienceTest} cho Tich hop BLE (Gate 4) tren nhanh {@code feature/mobile-ble-bridge}.
 *
 * <p>Xac minh:</p>
 * <ol>
 *     <li>Kich ban Beacon vao vung ({@code onBeaconTriggered}) -&gt; Hien Banner/BottomSheet goi y khong gay gian doan
 *     -&gt; Bam "Xem ngay" goi {@code GET /api/beacons/{id}/content?lang={lang}} va mo dung {@code ArtifactDetail}.</li>
 *     <li>Quy tac BAT BUOC khi roi vung phu song ({@code onBeaconOutOfRange}): KHONG dong man hinh,
 *     KHONG xoa du lieu tren UI, KHONG dung Audio/Video dang phat, chuyen nguon du phong sang {@code ArtifactCache}
 *     va hien nhan trang thai nho.</li>
 *     <li>Phoi hop ghi nhan {@code Interaction} qua hook {@link InteractionCallback} (thoi diem mo &amp; thoi luong xem).</li>
 *     <li>4 kich ban Debug Simulator &amp; {@link BlePermissionHelper} khi tat Bluetooth / tu choi quyen
 *     van cho phep dung app thu cong binh thuong.</li>
 * </ol>
 */
class BleResilienceTest {

    private MockBackendInterceptor mockBackend;
    private AppContainer container;
    private Navigator navigator;
    private BleBridgeCoordinator bleBridge;
    private BleDebugSimulator simulator;

    @BeforeEach
    void setUp() {
        I18n.setLanguage(AppConfig.LANGUAGE_VI);
        mockBackend = new MockBackendInterceptor(0L);
        container = new AppContainer(
                new InMemoryKeyValueStore(),
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mockBackend,
                AppConfig.MOCK_BASE_URL);
        Result<User> login = container.authRepository()
                .login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        assertTrue(login.isSuccess());
        navigator = new Navigator(container, s -> { }, (m, e) -> { }, l -> { });
        navigator.navigateTo(Navigator.Route.MAIN);
        bleBridge = container.bleBridge();
        simulator = container.bleDebugSimulator();
    }

    @Test
    void beaconEnter_showsNonIntrusivePrompt_andViewNowOpensArtifactDetail_andNotifiesInteractionCallback() {
        List<String> callbackLogs = new ArrayList<>();
        bleBridge.setInteractionCallback(new InteractionCallback() {
            @Override
            public void onContentOpened(String beaconId, long artifactId, long openedAtEpochMs) {
                callbackLogs.add("OPEN:" + beaconId + ":" + artifactId);
            }

            @Override
            public void onContentViewed(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds) {
                callbackLogs.add("VIEWED:" + beaconId + ":" + artifactId + ":" + durationSeconds);
            }
        });

        // 1. Nguoi dung dang o man hinh MAIN; TV3 goi onBeaconTriggered (Kich ban 1: ENTER B-101)
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());
        BeaconSignalEvent enterEvent = simulator.triggerScenario1EnterBeacon();
        assertEquals("B-101", enterEvent.getBeaconId());
        assertEquals(BeaconSignalEvent.EventType.ENTER, enterEvent.getEventType());

        // Khong tu dong chuyen man hinh (non-intrusive), chi hien Banner/BottomSheet goi y
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());
        assertNotNull(bleBridge.pendingBeaconPrompt().getValue());
        assertEquals("B-101", bleBridge.pendingBeaconPrompt().getValue().getBeaconId());

        // 2. Nguoi dung bam "Xem ngay" -> goi GET /api/beacons/B-101/content?lang=vi -> mo ArtifactDetail (101)
        navigator.acceptCurrentBeaconPrompt();
        assertNull(bleBridge.pendingBeaconPrompt().getValue(), "Prompt must close after accepting");
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        assertTrue(navigator.currentScreen() instanceof ArtifactDetailScreen);

        ArtifactDetailViewModel detailVm = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertEquals(101L, detailVm.getArtifactId());
        assertEquals("B-101", detailVm.getAssociatedBeaconId());
        assertTrue(detailVm.isCachedInArtifactCache());
        assertNotNull(container.artifactCache().getByBeaconLocalized("B-101", "vi", "vi"));

        // Hook InteractionCallback da bao cho TV3 thoi diem mo noi dung
        assertEquals(List.of("OPEN:B-101:101"), callbackLogs);
    }

    @Test
    void onBeaconOutOfRange_doesNotCloseScreen_doesNotClearUi_doesNotStopAudioOrVideo_andSwitchesToArtifactCache() {
        List<Integer> recordedDurations = new ArrayList<>();
        bleBridge.setInteractionCallback(new InteractionCallback() {
            @Override
            public void onContentOpened(String beaconId, long artifactId, long openedAtEpochMs) {
            }

            @Override
            public void onContentViewed(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds) {
                recordedDurations.add(durationSeconds);
            }
        });

        // 1. Beacon B-101 vao vung -> Khach bam "Xem ngay" -> Mo ArtifactDetail (101 - Trong dong Ngoc Lu)
        simulator.triggerEnterBeacon("B-101");
        navigator.acceptCurrentBeaconPrompt();
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());

        ArtifactDetailViewModel detailVm = (ArtifactDetailViewModel) navigator.currentViewModel();
        ArtifactDetailScreen detailScreen = (ArtifactDetailScreen) navigator.currentScreen();
        assertTrue(detailVm.artifactState().getValue().isSuccess());
        Artifact initialArtifact = detailVm.artifactState().getValue().getData();
        assertNotNull(initialArtifact);
        assertEquals("Trống đồng Ngọc Lũ", initialArtifact.getName());

        // 2. Khach dang nghe Audio (o giay 52) va xem Video (o giay 24)
        detailVm.setAudioPlaying(true);
        detailVm.seekAudio(52, 185);
        detailVm.setVideoPlaying(true);
        detailVm.seekVideo(24, 95);
        assertTrue(detailVm.isAudioPlaying());
        assertTrue(detailVm.isVideoPlaying());

        // 3. Khach di ra khoi vung phu song Beacon B-101 (va mat song/mat mang)
        mockBackend.setSimulateNetworkError(true);
        simulator.triggerScenario2OutOfRange(); // goi BleBridgeListener.onBeaconOutOfRange("B-101")

        // XAC MINH QUY TAC BAT BUOC GATE 4:
        // (a) KHONG dong man hinh
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        assertEquals(detailScreen, navigator.currentScreen());

        // (b) KHONG xoa du lieu tren UI
        assertTrue(detailVm.artifactState().getValue().isSuccess());
        assertNotNull(detailVm.artifactState().getValue().getData());
        assertEquals("Trống đồng Ngọc Lũ", detailVm.artifactState().getValue().getData().getName());
        assertNotNull(detailVm.resolveTranslation(detailVm.artifactState().getValue().getData()));

        // (c) KHONG dung Audio/Video dang phat
        assertTrue(detailVm.isAudioPlaying(), "Audio playback MUST NOT be stopped on beacon out of range");
        assertEquals(52, detailVm.getAudioPositionSeconds(), "Audio seek position MUST be preserved");
        assertTrue(detailVm.isVideoPlaying(), "Video playback MUST NOT be stopped on beacon out of range");
        assertEquals(24, detailVm.getVideoPositionSeconds(), "Video seek position MUST be preserved");

        // (d) Chuyen nguon doc du phong sang ArtifactCache & hien nhan trang thai nho
        assertTrue(detailVm.fromOfflineCache().getValue(), "Fallback source must switch to ArtifactCache");
        assertTrue(detailVm.beaconOutOfRange().getValue());
        assertEquals("Bạn đã rời khỏi vùng beacon — vẫn có thể tiếp tục xem nội dung",
                detailVm.beaconOutOfRangeNotice().getValue());

        // Render offscreen man hinh ArtifactDetail sau khi roi vung beacon de xac minh UI khong loi
        paintOffscreen(detailScreen);

        // Ngay ca khi tai lai du lieu trong luc mat mang/mat song, ArtifactCache van phuc vu day du
        detailVm.loadArtifact();
        assertTrue(detailVm.artifactState().getValue().isSuccess());
        assertEquals("Trống đồng Ngọc Lũ", detailVm.artifactState().getValue().getData().getName());
        mockBackend.setSimulateNetworkError(false);

        // 4. Khi khach thoat man hinh chi tiet, InteractionCallback nhan duoc thoi luong xem (>= 52s)
        navigator.navigateBackToMain();
        assertFalse(recordedDurations.isEmpty());
        assertTrue(recordedDurations.get(0) >= 52);
    }

    @Test
    void debugSimulator_scenario3SwitchBeacon_andScenario4BluetoothOffWarningWhileManualAppWorks() {
        // Kich ban 3: Chuyen vung sang Beacon khac (B-101 -> B-102)
        BeaconSignalEvent switchEvent = simulator.triggerScenario3SwitchBeacon();
        assertEquals("B-102", switchEvent.getBeaconId());
        assertEquals(BeaconSignalEvent.EventType.SWITCH, switchEvent.getEventType());
        assertNotNull(bleBridge.pendingBeaconPrompt().getValue());

        // Nguoi dung bam "Bo qua" -> prompt dong lai, man hinh khong doi
        bleBridge.dismissBeaconPrompt();
        assertNull(bleBridge.pendingBeaconPrompt().getValue());
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());

        // Kich ban 4: Gia lap tat Bluetooth / tu choi quyen BLE
        BleErrorCode errCode = simulator.triggerScenario4BluetoothOffOrPermissionDenied();
        assertEquals(BleErrorCode.BLUETOOTH_OFF, errCode);
        assertFalse(container.blePermissionHelper().isBluetoothEnabled());
        assertFalse(container.blePermissionHelper().isBleReady());
        assertNotNull(bleBridge.warningBannerMessage().getValue());

        // Khach van dung app thu cong binh thuong (canUseAppManually == true)
        assertTrue(container.blePermissionHelper().canUseAppManually());
        navigator.openArtifactDetail(102L);
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        ArtifactDetailViewModel vm102 = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertEquals("Rồng đá điện Kính Thiên", vm102.artifactState().getValue().getData().getName());

        // Bat lai Bluetooth & cap quyen -> banner canh bao bien mat, BLE san sang
        bleBridge.resolveBlePermissionsAndEnableBluetooth();
        assertTrue(container.blePermissionHelper().isBleReady());
        assertNull(bleBridge.warningBannerMessage().getValue());

        // Kiem tra danh sach quyen theo Android SDK (API 31+ vs API 26-30)
        assertEquals(2, container.blePermissionHelper().requiredPermissionsForSdk(31).size());
        assertEquals(1, container.blePermissionHelper().requiredPermissionsForSdk(28).size());
    }

    private static void paintOffscreen(com.heritage.tv2.ui.base.Screen screen) {
        screen.setSize(AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT);
        screen.doLayout();
        BufferedImage img = new BufferedImage(
                AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        try {
            screen.paintAll(g2);
        } finally {
            g2.dispose();
        }
    }
}
