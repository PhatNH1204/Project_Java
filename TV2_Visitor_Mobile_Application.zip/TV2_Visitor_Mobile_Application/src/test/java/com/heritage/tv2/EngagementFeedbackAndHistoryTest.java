package com.heritage.tv2;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.repository.VisitHistoryRepository;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.detail.ArtifactDetailScreen;
import com.heritage.tv2.ui.detail.ArtifactDetailViewModel;
import com.heritage.tv2.ui.main.MainScreen;
import com.heritage.tv2.ui.main.MainViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.Result;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit &amp; Integration Test cho Tuan 4 (Gate 3 - Phan 2) tren nhanh {@code feature/mobile-engagement-feedback}:
 * <ol>
 *     <li>Optimistic UI cho Yeu thich ({@code Favorite}) tren {@link ArtifactDetailScreen} + hoan tac (rollback) khi loi mang.</li>
 *     <li>Validate bat buoc cho Danh gia &amp; Phan hoi ({@link FeedbackRequest}: Rating 1..5, Comment khong trong &amp; &lt;= 1000 ky tu).</li>
 *     <li>Tab 3 chia 2 sub-tab (Yeu thich &amp; Lich su tham quan), sap xep theo thoi gian gan nhat, nhan phan biet
 *     {@code MANUAL} vs {@code BEACON_BLE}, va tang {@link VisitHistoryRepository} tach biet nguon du lieu.</li>
 *     <li>Luong End-to-End: Dang nhap -&gt; Tim di san -&gt; Xem noi dung -&gt; Yeu thich -&gt; Gui danh gia/phan hoi -&gt; Xem lai trong Lich su.</li>
 * </ol>
 */
class EngagementFeedbackAndHistoryTest {

    private MockBackendInterceptor mockBackend;
    private AppContainer container;
    private Navigator navigator;

    @BeforeEach
    void setUp() {
        mockBackend = new MockBackendInterceptor(0L);
        container = new AppContainer(
                new InMemoryKeyValueStore(),
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mockBackend,
                AppConfig.MOCK_BASE_URL);
        Result<User> login = container.authRepository()
                .login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        assertTrue(login.isSuccess());
        navigator = new Navigator(container, s -> { }, (m, e) -> { }, l -> { });
        navigator.navigateTo(Navigator.Route.MAIN);
    }

    @Test
    void favoriteOptimisticUi_flipsImmediately_andRollsBackOnNetworkError() {
        // Mo Hien vat 104 (ban dau CHUA co trong danh sach Yeu thich -> favoriteState = false)
        navigator.openArtifactDetail(104L);
        ArtifactDetailViewModel vm = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertFalse(vm.favoriteState().getValue(), "Artifact 104 should initially not be favorited");

        // Theo doi moi su thay doi cua favoriteState theo thu tu thoi gian
        List<Boolean> transitions = new ArrayList<>();
        Runnable unsub = vm.favoriteState().observe(transitions::add);

        // 1. Bat gia lap loi mang roi bam Yeu thich -> phai doi sang true (optimistic) roi hoan tac ve false (rollback)
        mockBackend.setSimulateNetworkError(true);
        vm.toggleFavorite();
        mockBackend.setSimulateNetworkError(false);

        assertEquals(List.of(false, true, false), transitions,
                "Optimistic UI must flip false -> true immediately, then rollback to false on network failure");
        assertFalse(vm.favoriteState().getValue());
        assertNotNull(vm.errorEvent().getValue());
        unsub.run();

        // 2. Khi mang binh thuong -> bam Yeu thich thanh cong va giu trang thai true
        vm.toggleFavorite();
        assertTrue(vm.favoriteState().getValue());

        // 3. Kiem tra hoan tac chieu nguoc lai (dang true -> bam Bo yeu thich khi mat mang -> false -> rollback ve true)
        List<Boolean> removeTransitions = new ArrayList<>();
        Runnable unsub2 = vm.favoriteState().observe(removeTransitions::add);

        mockBackend.setSimulateNetworkError(true);
        vm.toggleFavorite();
        mockBackend.setSimulateNetworkError(false);

        assertEquals(List.of(true, false, true), removeTransitions,
                "Optimistic UI must flip true -> false immediately, then rollback to true on DELETE failure");
        assertTrue(vm.favoriteState().getValue());
        unsub2.run();
    }

    @Test
    void feedbackValidation_enforcesRatingAndCommentRules_beforeCallingApi() {
        navigator.openArtifactDetail(101L);
        ArtifactDetailViewModel vm = (ArtifactDetailViewModel) navigator.currentViewModel();
        int initialCount = mockBackend.getFeedbacks().size();

        // 1. Chua chon sao (null) hoac sao ngoai khoang 1..5 (0, 6) -> bao loi validate, khong goi API
        vm.submitFeedback(null, "Nhan xet hop le");
        assertNotNull(vm.feedbackErrorMessage().getValue());
        assertNull(vm.feedbackSuccessMessage().getValue());
        assertEquals(initialCount, mockBackend.getFeedbacks().size());

        vm.submitFeedback(0, "Nhan xet hop le");
        assertEquals(FeedbackRequest.ValidationError.INVALID_RATING,
                new FeedbackRequest(101L, 0, "Nhan xet hop le").validate());
        assertEquals(initialCount, mockBackend.getFeedbacks().size());

        vm.submitFeedback(6, "Nhan xet hop le");
        assertEquals(FeedbackRequest.ValidationError.INVALID_RATING,
                new FeedbackRequest(101L, 6, "Nhan xet hop le").validate());
        assertEquals(initialCount, mockBackend.getFeedbacks().size());

        // 2. Nhan xet de trong hoac chi chua khoang trang -> bao loi validate, khong goi API
        vm.submitFeedback(5, "");
        assertEquals(FeedbackRequest.ValidationError.EMPTY_COMMENT,
                new FeedbackRequest(101L, 5, "").validate());
        assertNotNull(vm.feedbackErrorMessage().getValue());
        assertEquals(initialCount, mockBackend.getFeedbacks().size());

        vm.submitFeedback(5, "   ");
        assertEquals(FeedbackRequest.ValidationError.EMPTY_COMMENT,
                new FeedbackRequest(101L, 5, "   ").validate());
        assertEquals(initialCount, mockBackend.getFeedbacks().size());

        // 3. Nhan xet vuot qua 1000 ky tu -> bao loi validate
        String overlong = "a".repeat(FeedbackRequest.MAX_COMMENT_LENGTH + 1);
        vm.submitFeedback(4, overlong);
        assertEquals(FeedbackRequest.ValidationError.COMMENT_TOO_LONG,
                new FeedbackRequest(101L, 4, overlong).validate());
        assertNotNull(vm.feedbackErrorMessage().getValue());
        assertEquals(initialCount, mockBackend.getFeedbacks().size());

        // 4. Du lieu hop le (Rating = 4, Comment co noi dung) -> goi POST /api/feedback thanh cong
        vm.submitFeedback(4, "Thuyết minh rất chi tiết và sống động!");
        assertNull(vm.feedbackErrorMessage().getValue());
        assertNotNull(vm.feedbackSuccessMessage().getValue());
        assertEquals("", vm.getDraftComment());
        assertEquals(initialCount + 1, mockBackend.getFeedbacks().size());
        FeedbackRequest saved = mockBackend.getFeedbacks().get(initialCount);
        assertEquals(101L, saved.getArtifactId());
        assertEquals(4, saved.getRating());
        assertEquals("Thuyết minh rất chi tiết và sống động!", saved.getComment());
    }

    @Test
    void visitHistoryRepository_supportsSwitchingDataSources_andSortsMostRecentFirst() {
        VisitHistoryRepository repo = container.visitHistoryRepository();
        assertEquals(VisitHistoryRepository.SourceMode.INTERACTION_AGGREGATED, repo.getSourceMode());

        // Ghi nhan 1 luot mo thu cong (MANUAL) cho hien vat 104
        Artifact a104 = container.heritageRepository().getArtifact(104L).getData();
        repo.recordArtifactView(a104, "Bảo tàng Lịch sử Quốc gia", VisitHistory.SOURCE_MANUAL);

        Result<List<VisitHistory>> historyRes = repo.getVisitHistory();
        assertTrue(historyRes.isSuccess());
        List<VisitHistory> list = historyRes.getData();
        assertFalse(list.isEmpty());

        // Muc dau tien phai la hien vat 104 vua xem (thoi gian gan nhat) voi nguon MANUAL
        VisitHistory newest = list.get(0);
        assertEquals(104L, newest.getArtifactId());
        assertEquals(VisitHistory.SOURCE_MANUAL, newest.getSource());
        assertFalse(newest.isFromBeacon());

        // Kiem tra thu tu thoi gian giam dan (newest first)
        for (int i = 0; i < list.size() - 1; i++) {
            String t1 = list.get(i).getVisitedAt();
            String t2 = list.get(i + 1).getVisitedAt();
            assertTrue(t1.compareTo(t2) >= 0, "Visit history must be ordered by visitedAt descending");
        }

        // Chuyen sang che do bang VisitHistory doc lap (STANDALONE_TABLE) -> van hoat dong on dinh
        repo.setSourceMode(VisitHistoryRepository.SourceMode.STANDALONE_TABLE);
        assertEquals(VisitHistoryRepository.SourceMode.STANDALONE_TABLE, repo.getSourceMode());
        Result<List<VisitHistory>> standaloneRes = repo.getVisitHistory();
        assertTrue(standaloneRes.isSuccess());
        assertEquals(104L, standaloneRes.getData().get(0).getArtifactId());
    }

    @Test
    void endToEndFlow_login_searchSite_viewDetail_favorite_submitFeedback_andReopenFromHistorySubTab() {
        MainScreen mainScreen = (MainScreen) navigator.currentScreen();
        MainViewModel mainVm = (MainViewModel) navigator.currentViewModel();

        // 1. Tim di san tren Tab 1 ("Bảo tàng", danh muc MUSEUM)
        mainVm.setSearchAndCategory("Bảo tàng", HeritageSite.CATEGORY_MUSEUM);
        assertTrue(mainVm.sitesUiState().getValue().isSuccess());
        List<HeritageSite> foundSites = mainVm.sitesUiState().getValue().getData();
        assertEquals(1, foundSites.size());
        HeritageSite museum = foundSites.get(0);
        assertEquals("BTLSQG", museum.getCode());

        // 2. Chon xem Hien vat 104 (An vang Hoang de chi bao) thuoc Bao tang -> mo ArtifactDetail (MANUAL)
        navigator.openArtifactDetail(104L, VisitHistory.SOURCE_MANUAL);
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        ArtifactDetailViewModel detailVm = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertEquals(104L, detailVm.getArtifactId());
        assertEquals(VisitHistory.SOURCE_MANUAL, detailVm.getOpenSource());

        // 3. Bam Yeu thich (Optimistic UI -> POST /api/favorites/104)
        assertFalse(detailVm.favoriteState().getValue());
        detailVm.toggleFavorite();
        assertTrue(detailVm.favoriteState().getValue());

        // 4. Gui Danh gia 5 sao & Phan hoi (POST /api/feedback)
        detailVm.submitFeedback(5, "Ấn vàng Hoàng đế chi bảo vô cùng tinh xảo!");
        assertNotNull(detailVm.feedbackSuccessMessage().getValue());
        assertEquals(1, mockBackend.getFeedbacks().size());

        // 5. Quay ve Main -> chuyen sang Tab 3 (Yeu thich & Lich su)
        navigator.navigateBackToMain();
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());
        mainScreen = (MainScreen) navigator.currentScreen();
        mainVm = (MainViewModel) navigator.currentViewModel();
        mainScreen.switchTab(MainViewModel.TAB_FAV_HISTORY);

        // Kiem tra Sub-tab 1 (Yeu thich): co Hien vat 104
        mainScreen.switchFavHistorySubTab(MainViewModel.SUB_TAB_FAVORITES);
        assertEquals(MainViewModel.SUB_TAB_FAVORITES, mainVm.getFavHistorySubTab());
        List<Favorite> favs = mainVm.favorites().getValue();
        assertTrue(favs.stream().anyMatch(f -> f.getArtifactId() == 104L));

        // Chuyen sang Sub-tab 2 (Lich su tham quan): Hien vat 104 nam o dau danh sach (gan nhat) voi nhan MANUAL
        mainScreen.switchFavHistorySubTab(MainViewModel.SUB_TAB_HISTORY);
        assertEquals(MainViewModel.SUB_TAB_HISTORY, mainVm.getFavHistorySubTab());
        List<VisitHistory> history = mainVm.visitHistory().getValue();
        assertFalse(history.isEmpty());
        VisitHistory topEntry = history.get(0);
        assertEquals(104L, topEntry.getArtifactId());
        assertEquals(VisitHistory.SOURCE_MANUAL, topEntry.getSource());

        // Render offscreen Tab 3 (sub-tab Lich su) va ArtifactDetailScreen
        paintOffscreen(mainScreen);

        // 6. Nhan vao muc trong Lich su de mo lai man hinh ArtifactDetail
        navigator.openArtifactDetail(topEntry.getArtifactId(), topEntry.getSource());
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        assertEquals(104L, ((ArtifactDetailViewModel) navigator.currentViewModel()).getArtifactId());
        paintOffscreen(navigator.currentScreen());
    }

    private static void paintOffscreen(com.heritage.tv2.ui.base.Screen screen) {
        screen.setSize(AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT);
        screen.doLayout();
        BufferedImage img = new BufferedImage(
                AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        try {
            screen.paintAll(g2);
        } finally {
            g2.dispose();
        }
    }
}
