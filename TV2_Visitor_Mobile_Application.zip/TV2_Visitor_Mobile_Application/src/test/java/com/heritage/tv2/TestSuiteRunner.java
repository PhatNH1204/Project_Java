package com.heritage.tv2;

import org.junit.jupiter.engine.JupiterTestEngine;
import org.junit.platform.engine.ConfigurationParameters;
import org.junit.platform.engine.DiscoveryFilter;
import org.junit.platform.engine.DiscoverySelector;
import org.junit.platform.engine.EngineDiscoveryRequest;
import org.junit.platform.engine.EngineExecutionListener;
import org.junit.platform.engine.ExecutionRequest;
import org.junit.platform.engine.TestDescriptor;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.engine.UniqueId;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.engine.reporting.ReportEntry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Bo chay JUnit 5 Jupiter truc tiep qua {@link JupiterTestEngine}.
 */
public final class TestSuiteRunner {

    private TestSuiteRunner() {
    }

    public static void main(String[] args) {
        String[] testClassNames = {
                "com.heritage.tv2.cache.SessionStorageTest",
                "com.heritage.tv2.cache.ArtifactCacheTest",
                "com.heritage.tv2.api.AuthInterceptorTest",
                "com.heritage.tv2.FlowIntegrationTest",
                "com.heritage.tv2.ExploreMapAndDetailTest",
                "com.heritage.tv2.EngagementFeedbackAndHistoryTest",
                "com.heritage.tv2.ble.BleResilienceTest",
                "com.heritage.tv2.EndToEndIntegrationWeek56Test",
                "com.heritage.tv2.QaAcceptanceWeek67Test"
        };

        JupiterTestEngine engine = new JupiterTestEngine();
        EngineDiscoveryRequest discoveryRequest = new SimpleDiscoveryRequest(testClassNames);
        TestDescriptor root = engine.discover(discoveryRequest, UniqueId.forEngine(engine.getId()));

        AtomicInteger passed = new AtomicInteger();
        AtomicInteger failed = new AtomicInteger();
        List<String> failures = new ArrayList<>();

        EngineExecutionListener listener = new EngineExecutionListener() {
            @Override
            public void dynamicTestRegistered(TestDescriptor testDescriptor) {
            }

            @Override
            public void executionSkipped(TestDescriptor testDescriptor, String reason) {
                System.out.println("  [SKIP] " + testDescriptor.getDisplayName() + ": " + reason);
            }

            @Override
            public void executionStarted(TestDescriptor testDescriptor) {
            }

            @Override
            public void executionFinished(TestDescriptor testDescriptor, TestExecutionResult result) {
                if (!testDescriptor.isTest()) {
                    if (result.getStatus() == TestExecutionResult.Status.FAILED) {
                        failed.incrementAndGet();
                        Throwable t = result.getThrowable().orElse(null);
                        failures.add(testDescriptor.getDisplayName() + ": " + (t != null ? t : "failed"));
                        if (t != null) {
                            t.printStackTrace(System.out);
                        }
                    }
                    return;
                }
                if (result.getStatus() == TestExecutionResult.Status.SUCCESSFUL) {
                    passed.incrementAndGet();
                    System.out.println("  [PASS] "
                            + testDescriptor.getParent().map(TestDescriptor::getDisplayName).orElse("")
                            + " :: " + testDescriptor.getDisplayName());
                } else {
                    failed.incrementAndGet();
                    Throwable t = result.getThrowable().orElse(null);
                    String msg = testDescriptor.getDisplayName() + " -> " + (t != null ? t.getMessage() : "FAILED");
                    failures.add(msg);
                    System.out.println("  [FAIL] " + msg);
                    if (t != null) {
                        t.printStackTrace(System.out);
                    }
                }
            }

            @Override
            public void reportingEntryPublished(TestDescriptor testDescriptor, ReportEntry entry) {
            }
        };

        System.out.println("=== Running JUnit 5 Unit & Integration Tests ===");
        engine.execute(new ExecutionRequest(root, listener, EmptyConfigParams.INSTANCE));

        System.out.println("------------------------------------------------");
        System.out.println("Tests passed: " + passed.get() + ", failed: " + failed.get());
        if (failed.get() > 0) {
            System.out.println("Failures: " + failures);
            System.exit(1);
        }
        System.exit(0);
    }

    private static final class EmptyConfigParams implements ConfigurationParameters {
        static final EmptyConfigParams INSTANCE = new EmptyConfigParams();

        @Override
        public Optional<String> get(String key) {
            return Optional.empty();
        }

        @Override
        public Optional<Boolean> getBoolean(String key) {
            return Optional.empty();
        }

        @Override
        @SuppressWarnings("deprecation")
        public int size() {
            return 0;
        }

        @Override
        public Set<String> keySet() {
            return Collections.emptySet();
        }
    }

    private static final class SimpleDiscoveryRequest implements EngineDiscoveryRequest {
        private final List<DiscoverySelector> selectors = new ArrayList<>();

        SimpleDiscoveryRequest(String[] classNames) {
            for (String cn : classNames) {
                selectors.add(DiscoverySelectors.selectClass(cn));
            }
        }

        @Override
        @SuppressWarnings("unchecked")
        public <T extends DiscoverySelector> List<T> getSelectorsByType(Class<T> selectorType) {
            List<T> result = new ArrayList<>();
            for (DiscoverySelector s : selectors) {
                if (selectorType.isInstance(s)) {
                    result.add((T) s);
                }
            }
            return result;
        }

        @Override
        public <T extends DiscoveryFilter<?>> List<T> getFiltersByType(Class<T> filterType) {
            return Collections.emptyList();
        }

        @Override
        public ConfigurationParameters getConfigurationParameters() {
            return EmptyConfigParams.INSTANCE;
        }
    }
}
