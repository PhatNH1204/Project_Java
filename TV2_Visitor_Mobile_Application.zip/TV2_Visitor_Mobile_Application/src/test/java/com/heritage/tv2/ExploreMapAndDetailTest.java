package com.heritage.tv2;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.base.UiState;
import com.heritage.tv2.ui.detail.ArtifactDetailScreen;
import com.heritage.tv2.ui.detail.ArtifactDetailViewModel;
import com.heritage.tv2.ui.main.MainScreen;
import com.heritage.tv2.ui.main.MainViewModel;
import com.heritage.tv2.util.AppExecutors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Integration Test kiem tra toan bo yeu cau Tuan 3 (Gate 3 - Phan 1):
 * <ol>
 *     <li>Tab 1 - Danh sach Dia diem ({@link HeritageSite}): tim kiem theo ten/khu vuc, loc theo danh muc,
 *     4 trang thai Loading / Success / Empty / Error + Retry.</li>
 *     <li>Tab 2 - Ban do Di san: Marker theo latitude/longitude, kiem tra quyen vi tri GPS (Granted / Denied
 *     van xem duoc ban do &amp; bam Marker mo danh sach Artifact thuoc dia diem do).</li>
 *     <li>Man hinh Chi tiet Hien vat ({@link ArtifactDetailScreen}): van ban thuyet minh (fallback ngon ngu mac dinh
 *     neu thieu ban dich), thu vien hinh anh (anh du phong khi URL loi), Audio &amp; Video (Play/Pause/Seek,
 *     co lap loi tung file media ma khong lam trang trang van ban), luu va doc offline tu {@code ArtifactCache}.</li>
 * </ol>
 */
class ExploreMapAndDetailTest {

    private MockBackendInterceptor mockBackend;
    private AppContainer container;
    private Navigator navigator;

    @BeforeEach
    void setUp() {
        mockBackend = new MockBackendInterceptor(0L);
        container = new AppContainer(
                new InMemoryKeyValueStore(),
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mockBackend,
                AppConfig.MOCK_BASE_URL);
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        navigator = new Navigator(container, s -> { }, (m, e) -> { }, l -> { });
        navigator.navigateTo(Navigator.Route.MAIN);
    }

    @Test
    void tab1_searchByNameAndRegion_filterByCategory_andAllFourUiStates() {
        MainViewModel vm = (MainViewModel) navigator.currentViewModel();

        // 1. SUCCESS state ban dau (3 khu di san)
        UiState<List<HeritageSite>> initial = vm.sitesUiState().getValue();
        assertNotNull(initial);
        assertEquals(UiState.Status.SUCCESS, initial.getStatus());
        assertEquals(3, initial.getData().size());

        // 2. Tim kiem theo khu vuc (khong dau: "ba dinh") -> Hoang thanh Thang Long
        vm.setSearchAndCategory("ba dinh", HeritageSite.CATEGORY_ALL);
        assertEquals(UiState.Status.SUCCESS, vm.sitesUiState().getValue().getStatus());
        assertEquals(1, vm.sitesUiState().getValue().getData().size());
        assertEquals("HTTL", vm.sitesUiState().getValue().getData().get(0).getCode());

        // 3. Loc theo danh muc TEMPLE -> Van Mieu - Quoc Tu Giam
        vm.setSearchAndCategory("", HeritageSite.CATEGORY_TEMPLE);
        assertEquals(UiState.Status.SUCCESS, vm.sitesUiState().getValue().getStatus());
        assertEquals(1, vm.sitesUiState().getValue().getData().size());
        assertEquals("VMQTG", vm.sitesUiState().getValue().getData().get(0).getCode());

        // 4. EMPTY state khi tu khoa khong khop dia diem nao
        vm.setSearchAndCategory("KhongTonTaiXYZ", HeritageSite.CATEGORY_ALL);
        assertEquals(UiState.Status.EMPTY, vm.sitesUiState().getValue().getStatus());

        // Xoa bo loc -> quay ve SUCCESS (3 dia diem)
        vm.clearFilters();
        assertEquals(UiState.Status.SUCCESS, vm.sitesUiState().getValue().getStatus());
        assertEquals(3, vm.sitesUiState().getValue().getData().size());

        // 5. ERROR state khi mat mang + nut Retry khoi phuc ve SUCCESS
        vm.simulateSitesNetworkError();
        assertEquals(UiState.Status.ERROR, vm.sitesUiState().getValue().getStatus());
        assertNotNull(vm.sitesUiState().getValue().getErrorMessage());

        vm.retryLoadSites();
        assertEquals(UiState.Status.SUCCESS, vm.sitesUiState().getValue().getStatus());
        assertEquals(3, vm.sitesUiState().getValue().getData().size());
    }

    @Test
    void tab2_mapGpsPermissionDenied_stillAllowsBrowsingMapAndOpeningSiteArtifacts() {
        MainScreen mainScreen = (MainScreen) navigator.currentScreen();
        MainViewModel vm = (MainViewModel) navigator.currentViewModel();
        mainScreen.switchTab(MainViewModel.TAB_MAP);

        // 1. Khi GPS Permission = GRANTED -> tinh duoc khoang cach > 0 km
        assertTrue(vm.isLocationPermissionGranted());
        HeritageSite vanMieu = vm.findSiteById(2L);
        assertNotNull(vanMieu);
        assertTrue(vm.distanceFromUserKm(vanMieu) > 0.1);

        // 2. Nguoi dung TU CHOI quyen vi tri (DENIED)
        vm.setLocationPermissionGranted(false);
        assertFalse(vm.isLocationPermissionGranted());

        // Van xem ban do va bam vao Marker Van Mieu (siteId = 2) binh thuong
        mainScreen.selectSiteOnMap(vanMieu);
        assertEquals(2L, vm.getSelectedSiteId());

        // Danh sach Artifact thuoc Van Mieu (103 Bia Tien si, 105 Khue Van Cac) duoc mo ra
        List<Artifact> siteArtifacts = vm.selectedSiteArtifacts().getValue();
        assertNotNull(siteArtifacts);
        assertEquals(2, siteArtifacts.size());

        // Render offscreen Tab 2 khi GPS Denied de dam bao banner huong dan & ban do ve khong loi
        paintScreenOffscreen(mainScreen);
    }

    @Test
    void artifactDetail_cachesForOffline_handlesFallbackLanguage_mediaControls_andIsolatedMediaErrors() {
        // 1. Mo chi tiet Hien vat 103 (Bia Tien si - co anh thu 2 broken & video broken de test co lap loi)
        navigator.openArtifactDetail(103L);
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        assertTrue(navigator.currentScreen() instanceof ArtifactDetailScreen);

        ArtifactDetailViewModel detailVm = (ArtifactDetailViewModel) navigator.currentViewModel();
        ArtifactDetailScreen detailScreen = (ArtifactDetailScreen) navigator.currentScreen();

        UiState<Artifact> state = detailVm.artifactState().getValue();
        assertNotNull(state);
        assertTrue(state.isSuccess());
        Artifact a103 = state.getData();
        assertNotNull(a103);

        // Ngay khi tai thanh cong, Artifact 103 da duoc luu vao ArtifactCache
        assertTrue(detailVm.isCachedInArtifactCache());
        assertFalse(detailVm.fromOfflineCache().getValue());

        // Van ban thuyet minh hien thi day du
        ContentTranslation tr103 = detailVm.resolveTranslation(a103);
        assertNotNull(tr103);
        assertTrue(tr103.getBodyText().contains("UNESCO"));

        // Thu vien hinh anh: anh 1 binh thuong, anh 2 co link broken -> hien thi anh du phong (fallback)
        List<Media> images = detailVm.imageMediaList(a103);
        assertEquals(3, images.size());
        assertFalse(detailVm.isImageBroken(images.get(0)));
        detailVm.nextImage(images.size());
        assertEquals(1, detailVm.getCurrentImageIndex());
        assertTrue(detailVm.isImageBroken(images.get(1)), "Second image of 103 has broken URL -> fallback image");

        // Audio player: Play / Pause / Seek hoat dong binh thuong
        assertFalse(detailVm.isAudioBroken(a103));
        detailVm.setAudioPlaying(true);
        assertTrue(detailVm.isAudioPlaying());
        detailVm.seekAudio(45, 160);
        assertEquals(45, detailVm.getAudioPositionSeconds());
        detailVm.setAudioPlaying(false);
        assertFalse(detailVm.isAudioPlaying());

        // Video player: link video cua 103 bi loi -> bao loi rieng cho Video, KHONG lam trang van ban hay Audio
        assertTrue(detailVm.isVideoBroken(a103));
        detailVm.setVideoPlaying(true);
        assertFalse(detailVm.isVideoPlaying(), "Broken video must not enter playing state");
        paintScreenOffscreen(detailScreen);

        // Bam Retry tren Video player -> khoi phuc va Play/Seek duoc
        detailVm.setForceVideoBroken(false);
        assertFalse(detailVm.isVideoBroken(a103));
        detailVm.setVideoPlaying(true);
        detailVm.seekVideo(30, 95);
        assertEquals(30, detailVm.getVideoPositionSeconds());

        // 2. Mat mang / mat song beacon -> van xem duoc Hien vat 103 tu ArtifactCache!
        mockBackend.setSimulateNetworkError(true);
        detailVm.loadArtifact();
        assertTrue(detailVm.artifactState().getValue().isSuccess());
        assertTrue(detailVm.fromOfflineCache().getValue(), "Should load from ArtifactCache when offline");
        mockBackend.setSimulateNetworkError(false);

        // 3. Kiem tra fallback ngon ngu mac dinh khi thieu ban dich:
        // Doi ngon ngu sang English (en), mo Hien vat 105 (Khue Van Cac - chi co ban dich vi)
        container.languageRepository().changeLanguage("en");
        navigator.openArtifactDetail(105L);
        ArtifactDetailViewModel vm105 = (ArtifactDetailViewModel) navigator.currentViewModel();
        Artifact a105 = vm105.artifactState().getValue().getData();
        assertNotNull(a105);
        assertTrue(vm105.isUsingFallbackTranslation(a105),
                "Artifact 105 lacks 'en' translation and must fallback to default 'vi'");
        ContentTranslation fallbackTr = vm105.resolveTranslation(a105);
        assertNotNull(fallbackTr);
        assertEquals("vi", fallbackTr.getLanguageCode());
        paintScreenOffscreen(navigator.currentScreen());

        // Quay lai MainScreen
        navigator.navigateBackToMain();
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());
    }

    private static void paintScreenOffscreen(com.heritage.tv2.ui.base.Screen screen) {
        screen.setSize(AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT);
        screen.doLayout();
        BufferedImage img = new BufferedImage(
                AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        try {
            screen.paintAll(g2);
        } finally {
            g2.dispose();
        }
    }
}
