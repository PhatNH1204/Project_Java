package com.heritage.tv2.api;

import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.cache.SessionStorage;
import com.heritage.tv2.model.AuthTokens;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit Test cho {@link AuthInterceptor}:
 * <ul>
 *     <li>Tu dong dinh kem {@code Authorization: Bearer <token>} va {@code Accept-Language: <lang>}</li>
 *     <li>Khong dinh kem Authorization cho endpoint cong khai (/api/auth/login, /register, /refresh)</li>
 *     <li>Tu dong refresh token va retry khi nhan 401</li>
 *     <li>Xoa session va goi callback dieu huong ve Login khi refresh that bai</li>
 *     <li>Khong xoa session khi refresh gap loi mang (IOException)</li>
 * </ul>
 */
class AuthInterceptorTest {

    private static final String BASE = "http://test.heritage.local";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private SessionStorage session;
    private List<Request> recordedRequests;

    @BeforeEach
    void setUp() {
        session = new SessionStorage(new InMemoryKeyValueStore());
        recordedRequests = new ArrayList<>();
    }

    @Test
    void attachesBearerTokenAndAcceptLanguageOnProtectedEndpoint() throws IOException {
        session.saveTokens(new AuthTokens("token-abc", "refresh-xyz"));
        session.setLanguage("en");

        OkHttpClient client = buildClient(
                rt -> null,
                () -> { },
                chain -> {
                    recordedRequests.add(chain.request());
                    return jsonResponse(chain.request(), 200, "{\"success\":true}");
                });

        try (Response res = client.newCall(new Request.Builder()
                .url(BASE + "/api/users/me")
                .get()
                .build()).execute()) {
            assertEquals(200, res.code());
        }

        assertEquals(1, recordedRequests.size());
        Request sent = recordedRequests.get(0);
        assertEquals("Bearer token-abc", sent.header(AuthInterceptor.HEADER_AUTHORIZATION));
        assertEquals("en", sent.header(AuthInterceptor.HEADER_ACCEPT_LANGUAGE));
    }

    @Test
    void doesNotAttachAuthorizationOnPublicLoginEndpoint_butAttachesAcceptLanguage() throws IOException {
        session.saveTokens(new AuthTokens("old-token", "old-refresh"));
        session.setLanguage("vi");

        OkHttpClient client = buildClient(
                rt -> null,
                () -> { },
                chain -> {
                    recordedRequests.add(chain.request());
                    return jsonResponse(chain.request(), 200, "{\"success\":true}");
                });

        try (Response res = client.newCall(new Request.Builder()
                .url(BASE + "/api/auth/login")
                .post(RequestBody.create("{}", JSON))
                .build()).execute()) {
            assertEquals(200, res.code());
        }

        assertEquals(1, recordedRequests.size());
        Request sent = recordedRequests.get(0);
        assertNull(sent.header(AuthInterceptor.HEADER_AUTHORIZATION));
        assertEquals("vi", sent.header(AuthInterceptor.HEADER_ACCEPT_LANGUAGE));
    }

    @Test
    void on401_automaticallyRefreshesToken_updatesStorage_andRetriesOriginalRequest() throws IOException {
        session.saveTokens(new AuthTokens("expired-token", "valid-refresh"));
        AtomicInteger refreshCalls = new AtomicInteger();
        AtomicBoolean expiredCallbackCalled = new AtomicBoolean(false);

        OkHttpClient client = buildClient(
                refreshToken -> {
                    assertEquals("valid-refresh", refreshToken);
                    refreshCalls.incrementAndGet();
                    return new AuthTokens("fresh-token-999", "rotated-refresh-999");
                },
                () -> expiredCallbackCalled.set(true),
                chain -> {
                    Request req = chain.request();
                    recordedRequests.add(req);
                    String auth = req.header(AuthInterceptor.HEADER_AUTHORIZATION);
                    if ("Bearer fresh-token-999".equals(auth)) {
                        return jsonResponse(req, 200, "{\"success\":true}");
                    }
                    return jsonResponse(req, 401, "{\"success\":false}");
                });

        try (Response res = client.newCall(new Request.Builder()
                .url(BASE + "/api/favorites")
                .get()
                .build()).execute()) {
            assertEquals(200, res.code());
        }

        assertEquals(1, refreshCalls.get());
        assertEquals(2, recordedRequests.size());
        assertEquals("Bearer expired-token", recordedRequests.get(0).header(AuthInterceptor.HEADER_AUTHORIZATION));
        assertEquals("Bearer fresh-token-999", recordedRequests.get(1).header(AuthInterceptor.HEADER_AUTHORIZATION));
        assertEquals("fresh-token-999", session.getAccessToken());
        assertEquals("rotated-refresh-999", session.getRefreshToken());
        assertFalse(expiredCallbackCalled.get());
    }

    @Test
    void on401_whenRefreshRejected_clearsSession_andTriggersSessionExpiredCallback() throws IOException {
        session.saveTokens(new AuthTokens("expired-token", "revoked-refresh"));
        AtomicBoolean expiredCallbackCalled = new AtomicBoolean(false);

        OkHttpClient client = buildClient(
                refreshToken -> null, // refresh token bi tu choi (401)
                () -> expiredCallbackCalled.set(true),
                chain -> {
                    recordedRequests.add(chain.request());
                    return jsonResponse(chain.request(), 401, "{\"success\":false}");
                });

        try (Response res = client.newCall(new Request.Builder()
                .url(BASE + "/api/users/me")
                .get()
                .build()).execute()) {
            assertEquals(401, res.code());
        }

        assertEquals(1, recordedRequests.size());
        assertFalse(session.isLoggedIn());
        assertNull(session.getAccessToken());
        assertNull(session.getRefreshToken());
        assertTrue(expiredCallbackCalled.get());
    }

    @Test
    void on401_whenRefreshThrowsNetworkIOException_keepsSessionIntact() {
        session.saveTokens(new AuthTokens("expired-token", "valid-refresh"));
        AtomicBoolean expiredCallbackCalled = new AtomicBoolean(false);

        OkHttpClient client = buildClient(
                refreshToken -> {
                    throw new IOException("Temporary network outage");
                },
                () -> expiredCallbackCalled.set(true),
                chain -> jsonResponse(chain.request(), 401, "{\"success\":false}"));

        assertThrows(IOException.class, () -> client.newCall(new Request.Builder()
                .url(BASE + "/api/sites")
                .get()
                .build()).execute());

        assertTrue(session.isLoggedIn());
        assertEquals("valid-refresh", session.getRefreshToken());
        assertFalse(expiredCallbackCalled.get());
    }

    private OkHttpClient buildClient(AuthInterceptor.TokenRefresher refresher,
                                     AuthInterceptor.SessionExpiredListener expiredListener,
                                     Interceptor terminalBackend) {
        return new OkHttpClient.Builder()
                .addInterceptor(new AuthInterceptor(session, refresher, expiredListener))
                .addInterceptor(terminalBackend)
                .build();
    }

    private static Response jsonResponse(Request request, int code, String body) {
        return new Response.Builder()
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .code(code)
                .message("HTTP " + code)
                .body(ResponseBody.create(body, JSON))
                .build();
    }
}
