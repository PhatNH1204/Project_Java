package com.heritage.tv2;

import com.heritage.tv2.api.ErrorMapper;
import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.ble.BleErrorCode;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.auth.LoginViewModel;
import com.heritage.tv2.ui.auth.RegisterViewModel;
import com.heritage.tv2.ui.base.UiState;
import com.heritage.tv2.ui.detail.ArtifactDetailViewModel;
import com.heritage.tv2.ui.main.MainViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Bo Test Nghiem thu Tuan 6-7 ({@code QaAcceptanceWeek67Test}) tren nhanh {@code feature/mobile-docs-qa}.
 *
 * <p>Ra soat va phu day du cac nhanh thanh cong va nhanh loi chinh theo 4 nhom:</p>
 * <ol>
 *     <li><b>Auth</b>: dang nhap sai, dang ky trung email, het han token 401 (tu refresh &amp; refresh het han
 *     dieu huong ve Login), dang xuat xoa sach session.</li>
 *     <li><b>Explore &amp; Content</b>: mat mang, du lieu rong, thieu ban dich fallback ngon ngu mac dinh,
 *     loi phat media (anh du phong, audio/video bao loi co lap).</li>
 *     <li><b>Favorite, VisitHistory &amp; Feedback</b>: loi mang hoan tac nut tim (Optimistic UI rollback),
 *     validate rating 1-5 sao &amp; nhan xet, loi mang khi gui feedback giu lai ban nhap.</li>
 *     <li><b>BLE Bridge</b>: beacon moi vao vung, roi vung van giu noi dung tu cache &amp; tiep tuc phat media,
 *     chuyen beacon khac, tu choi quyen Bluetooth/GPS.</li>
 * </ol>
 */
class QaAcceptanceWeek67Test {

    private MockBackendInterceptor mockBackend;
    private AppContainer container;
    private Navigator navigator;

    @BeforeEach
    void setUp() {
        I18n.setLanguage(AppConfig.LANGUAGE_VI);
        mockBackend = new MockBackendInterceptor(0L);
        container = new AppContainer(
                new InMemoryKeyValueStore(),
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mockBackend,
                AppConfig.MOCK_BASE_URL);
        navigator = new Navigator(container, s -> { }, (m, e) -> { }, l -> { });
    }

    // ================================================================== 1. AUTH
    @Test
    void qa1_auth_wrongCredentials_duplicateEmail_401RefreshAndExpiry_andCleanLogout() {
        navigator.navigateTo(Navigator.Route.LOGIN);
        LoginViewModel loginVm = (LoginViewModel) navigator.currentViewModel();

        // 1a. Dang nhap voi email sai dinh dang & mat khau qua ngan (client validation)
        loginVm.login("invalid-email", "123456");
        assertNotNull(loginVm.errorEvent().getValue());
        assertNotNull(loginVm.errorEvent().getValue().peek());
        assertFalse(container.sessionStorage().isLoggedIn());

        loginVm.login(MockBackendInterceptor.DEMO_EMAIL, "123");
        assertNotNull(loginVm.errorEvent().getValue().peek());
        assertFalse(container.sessionStorage().isLoggedIn());

        // 1b. Dang nhap sai mat khau / tai khoan khong ton tai (server 401 AUTH_INVALID_CREDENTIALS)
        Result<User> wrongPass = container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, "wrong-pass");
        assertFalse(wrongPass.isSuccess());
        assertEquals(401, wrongPass.getHttpStatus());
        assertEquals(ErrorMapper.AUTH_INVALID_CREDENTIALS, wrongPass.getErrorCode());
        assertFalse(container.sessionStorage().isLoggedIn());

        Result<User> unknownUser = container.authRepository().login("ghost@heritage.vn", "123456");
        assertFalse(unknownUser.isSuccess());
        assertEquals(401, unknownUser.getHttpStatus());

        // 1c. Dang ky trung email da ton tai (409 AUTH_EMAIL_EXISTS) & lech mat khau xac nhan
        navigator.navigateTo(Navigator.Route.REGISTER);
        RegisterViewModel regVm = (RegisterViewModel) navigator.currentViewModel();
        regVm.register("Test User", MockBackendInterceptor.DEMO_EMAIL, "123456", "999999");
        assertNotNull(regVm.errorEvent().getValue().peek());

        Result<User> dupEmail = container.authRepository()
                .register(MockBackendInterceptor.DEMO_EMAIL, "123456", "Dup User");
        assertFalse(dupEmail.isSuccess());
        assertEquals(409, dupEmail.getHttpStatus());
        assertEquals(ErrorMapper.AUTH_EMAIL_EXISTS, dupEmail.getErrorCode());

        // 1d. Dang nhap thanh cong -> chuyen sang MAIN
        navigator.navigateTo(Navigator.Route.LOGIN);
        loginVm = (LoginViewModel) navigator.currentViewModel();
        loginVm.login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());
        assertTrue(container.sessionStorage().isLoggedIn());
        assertNotNull(container.sessionStorage().getAccessToken());
        assertNotNull(container.sessionStorage().getRefreshToken());
        assertNotNull(container.sessionStorage().getUser());

        // 1e. Het han Access Token (401) -> AuthInterceptor tu dong refresh thanh cong
        mockBackend.expireAllAccessTokens();
        Result<User> profileAfterAutoRefresh = container.userRepository().getProfile();
        assertTrue(profileAfterAutoRefresh.isSuccess());
        assertEquals(1, mockBackend.getRefreshCount());

        // 1f. Ca Access Token va Refresh Token deu khong hop le (401 khi refresh) -> xoa session & ve LOGIN
        container.sessionStorage().saveTokens(
                new com.heritage.tv2.model.AuthTokens("expired-at", "invalid-refresh-token"));
        Result<User> expiredBoth = container.userRepository().getProfile();
        assertFalse(expiredBoth.isSuccess());
        assertFalse(container.sessionStorage().isLoggedIn());
        assertEquals(Navigator.Route.LOGIN, navigator.currentRoute(),
                "Navigator must automatically redirect to LOGIN when 401 refresh fails");

        // 1g. Dang nhap lai roi Dang xuat -> xoa sach token & user, giu lai ngon ngu
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        container.languageRepository().changeLanguage("en");
        assertTrue(container.sessionStorage().isLoggedIn());

        container.authRepository().logout();
        assertFalse(container.sessionStorage().isLoggedIn());
        assertNull(container.sessionStorage().getAccessToken());
        assertNull(container.sessionStorage().getRefreshToken());
        assertNull(container.sessionStorage().getUser());
        assertEquals("en", container.sessionStorage().getLanguage());
    }

    // ==================================================== 2. EXPLORE & CONTENT
    @Test
    void qa2_exploreAndContent_networkOutage_emptySearch_languageFallback_andIsolatedMediaErrors() {
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        navigator.navigateTo(Navigator.Route.MAIN);
        MainViewModel mainVm = (MainViewModel) navigator.currentViewModel();

        // 2a. Mat mang khi tai danh sach HeritageSite -> trang thai ERROR + Retry khoi phuc SUCCESS
        mainVm.simulateSitesNetworkError();
        assertEquals(UiState.Status.ERROR, mainVm.sitesUiState().getValue().getStatus());
        mainVm.retryLoadSites();
        assertEquals(UiState.Status.SUCCESS, mainVm.sitesUiState().getValue().getStatus());
        assertEquals(3, mainVm.sitesUiState().getValue().getData().size());

        // 2b. Du lieu rong (EMPTY) khi tim kiem/loc khong khop
        mainVm.setSearchAndCategory("DiaDiemKhongTonTai999", HeritageSite.CATEGORY_CITADEL);
        assertEquals(UiState.Status.EMPTY, mainVm.sitesUiState().getValue().getStatus());
        mainVm.clearFilters();
        assertEquals(UiState.Status.SUCCESS, mainVm.sitesUiState().getValue().getStatus());

        // 2c. Mat mang khi mo ArtifactDetail CHUA CO trong ArtifactCache -> trang thai ERROR tren ArtifactDetail
        mockBackend.setSimulateNetworkError(true);
        navigator.openArtifactDetail(104L);
        ArtifactDetailViewModel vm104 = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertEquals(UiState.Status.ERROR, vm104.artifactState().getValue().getStatus());
        mockBackend.setSimulateNetworkError(false);

        // Bam Retry (loadArtifact) khi co mang lai -> SUCCESS & luu vao ArtifactCache
        vm104.loadArtifact();
        assertEquals(UiState.Status.SUCCESS, vm104.artifactState().getValue().getStatus());
        assertTrue(vm104.isCachedInArtifactCache());

        // 2d. Thieu ban dich (Artifact 105 chi co ban dich 'vi') khi nguoi dung dang o 'en' -> fallback 'vi'
        container.languageRepository().changeLanguage("en");
        navigator.openArtifactDetail(105L);
        ArtifactDetailViewModel vm105 = (ArtifactDetailViewModel) navigator.currentViewModel();
        Artifact a105 = vm105.artifactState().getValue().getData();
        assertNotNull(a105);
        assertTrue(vm105.isUsingFallbackTranslation(a105));
        ContentTranslation fallback = vm105.resolveTranslation(a105);
        assertNotNull(fallback);
        assertEquals("vi", fallback.getLanguageCode());
        assertTrue(fallback.getBodyText().contains("Khuê Văn Các"));

        // 2e. Loi phat media (anh broken, audio broken, video broken) duoc co lap, khong lam mat van ban
        navigator.openArtifactDetail(103L);
        ArtifactDetailViewModel vm103 = (ArtifactDetailViewModel) navigator.currentViewModel();
        Artifact a103 = vm103.artifactState().getValue().getData();
        assertNotNull(a103);

        // Anh thu 2 cua 103 co link broken -> isImageBroken = true (ve anh du phong)
        List<Media> imgs = vm103.imageMediaList(a103);
        vm103.nextImage(imgs.size());
        assertTrue(vm103.isImageBroken(imgs.get(vm103.getCurrentImageIndex())));

        // Gia lap loi Audio -> Audio dung phat nhung van ban thuyet minh van con nguyen
        vm103.setAudioPlaying(true);
        assertTrue(vm103.isAudioPlaying());
        vm103.setForceAudioBroken(true);
        assertTrue(vm103.isAudioBroken(a103));
        assertFalse(vm103.isAudioPlaying());
        assertNotNull(vm103.resolveTranslation(a103).getBodyText());

        // Video cua 103 mac dinh co link broken -> isVideoBroken = true; sua lai -> phat binh thuong
        assertTrue(vm103.isVideoBroken(a103));
        vm103.setForceVideoBroken(false);
        assertFalse(vm103.isVideoBroken(a103));
    }

    // ================================== 3. FAVORITE, VISITHISTORY & FEEDBACK
    @Test
    void qa3_favoriteRollback_feedbackBoundaryValidation_andNetworkErrorPreservesDraft() {
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        navigator.openArtifactDetail(106L); // Cổng Đoan Môn (chua yeu thich)
        ArtifactDetailViewModel vm = (ArtifactDetailViewModel) navigator.currentViewModel();

        // 3a. Optimistic UI rollback khi loi mang
        List<Boolean> states = new ArrayList<>();
        Runnable unsub = vm.favoriteState().observe(states::add);
        mockBackend.setSimulateNetworkError(true);
        vm.toggleFavorite();
        mockBackend.setSimulateNetworkError(false);
        unsub.run();
        assertEquals(List.of(false, true, false), states);
        assertFalse(vm.favoriteState().getValue());

        // 3b. Validate bien rating (1..5 sao): 0, -1, 6, null deu bi tu choi; 1 va 5 hop le
        int beforeCount = mockBackend.getFeedbacks().size();
        for (Integer invalidRating : new Integer[]{null, -1, 0, 6, 10}) {
            vm.submitFeedback(invalidRating, "Nhan xet hop le");
            assertNotNull(vm.feedbackErrorMessage().getValue(),
                    "Rating " + invalidRating + " must be rejected");
        }
        assertEquals(beforeCount, mockBackend.getFeedbacks().size());

        // Rating 1 sao (bien duoi) + nhan xet hop le -> thanh cong
        vm.submitFeedback(1, "Cần bổ sung thêm bảng chỉ dẫn.");
        assertNull(vm.feedbackErrorMessage().getValue());
        assertNotNull(vm.feedbackSuccessMessage().getValue());
        assertEquals(beforeCount + 1, mockBackend.getFeedbacks().size());

        // Rating 5 sao (bien tren) khi mat mang -> bao loi mang va GIU NGUYEN draftComment de gui lai
        mockBackend.setSimulateNetworkError(true);
        vm.submitFeedback(5, "Kiến trúc cổng thành rất uy nghiêm!");
        mockBackend.setSimulateNetworkError(false);
        assertNotNull(vm.feedbackErrorMessage().getValue());
        assertEquals("Kiến trúc cổng thành rất uy nghiêm!", vm.getDraftComment(),
                "Draft comment must be preserved when network submission fails");

        // Gui lai khi mang phuc hoi -> thanh cong va xoa draftComment
        vm.submitFeedback(5, vm.getDraftComment());
        assertNull(vm.feedbackErrorMessage().getValue());
        assertEquals("", vm.getDraftComment());
        assertEquals(beforeCount + 2, mockBackend.getFeedbacks().size());
    }

    // ========================================================== 4. BLE BRIDGE
    @Test
    void qa4_bleBridge_enter_outOfRangeCacheRetention_switchBeacon_andBluetoothGpsPermissionDenial() {
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        navigator.navigateTo(Navigator.Route.MAIN);
        MainViewModel mainVm = (MainViewModel) navigator.currentViewModel();

        // 4a. Tu choi quyen GPS tren Ban do + Tu choi quyen Bluetooth BLE
        mainVm.setLocationPermissionGranted(false);
        assertFalse(mainVm.isLocationPermissionGranted());
        container.bleBridge().onBleError(BleErrorCode.PERMISSION_DENIED, null);
        assertFalse(container.blePermissionHelper().isBleReady());
        assertNotNull(container.bleBridge().warningBannerMessage().getValue());
        assertTrue(container.blePermissionHelper().canUseAppManually(),
                "Visitor must always be able to use the app manually when BLE/GPS is denied");

        // Khi BLE chua san sang, su kien beacon tu dong bi chan va nhac banner canh bao
        container.bleBridge().onBeaconTriggered(new BeaconSignalEvent(
                "B-101", "UUID", 1, 101, -60, BeaconSignalEvent.EventType.ENTER, System.currentTimeMillis()));
        assertNull(container.bleBridge().pendingBeaconPrompt().getValue());

        // 4b. Cap quyen Bluetooth & GPS -> nhan Beacon B-101 (ENTER) -> Mo ArtifactDetail (101)
        container.bleBridge().resolveBlePermissionsAndEnableBluetooth();
        mainVm.setLocationPermissionGranted(true);
        assertTrue(container.blePermissionHelper().isBleReady());

        container.bleDebugSimulator().triggerEnterBeacon("B-101");
        assertNotNull(container.bleBridge().pendingBeaconPrompt().getValue());
        navigator.acceptCurrentBeaconPrompt();
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        ArtifactDetailViewModel detailVm = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertEquals(101L, detailVm.getArtifactId());
        detailVm.setAudioPlaying(true);
        detailVm.seekAudio(75, 185);

        // 4c. Roi vung phu song B-101 -> van giu nguyen man hinh, du lieu tu ArtifactCache va Audio dang phat
        container.bleDebugSimulator().triggerOutOfRange("B-101");
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        assertTrue(detailVm.fromOfflineCache().getValue());
        assertTrue(detailVm.beaconOutOfRange().getValue());
        assertTrue(detailVm.isAudioPlaying());
        assertEquals(75, detailVm.getAudioPositionSeconds());

        // 4d. Chuyen sang Beacon khac (SWITCH B-102) -> hien goi y B-102 -> bam "Xem ngay" mo Hien vat 102
        container.bleDebugSimulator().triggerScenario3SwitchBeacon();
        assertNotNull(container.bleBridge().pendingBeaconPrompt().getValue());
        assertEquals("B-102", container.bleBridge().pendingBeaconPrompt().getValue().getBeaconId());
        navigator.acceptCurrentBeaconPrompt();

        ArtifactDetailViewModel vm102 = (ArtifactDetailViewModel) navigator.currentViewModel();
        assertEquals(102L, vm102.getArtifactId());

        // Lich su tham quan ghi nhan ca B-101 va B-102 voi nguon BEACON_BLE
        List<VisitHistory> history = container.visitHistoryRepository().getVisitHistory().getData();
        assertTrue(history.stream().anyMatch(h -> h.getArtifactId() == 102L && h.isFromBeacon()));
    }
}
