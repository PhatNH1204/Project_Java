package com.heritage.tv2;

import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.BeaconSignalEvent;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Favorite;
import com.heritage.tv2.model.FeedbackRequest;
import com.heritage.tv2.model.HeritageSite;
import com.heritage.tv2.model.MediaType;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.ui.main.MainScreen;
import com.heritage.tv2.ui.main.MainViewModel;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.I18n;
import com.heritage.tv2.util.Result;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Integration Test kiem tra toan bo luong bat buoc Gate 2:
 * <ul>
 *     <li>{@code AppConfig.USE_MOCK_DATA == true}</li>
 *     <li>Splash -> Login / Register -> Main (4 Tab)</li>
 *     <li>Doi ngon ngu {@code vi} -> {@code en} qua {@code PUT /api/users/me} va {@code Accept-Language}</li>
 *     <li>Tat ca 13 endpoint trong {@code HeritageApiService} va bo Model/DTO</li>
 * </ul>
 */
class FlowIntegrationTest {

    private MockBackendInterceptor mockBackend;
    private AppContainer container;

    @BeforeEach
    void setUp() {
        assertTrue(AppConfig.USE_MOCK_DATA, "AppConfig.USE_MOCK_DATA must be true by default");
        mockBackend = new MockBackendInterceptor(0L);
        container = new AppContainer(
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mockBackend,
                AppConfig.MOCK_BASE_URL);
    }

    @Test
    void fullLoginMainProfileLanguageSwitchAndAllApiEndpointsFlow() {
        // 1. Login voi tai khoan mau (vi)
        Result<User> login = container.authRepository()
                .login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        assertTrue(login.isSuccess());
        assertEquals("vi", container.sessionStorage().getLanguage());
        assertEquals("Nguyễn Văn An", login.getData().getFullName());

        // 2. Sites & Artifact & Beacon content bang tieng Viet (Accept-Language: vi)
        Result<List<HeritageSite>> sitesVi = container.heritageRepository().getSites(true);
        assertTrue(sitesVi.isSuccess());
        assertEquals(3, sitesVi.getData().size());
        assertEquals("Hoàng thành Thăng Long", sitesVi.getData().get(0).getName());

        Result<Artifact> artifactVi = container.heritageRepository().getArtifact(101L);
        assertTrue(artifactVi.isSuccess());
        assertEquals("Trống đồng Ngọc Lũ", artifactVi.getData().getName());
        assertNotNull(artifactVi.getData().getContent());
        ContentTranslation trVi = artifactVi.getData().getContent().findTranslation("vi", "en");
        assertNotNull(trVi);
        assertFalse(artifactVi.getData().getContent().mediaOfType(MediaType.AUDIO).isEmpty());

        Result<Artifact> beaconContent = container.heritageRepository().getBeaconContent("B-102");
        assertTrue(beaconContent.isSuccess());
        assertEquals(102L, beaconContent.getData().getId());

        // 3. Favorites (GET, POST, DELETE), VisitHistory (GET read-only), Feedback (POST)
        Result<List<Favorite>> initialFavs = container.favoriteRepository().getFavorites();
        assertTrue(initialFavs.isSuccess());
        assertEquals(2, initialFavs.getData().size());

        Result<Favorite> addedFav = container.favoriteRepository().addFavorite(104L);
        assertTrue(addedFav.isSuccess());
        assertEquals(3, container.favoriteRepository().getFavorites().getData().size());

        Result<Void> removedFav = container.favoriteRepository().removeFavorite(104L);
        assertTrue(removedFav.isSuccess());
        assertEquals(2, container.favoriteRepository().getFavorites().getData().size());

        Result<List<VisitHistory>> historyVi = container.visitHistoryRepository().getVisitHistory();
        assertTrue(historyVi.isSuccess());
        assertEquals(3, historyVi.getData().size());
        assertEquals("Rồng đá điện Kính Thiên", historyVi.getData().get(0).getArtifactName());

        Result<Void> fb = container.feedbackRepository().submit(new FeedbackRequest(101L, 5, "Excellent!"));
        assertTrue(fb.isSuccess());
        assertEquals(1, mockBackend.getFeedbacks().size());

        // 4. Cap nhat ho so & Doi ngon ngu sang English (en) qua PUT /api/users/me
        Result<User> updatedProfile = container.userRepository().updateProfile("Nguyen Van An (VIP)", "0988777666");
        assertTrue(updatedProfile.isSuccess());
        assertEquals("Nguyen Van An (VIP)", updatedProfile.getData().getFullName());

        Result<User> switchedLang = container.languageRepository().changeLanguage("en");
        assertTrue(switchedLang.isSuccess());
        assertEquals("en", switchedLang.getData().getPreferredLanguage());
        assertEquals("en", container.sessionStorage().getLanguage());

        // 5. Goi lai API sau khi doi ngon ngu -> Accept-Language: en tra ve du lieu tieng Anh
        Result<List<HeritageSite>> sitesEn = container.heritageRepository().getSites(true);
        assertTrue(sitesEn.isSuccess());
        assertEquals("Imperial Citadel of Thang Long", sitesEn.getData().get(0).getName());

        Result<List<VisitHistory>> historyEn = container.visitHistoryRepository().getVisitHistory();
        assertTrue(historyEn.isSuccess());
        assertEquals("Stone Dragons of Kinh Thien Palace", historyEn.getData().get(0).getArtifactName());

        // 6. Het han Access Token -> AuthInterceptor tu dong refresh va retry
        mockBackend.expireAllAccessTokens();
        Result<User> meAfterRefresh = container.userRepository().getProfile();
        assertTrue(meAfterRefresh.isSuccess());
        assertEquals(1, mockBackend.getRefreshCount());

        // 7. Logout
        Result<Void> logout = container.authRepository().logout();
        assertTrue(logout.isSuccess());
        assertFalse(container.sessionStorage().isLoggedIn());
    }

    @Test
    void navigatorAndMainViewModel_headlessUiFlow() {
        AtomicReference<String> lastToast = new AtomicReference<>();
        AtomicReference<String> badgeLang = new AtomicReference<>();
        Navigator navigator = new Navigator(
                container,
                screen -> { },
                (msg, err) -> lastToast.set(msg),
                badgeLang::set);

        // Chua dang nhap: LOGIN
        navigator.navigateTo(Navigator.Route.LOGIN);
        assertEquals(Navigator.Route.LOGIN, navigator.currentRoute());

        // Chuyen sang REGISTER va dang ky tai khoan moi
        navigator.navigateTo(Navigator.Route.REGISTER);
        assertEquals(Navigator.Route.REGISTER, navigator.currentRoute());
        Result<User> reg = container.authRepository().register("newuser@heritage.vn", "123456", "Le Thi Binh");
        assertTrue(reg.isSuccess());

        // Chuyen sang MAIN (4 Tabs)
        navigator.navigateTo(Navigator.Route.MAIN);
        assertEquals(Navigator.Route.MAIN, navigator.currentRoute());
        assertTrue(navigator.currentScreen() instanceof MainScreen);
        MainScreen mainScreen = (MainScreen) navigator.currentScreen();
        MainViewModel mainVm = (MainViewModel) navigator.currentViewModel();

        // Chuyen qua 4 Tab: Explore (0) -> Map (1) -> Fav & History (2) -> Profile & Language (3)
        mainScreen.switchTab(MainViewModel.TAB_MAP);
        assertEquals(MainViewModel.TAB_MAP, mainVm.getActiveTab());
        mainScreen.switchTab(MainViewModel.TAB_FAV_HISTORY);
        assertEquals(MainViewModel.TAB_FAV_HISTORY, mainVm.getActiveTab());
        mainScreen.switchTab(MainViewModel.TAB_PROFILE);
        assertEquals(MainViewModel.TAB_PROFILE, mainVm.getActiveTab());

        // Gia lap tin hieu BLE Beacon (TV3)
        mainVm.simulateBeaconSignal();
        BeaconSignalEvent ble = mainVm.lastBeaconEvent().getValue();
        assertNotNull(ble);
        assertEquals(BeaconSignalEvent.EventType.ENTER, ble.getEventType());

        // Doi ngon ngu tren Tab Ho so & Ngon ngu -> Navigator rebuild screen nhung van giu TAB_PROFILE
        String viTitle = I18n.tr("tab.profile");
        mainVm.changeLanguage("en");
        assertEquals("en", badgeLang.get());
        assertEquals("en", I18n.getLanguage());
        assertNotEquals(viTitle, I18n.tr("tab.profile"));
        assertEquals(MainViewModel.TAB_PROFILE, mainVm.getActiveTab());

        // Dang xuat -> quay ve LOGIN
        mainVm.logout();
        assertEquals(Navigator.Route.LOGIN, navigator.currentRoute());
    }

    @Test
    void screensAndMapCanvas_renderToOffscreenImageWithoutError() {
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        Navigator navigator = new Navigator(container, s -> { }, (m, e) -> { }, l -> { });

        for (Navigator.Route route : Navigator.Route.values()) {
            navigator.navigateTo(route);
            var screen = navigator.currentScreen();
            assertNotNull(screen);
            screen.setSize(AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT);
            screen.doLayout();

            java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(
                    AppConfig.PHONE_WIDTH, AppConfig.PHONE_HEIGHT, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            java.awt.Graphics2D g2 = img.createGraphics();
            try {
                screen.paintAll(g2);
                if (screen instanceof MainScreen) {
                    MainScreen ms = (MainScreen) screen;
                    for (int tab = 0; tab < 4; tab++) {
                        ms.switchTab(tab);
                        ms.doLayout();
                        ms.paintAll(g2);
                    }
                }
            } finally {
                g2.dispose();
            }
        }
    }
}
