package com.heritage.tv2.cache;

import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.Role;
import com.heritage.tv2.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit Test cho {@link SessionStorage} va {@link FileKeyValueStore}.
 */
class SessionStorageTest {

    private InMemoryKeyValueStore memoryStore;
    private SessionStorage storage;

    @BeforeEach
    void setUp() {
        memoryStore = new InMemoryKeyValueStore();
        storage = new SessionStorage(memoryStore);
    }

    @Test
    void saveAndLoadTokens_roundTrip() {
        assertFalse(storage.isLoggedIn());
        assertNull(storage.getAccessToken());
        assertNull(storage.getRefreshToken());

        AuthTokens tokens = new AuthTokens("access-123", "refresh-456", 300L);
        storage.saveTokens(tokens);

        assertTrue(storage.isLoggedIn());
        assertEquals("access-123", storage.getAccessToken());
        assertEquals("refresh-456", storage.getRefreshToken());
        assertNotNull(storage.getTokens());
        assertEquals("Bearer", storage.getTokens().getTokenType());
    }

    @Test
    void saveTokens_preservesExistingRefreshTokenWhenNewRefreshIsBlank() {
        storage.saveTokens(new AuthTokens("access-1", "refresh-keep"));
        storage.saveTokens(new AuthTokens("access-2", null));

        assertEquals("access-2", storage.getAccessToken());
        assertEquals("refresh-keep", storage.getRefreshToken());
    }

    @Test
    void saveTokens_rejectsBlankAccessToken() {
        assertThrows(IllegalArgumentException.class, () -> storage.saveTokens(new AuthTokens("", "rt")));
        assertThrows(IllegalArgumentException.class, () -> storage.saveTokens(null));
    }

    @Test
    void saveAndLoadUser_roundTrip() {
        User user = new User(10L, "visitor@heritage.vn", "Nguyen Van An",
                new Role(3L, Role.VISITOR, "Visitor"), "vi");
        user.setPhone("0901234567");

        storage.saveUser(user);
        User loaded = storage.getUser();

        assertNotNull(loaded);
        assertEquals(user.getId(), loaded.getId());
        assertEquals(user.getEmail(), loaded.getEmail());
        assertEquals(user.getFullName(), loaded.getFullName());
        assertEquals("0901234567", loaded.getPhone());
        assertEquals("vi", loaded.getPreferredLanguage());
    }

    @Test
    void language_defaultsToVi_andNotifiesListenersOnChange() {
        assertEquals(AppConfig.DEFAULT_LANGUAGE, storage.getLanguage());

        AtomicReference<String> notified = new AtomicReference<>();
        storage.addLanguageListener(notified::set);

        storage.setLanguage("EN");
        assertEquals("en", storage.getLanguage());
        assertEquals("en", notified.get());

        assertThrows(IllegalArgumentException.class, () -> storage.setLanguage("fr"));
    }

    @Test
    void clearSession_removesTokensAndUser_butPreservesLanguage() {
        storage.saveTokens(new AuthTokens("at", "rt"));
        storage.saveUser(new User(1L, "a@b.c", "Name", new Role(3L, "VISITOR", ""), "en"));
        storage.setLanguage("en");

        storage.clearSession();

        assertFalse(storage.isLoggedIn());
        assertNull(storage.getAccessToken());
        assertNull(storage.getRefreshToken());
        assertNull(storage.getUser());
        assertEquals("en", storage.getLanguage());
    }

    @Test
    void fileKeyValueStore_persistsAcrossInstances(@TempDir Path tempDir) {
        Path file = tempDir.resolve("session.properties");

        SessionStorage first = new SessionStorage(new FileKeyValueStore(file));
        first.saveTokens(new AuthTokens("persisted-at", "persisted-rt"));
        first.setLanguage("en");

        SessionStorage second = new SessionStorage(new FileKeyValueStore(file));
        assertEquals("persisted-at", second.getAccessToken());
        assertEquals("persisted-rt", second.getRefreshToken());
        assertEquals("en", second.getLanguage());
    }
}
