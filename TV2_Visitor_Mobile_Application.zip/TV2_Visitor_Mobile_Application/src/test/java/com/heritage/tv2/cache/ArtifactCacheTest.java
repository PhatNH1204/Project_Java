package com.heritage.tv2.cache;

import com.heritage.tv2.api.mock.MockDataSource;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.Content;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.MediaType;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit Test cho {@link ArtifactCache} (Gate 3 - Phan 1).
 */
class ArtifactCacheTest {

    private ArtifactCache cache;

    @BeforeEach
    void setUp() {
        cache = new ArtifactCache(new InMemoryKeyValueStore());
    }

    @Test
    void saveAndGet_storesDeepCopyOfArtifactContentTranslationsAndMedia() {
        Artifact artifact = sampleArtifactWithViAndEn(101L);
        assertFalse(cache.contains(101L));

        cache.save(artifact);
        assertTrue(cache.contains(101L));

        Artifact loaded = cache.get(101L);
        assertNotNull(loaded);
        assertEquals(101L, loaded.getId());
        assertNotNull(loaded.getContent());
        assertEquals(2, loaded.getContent().getTranslations().size());
        assertEquals(3, loaded.getContent().getMedia().size());
        assertEquals(1, loaded.getContent().mediaOfType(MediaType.IMAGE).size());
        assertEquals(1, loaded.getContent().mediaOfType(MediaType.AUDIO).size());
        assertEquals(1, loaded.getContent().mediaOfType(MediaType.VIDEO).size());
    }

    @Test
    void getLocalized_returnsMatchingLanguageOrFallsBackToDefaultLanguage() {
        // Artifact 101 co ca vi va en
        cache.save(sampleArtifactWithViAndEn(101L));

        Artifact enCopy = cache.getLocalized(101L, "en", AppConfig.DEFAULT_LANGUAGE);
        assertEquals("Ngoc Lu Bronze Drum", enCopy.getName());

        Artifact viCopy = cache.getLocalized(101L, "vi", AppConfig.DEFAULT_LANGUAGE);
        assertEquals("Trống đồng Ngọc Lũ", viCopy.getName());

        // Artifact 105 chi co ban dich vi -> khi yeu cau en se fallback sang vi
        Artifact viOnly = new Artifact(105L, 2L, "AR-105", "Khuê Văn Các", "Biểu tượng Hà Nội", "1805");
        viOnly.setContent(new Content(1050L, 105L,
                List.of(new ContentTranslation(1L, "vi", "Khuê Văn Các", "Thuyết minh tiếng Việt")),
                List.of(new Media(1L, MediaType.IMAGE, "https://cdn/105.jpg", null, null))));
        cache.save(viOnly);

        Artifact fallbackCopy = cache.getLocalized(105L, "en", "vi");
        assertNotNull(fallbackCopy);
        assertEquals("Khuê Văn Các", fallbackCopy.getName());
        ContentTranslation resolved = fallbackCopy.getContent().findTranslation("en", "vi");
        assertNotNull(resolved);
        assertEquals("vi", resolved.getLanguageCode());
    }

    @Test
    void persistsToDiskViaFileKeyValueStore(@TempDir Path tempDir) {
        Path file = tempDir.resolve("artifact-cache.properties");

        ArtifactCache writer = new ArtifactCache(new FileKeyValueStore(file));
        writer.save(sampleArtifactWithViAndEn(101L));

        ArtifactCache reader = new ArtifactCache(new FileKeyValueStore(file));
        Artifact restored = reader.getLocalized(101L, "en", "vi");
        assertNotNull(restored);
        assertEquals("Ngoc Lu Bronze Drum", restored.getName());
        assertEquals(3, restored.getContent().getMedia().size());

        reader.remove(101L);
        assertNull(reader.get(101L));
    }

    private static Artifact sampleArtifactWithViAndEn(long id) {
        Artifact a = new Artifact(id, 3L, "AR-" + id, "Trống đồng Ngọc Lũ", "Bảo vật Đông Sơn", "Đông Sơn");
        Content content = new Content(id * 10, id,
                List.of(
                        new ContentTranslation(1L, "vi", "Trống đồng Ngọc Lũ", "Nội dung tiếng Việt"),
                        new ContentTranslation(2L, "en", "Ngoc Lu Bronze Drum", "English narrative body")
                ),
                List.of(
                        new Media(10L, MediaType.IMAGE, "https://cdn.heritage.local/101/photo.jpg", null, null),
                        new Media(11L, MediaType.AUDIO, "https://cdn.heritage.local/101/audio-vi.mp3", 185, "vi"),
                        new Media(12L, MediaType.VIDEO, "https://cdn.heritage.local/101/video.mp4", 95, null)
                ));
        a.setContent(content);
        return a;
    }
}
