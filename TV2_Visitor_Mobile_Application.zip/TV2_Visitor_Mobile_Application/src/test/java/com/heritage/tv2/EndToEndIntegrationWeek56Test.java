package com.heritage.tv2;

import com.google.gson.reflect.TypeToken;
import com.heritage.tv2.api.ErrorMapper;
import com.heritage.tv2.api.mock.MockBackendInterceptor;
import com.heritage.tv2.ble.Tv3BleAdapter;
import com.heritage.tv2.cache.InMemoryKeyValueStore;
import com.heritage.tv2.config.AppConfig;
import com.heritage.tv2.config.AppContainer;
import com.heritage.tv2.model.ApiResponse;
import com.heritage.tv2.model.Artifact;
import com.heritage.tv2.model.AuthTokens;
import com.heritage.tv2.model.ContentTranslation;
import com.heritage.tv2.model.Feedback;
import com.heritage.tv2.model.Media;
import com.heritage.tv2.model.MediaType;
import com.heritage.tv2.model.User;
import com.heritage.tv2.model.VisitHistory;
import com.heritage.tv2.ui.Navigator;
import com.heritage.tv2.util.AppExecutors;
import com.heritage.tv2.util.JsonProvider;
import com.heritage.tv2.util.Result;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit &amp; Integration Test cho Tuan 5-6 (Tich hop dau cuoi voi TV1, TV3, TV4, TV5, TV6):
 * <ol>
 *     <li>Kiem tra {@code @SerializedName} va {@code alternate} tren toan bo DTO voi JSON Swagger that
 *     (ca camelCase va snake_case cua TV1, TV3, TV4, TV5).</li>
 *     <li>Kiem tra {@link ErrorMapper} chuan hoa ma loi &amp; HTTP status code.</li>
 *     <li>Kiem tra {@link Tv3BleAdapter} chong vong lap mo man hinh va chong ghi trung {@code Interaction}.</li>
 *     <li>Kiem tra chuyen doi cau hinh giua {@code mock} va {@code dev-backend} (Docker/server TV6).</li>
 * </ol>
 */
class EndToEndIntegrationWeek56Test {

    @Test
    void serializedName_deserializesRealSwaggerJsonPayloads_camelCaseAndSnakeCaseVariants() {
        // 1. TV1 AuthTokens & User (snake_case tu backend)
        String authJson = """
                {
                  "is_success": true,
                  "msg": "Login OK",
                  "payload": {
                    "access_token": "jwt-access-999",
                    "refresh_token": "jwt-refresh-888",
                    "token_type": "Bearer",
                    "expires_in": 3600
                  },
                  "server_time": "2026-11-19T15:00:00Z"
                }
                """;
        Type authType = new TypeToken<ApiResponse<AuthTokens>>() { }.getType();
        ApiResponse<AuthTokens> authRes = JsonProvider.gson().fromJson(authJson, authType);
        assertTrue(authRes.isSuccess());
        assertEquals("jwt-access-999", authRes.getData().getAccessToken());
        assertEquals("jwt-refresh-888", authRes.getData().getRefreshToken());
        assertEquals(3600L, authRes.getData().getExpiresIn());

        String userJson = """
                {
                  "user_id": 42,
                  "username": "visitor@heritage.vn",
                  "full_name": "Tran Thi Mai",
                  "phone_number": "0912345678",
                  "preferred_language": "en",
                  "user_role": { "role_id": 3, "role_name": "VISITOR" }
                }
                """;
        User user = JsonProvider.gson().fromJson(userJson, User.class);
        assertEquals(42L, user.getId());
        assertEquals("visitor@heritage.vn", user.getEmail());
        assertEquals("Tran Thi Mai", user.getFullName());
        assertEquals("0912345678", user.getPhone());
        assertEquals("en", user.getPreferredLanguage());
        assertTrue(user.getRole().isVisitor());

        // 2. TV4 Artifact + Content + ContentTranslation + Media (snake_case / alternate names)
        String artifactJson = """
                {
                  "artifact_id": 101,
                  "heritage_site_id": 3,
                  "artifact_code": "AR-101",
                  "artifact_name": "Ngoc Lu Bronze Drum",
                  "short_description": "Dong Son national treasure",
                  "historical_period": "2500 years ago",
                  "artifact_content": {
                    "content_id": 1010,
                    "artifact_id": 101,
                    "content_translations": [
                      {
                        "translation_id": 1,
                        "language_code": "vi",
                        "heading": "Trống đồng Ngọc Lũ",
                        "body_text": "Thuyết minh tiếng Việt"
                      },
                      {
                        "translation_id": 2,
                        "lang_code": "en",
                        "title": "Ngoc Lu Bronze Drum",
                        "content_text": "English narrative body"
                      }
                    ],
                    "media_assets": [
                      {
                        "media_id": 501,
                        "media_type": "AUDIO",
                        "file_url": "https://cdn.heritage.vn/audio-en.mp3",
                        "duration_seconds": 172,
                        "language_code": "en"
                      }
                    ]
                  }
                }
                """;
        Artifact artifact = JsonProvider.gson().fromJson(artifactJson, Artifact.class);
        assertEquals(101L, artifact.getId());
        assertEquals(3L, artifact.getSiteId());
        assertNotNull(artifact.getContent());
        ContentTranslation enTr = artifact.getContent().findTranslation("en", "vi");
        assertNotNull(enTr);
        assertEquals("English narrative body", enTr.getBodyText());
        List<Media> audios = artifact.getContent().mediaOfType(MediaType.AUDIO);
        assertEquals(1, audios.size());
        assertEquals("https://cdn.heritage.vn/audio-en.mp3", audios.get(0).getUrl());
        assertEquals(172, audios.get(0).getDuration());

        // 3. TV3/TV5 VisitHistory (mapped from Interaction fields: interaction_time, dwell_time_seconds, trigger_source)
        String historyJson = """
                {
                  "interaction_id": 7001,
                  "visitor_id": 42,
                  "heritage_site_id": 1,
                  "artifact_id": 102,
                  "artifact_title": "Stone Dragons",
                  "heritage_site_name": "Thang Long Citadel",
                  "interaction_time": "2026-11-19T14:20:00Z",
                  "dwell_time_seconds": 110,
                  "trigger_source": "BEACON_BLE"
                }
                """;
        VisitHistory vh = JsonProvider.gson().fromJson(historyJson, VisitHistory.class);
        assertEquals(7001L, vh.getId());
        assertEquals(102L, vh.getArtifactId());
        assertEquals("Stone Dragons", vh.getArtifactName());
        assertEquals(110, vh.getDurationSeconds());
        assertTrue(vh.isFromBeacon());

        // 4. TV5 Feedback entity & ApiResponse Error
        String feedbackJson = """
                {
                  "feedback_id": 301,
                  "visitor_id": 42,
                  "artifact_id": 101,
                  "stars": 5,
                  "review_text": "Wonderful audio guide!",
                  "submitted_at": "2026-11-19T14:25:00Z"
                }
                """;
        Feedback fb = JsonProvider.gson().fromJson(feedbackJson, Feedback.class);
        assertEquals(301L, fb.getId());
        assertEquals(5, fb.getRating());
        assertEquals("Wonderful audio guide!", fb.getComment());

        String errJson = """
                {
                  "success": false,
                  "api_error": {
                    "status_code": 422,
                    "error_code": "FEEDBACK_INVALID_RATING",
                    "error_message": "Rating must be 1..5",
                    "field_errors": [
                      { "field_name": "rating", "defaultMessage": "must be between 1 and 5" }
                    ]
                  }
                }
                """;
        ApiResponse<?> errRes = JsonProvider.gson().fromJson(errJson, ApiResponse.class);
        assertFalse(errRes.isSuccess());
        assertEquals(422, errRes.getError().getStatus());
        assertEquals("FEEDBACK_INVALID_RATING", errRes.getError().getCode());
        assertEquals(1, errRes.getError().getDetails().size());
    }

    @Test
    void errorMapper_normalizesBackendErrorCodesAndHttpStatuses() {
        assertEquals(ErrorMapper.AUTH_INVALID_CREDENTIALS,
                ErrorMapper.normalizeCode("BAD_CREDENTIALS", 401));
        assertEquals(ErrorMapper.AUTH_TOKEN_EXPIRED,
                ErrorMapper.normalizeCode("JWT_EXPIRED", 401));
        assertEquals(ErrorMapper.AUTH_EMAIL_EXISTS,
                ErrorMapper.normalizeCode("DUPLICATE_EMAIL", 409));
        assertEquals(ErrorMapper.NOT_FOUND,
                ErrorMapper.normalizeCode("ARTIFACT_NOT_FOUND", 404));
        assertEquals(ErrorMapper.VALIDATION_ERROR,
                ErrorMapper.normalizeCode("FEEDBACK_INVALID_RATING", 422));
        assertEquals(ErrorMapper.SERVER_ERROR,
                ErrorMapper.normalizeCode(null, 503));

        ApiResponse<Void> failBody = ApiResponse.fail(404, "BEACON_NOT_FOUND", null, "/api/beacons/B-999/content");
        Result<Void> mapped = ErrorMapper.mapHttpError(failBody, 404);
        assertFalse(mapped.isSuccess());
        assertEquals(ErrorMapper.NOT_FOUND, mapped.getErrorCode());
        assertNotNull(mapped.getErrorMessage());

        String timeoutMsg = ErrorMapper.describeNetworkException(new SocketTimeoutException("Read timed out"), "vi");
        assertTrue(timeoutMsg.contains("thời gian chờ"));
    }

    @Test
    void tv3BleAdapter_preventsScreenOpeningLoops_andPreventsDuplicateInteractionRecords() {
        MockBackendInterceptor mock = new MockBackendInterceptor(0L);
        AppContainer container = new AppContainer(
                new InMemoryKeyValueStore(),
                new InMemoryKeyValueStore(),
                AppExecutors.direct(),
                mock,
                AppConfig.MOCK_BASE_URL);
        container.authRepository().login(MockBackendInterceptor.DEMO_EMAIL, MockBackendInterceptor.DEMO_PASSWORD);
        Navigator navigator = new Navigator(container, s -> { }, (m, e) -> { }, l -> { });
        navigator.navigateTo(Navigator.Route.MAIN);

        Tv3BleAdapter adapter = container.tv3BleAdapter();
        List<String> tv3SinkRecords = new ArrayList<>();
        adapter.setTv3InteractionSink(new Tv3BleAdapter.Tv3InteractionSink() {
            @Override
            public void recordInteractionStart(String beaconId, long artifactId, long openedAtEpochMs) {
                tv3SinkRecords.add("START:" + beaconId + ":" + artifactId);
            }

            @Override
            public void recordInteractionEnd(String beaconId, long artifactId, long openedAtEpochMs, int durationSeconds) {
                tv3SinkRecords.add("END:" + beaconId + ":" + artifactId + ":" + durationSeconds);
            }
        });

        // 1. Module TV3 phat su kien ENTER B-101 lan dau -> duoc chuyen tiep, hien Banner goi y
        adapter.onTv3BeaconDetected("B-101", "UUID", 1, 101, -59, "ENTER", System.currentTimeMillis());
        assertNotNull(container.bleBridge().pendingBeaconPrompt().getValue());

        // Khi Banner goi y B-101 dang hien thi, TV3 phat tiep su kien B-101 -> bi chan (khong phat lap)
        adapter.onTv3BeaconDetected("B-101", "UUID", 1, 101, -57, "ENTER", System.currentTimeMillis());
        assertEquals(1, adapter.getSuppressedLoopTriggerCount());

        // 2. Khach bam "Xem ngay" -> mo ArtifactDetailScreen cho B-101 (Artifact 101)
        navigator.acceptCurrentBeaconPrompt();
        assertEquals(Navigator.Route.ARTIFACT_DETAIL, navigator.currentRoute());
        assertEquals("B-101", adapter.getCurrentlyViewingBeaconId());
        assertEquals(List.of("START:B-101:101"), tv3SinkRecords);

        // 3. Trong luc khach DANG XEM ArtifactDetail cua B-101, TV3 lien tuc ban them 3 su kien B-101:
        // Tv3BleAdapter PHAI CHAN TAT CA de khong xay ra vong lap mo lai man hinh!
        for (int i = 0; i < 3; i++) {
            adapter.onTv3BeaconDetected("B-101", "UUID", 1, 101, -55, "SWITCH", System.currentTimeMillis());
        }
        assertNull(container.bleBridge().pendingBeaconPrompt().getValue(),
                "Must not re-show prompt for the beacon already open on screen");
        assertEquals(4, adapter.getSuppressedLoopTriggerCount());

        // 4. Kiem tra chong ghi trung Interaction: goi lap onContentOpened cho cung phien B-101:101
        adapter.onContentOpened("B-101", 101L, System.currentTimeMillis());
        assertEquals(1, adapter.getSuppressedDuplicateInteractionCount());
        assertEquals(1, tv3SinkRecords.size(), "Must not record duplicate START interaction");

        // 5. Khach dong man hinh ArtifactDetail -> ghi nhan END interaction dung 1 lan
        navigator.navigateBackToMain();
        assertNull(adapter.getCurrentlyViewingBeaconId());
        assertEquals(2, tv3SinkRecords.size());
        assertTrue(tv3SinkRecords.get(1).startsWith("END:B-101:101:"));
    }

    @Test
    void environmentConfig_switchesBetweenMockAndDevBackendViaEnvOrProperties() {
        Properties fileProps = new Properties();
        fileProps.setProperty("tv2.env", "mock");
        fileProps.setProperty("tv2.baseUrl", "http://localhost:8080/");

        // 1. Mac dinh tu file config -> MOCK
        assertEquals(AppConfig.Environment.MOCK,
                AppConfig.resolveEnvironment(fileProps, Map.of(), new Properties()));
        assertEquals(AppConfig.MOCK_BASE_URL,
                AppConfig.effectiveBaseUrl(AppConfig.Environment.MOCK, "http://localhost:8080/"));

        // 2. Bien moi truong TV2_ENV=dev-backend va TV2_BACKEND_URL=http://192.168.1.20:8080 (khong co dau '/' cuoi)
        Map<String, String> dockerEnv = Map.of(
                "TV2_ENV", "dev-backend",
                "TV2_BACKEND_URL", "http://192.168.1.20:8080");
        AppConfig.Environment resolvedEnv = AppConfig.resolveEnvironment(fileProps, dockerEnv, new Properties());
        String resolvedUrl = AppConfig.resolveBaseUrl(fileProps, dockerEnv, new Properties());
        assertEquals(AppConfig.Environment.DEV_BACKEND, resolvedEnv);
        assertEquals("http://192.168.1.20:8080/", resolvedUrl, "Must auto-append trailing slash for Retrofit");
        assertEquals("http://192.168.1.20:8080/", AppConfig.effectiveBaseUrl(resolvedEnv, resolvedUrl));

        // 3. System property -Dtv2.env=mock ghi de bien moi truong
        Properties sysProps = new Properties();
        sysProps.setProperty("tv2.env", "mock");
        assertEquals(AppConfig.Environment.MOCK,
                AppConfig.resolveEnvironment(fileProps, dockerEnv, sysProps));
    }
}
