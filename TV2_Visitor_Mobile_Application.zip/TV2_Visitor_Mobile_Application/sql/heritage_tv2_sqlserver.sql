-- =============================================================================
-- HERITAGE GUIDE - PHAN HE TV2 (VISITOR MOBILE APPLICATION)
-- Script SQL Server (T-SQL): Khoi tao Database, 13 Bang Entity & Du lieu mau
-- Chay trong SSMS (SQL Server Management Studio) hoac: sqlcmd -S localhost -E -i sql\heritage_tv2_sqlserver.sql
-- =============================================================================

IF DB_ID(N'HeritageTV2DB') IS NULL
BEGIN
    CREATE DATABASE HeritageTV2DB;
END
GO

USE HeritageTV2DB;
GO

-- Xoa bang cu theo thu tu khoa ngoai (neu chay lai)
IF OBJECT_ID(N'dbo.artifact_cache_local', N'U') IS NOT NULL DROP TABLE dbo.artifact_cache_local;
IF OBJECT_ID(N'dbo.beacon_signal_events', N'U') IS NOT NULL DROP TABLE dbo.beacon_signal_events;
IF OBJECT_ID(N'dbo.feedbacks', N'U') IS NOT NULL DROP TABLE dbo.feedbacks;
IF OBJECT_ID(N'dbo.visit_history', N'U') IS NOT NULL DROP TABLE dbo.visit_history;
IF OBJECT_ID(N'dbo.favorites', N'U') IS NOT NULL DROP TABLE dbo.favorites;
IF OBJECT_ID(N'dbo.media', N'U') IS NOT NULL DROP TABLE dbo.media;
IF OBJECT_ID(N'dbo.content_translations', N'U') IS NOT NULL DROP TABLE dbo.content_translations;
IF OBJECT_ID(N'dbo.contents', N'U') IS NOT NULL DROP TABLE dbo.contents;
IF OBJECT_ID(N'dbo.artifacts', N'U') IS NOT NULL DROP TABLE dbo.artifacts;
IF OBJECT_ID(N'dbo.heritage_sites', N'U') IS NOT NULL DROP TABLE dbo.heritage_sites;
IF OBJECT_ID(N'dbo.auth_tokens', N'U') IS NOT NULL DROP TABLE dbo.auth_tokens;
IF OBJECT_ID(N'dbo.users', N'U') IS NOT NULL DROP TABLE dbo.users;
IF OBJECT_ID(N'dbo.languages', N'U') IS NOT NULL DROP TABLE dbo.languages;
IF OBJECT_ID(N'dbo.roles', N'U') IS NOT NULL DROP TABLE dbo.roles;
GO

-- ============================================================================
-- 1. NHOM BANG TV1: Role, Language, User, AuthTokens
-- ============================================================================
CREATE TABLE dbo.roles (
    id          BIGINT PRIMARY KEY,
    name        NVARCHAR(50)  NOT NULL UNIQUE,
    description NVARCHAR(255) NULL
);

CREATE TABLE dbo.languages (
    id         BIGINT PRIMARY KEY,
    code       NVARCHAR(10)  NOT NULL UNIQUE,
    name       NVARCHAR(100) NOT NULL,
    active     BIT           NOT NULL DEFAULT 1,
    is_default BIT           NOT NULL DEFAULT 0
);

CREATE TABLE dbo.users (
    id                 BIGINT PRIMARY KEY,
    email              NVARCHAR(150) NOT NULL UNIQUE,
    password_hash      NVARCHAR(255) NOT NULL,
    full_name          NVARCHAR(150) NOT NULL,
    phone              NVARCHAR(30)  NULL,
    avatar_url         NVARCHAR(500) NULL,
    role_id            BIGINT        NOT NULL REFERENCES dbo.roles(id),
    preferred_language NVARCHAR(10)  NOT NULL REFERENCES dbo.languages(code),
    created_at         NVARCHAR(40)  NOT NULL
);

CREATE TABLE dbo.auth_tokens (
    id            BIGINT IDENTITY(1,1) PRIMARY KEY,
    user_id       BIGINT        NOT NULL REFERENCES dbo.users(id),
    access_token  NVARCHAR(500) NOT NULL,
    refresh_token NVARCHAR(500) NOT NULL,
    token_type    NVARCHAR(20)  NOT NULL DEFAULT N'Bearer',
    expires_in    BIGINT        NOT NULL DEFAULT 300
);

-- ============================================================================
-- 2. NHOM BANG TV4: HeritageSite, Artifact, Content, ContentTranslation, Media
-- ============================================================================
CREATE TABLE dbo.heritage_sites (
    id             BIGINT PRIMARY KEY,
    code           NVARCHAR(30)  NOT NULL UNIQUE,
    category       NVARCHAR(30)  NOT NULL,
    region         NVARCHAR(150) NOT NULL,
    name           NVARCHAR(200) NOT NULL,
    description    NVARCHAR(MAX) NOT NULL,
    address        NVARCHAR(300) NOT NULL,
    latitude       FLOAT         NOT NULL,
    longitude      FLOAT         NOT NULL,
    opening_hours  NVARCHAR(100) NULL,
    thumbnail_url  NVARCHAR(500) NULL,
    artifact_count INT           NOT NULL DEFAULT 0
);

CREATE TABLE dbo.artifacts (
    id                BIGINT PRIMARY KEY,
    site_id           BIGINT        NOT NULL REFERENCES dbo.heritage_sites(id),
    code              NVARCHAR(30)  NOT NULL UNIQUE,
    beacon_id         NVARCHAR(30)  NULL,
    name              NVARCHAR(200) NOT NULL,
    short_description NVARCHAR(500) NOT NULL,
    period            NVARCHAR(150) NOT NULL,
    thumbnail_url     NVARCHAR(500) NULL
);

CREATE TABLE dbo.contents (
    id          BIGINT PRIMARY KEY,
    artifact_id BIGINT NOT NULL UNIQUE REFERENCES dbo.artifacts(id)
);

CREATE TABLE dbo.content_translations (
    id            BIGINT PRIMARY KEY,
    content_id    BIGINT        NOT NULL REFERENCES dbo.contents(id),
    language_code NVARCHAR(10)  NOT NULL REFERENCES dbo.languages(code),
    title         NVARCHAR(250) NOT NULL,
    body_text     NVARCHAR(MAX) NOT NULL
);

CREATE TABLE dbo.media (
    id            BIGINT PRIMARY KEY,
    content_id    BIGINT        NOT NULL REFERENCES dbo.contents(id),
    media_type    NVARCHAR(20)  NOT NULL CHECK (media_type IN (N'IMAGE', N'AUDIO', N'VIDEO')),
    url           NVARCHAR(500) NOT NULL,
    duration      INT           NULL,
    language_code NVARCHAR(10)  NULL
);

-- ============================================================================
-- 3. NHOM BANG TV2 / TV5: Favorite, VisitHistory, Feedback, ArtifactCache
-- ============================================================================
CREATE TABLE dbo.favorites (
    id          BIGINT PRIMARY KEY,
    user_id     BIGINT       NOT NULL REFERENCES dbo.users(id),
    artifact_id BIGINT       NOT NULL REFERENCES dbo.artifacts(id),
    created_at  NVARCHAR(40) NOT NULL,
    CONSTRAINT uq_user_favorite UNIQUE (user_id, artifact_id)
);

CREATE TABLE dbo.visit_history (
    id               BIGINT PRIMARY KEY,
    user_id          BIGINT        NOT NULL REFERENCES dbo.users(id),
    site_id          BIGINT        NOT NULL REFERENCES dbo.heritage_sites(id),
    artifact_id      BIGINT        NOT NULL REFERENCES dbo.artifacts(id),
    artifact_name    NVARCHAR(200) NOT NULL,
    site_name        NVARCHAR(200) NOT NULL,
    visited_at       NVARCHAR(40)  NOT NULL,
    duration_seconds INT           NOT NULL,
    source           NVARCHAR(20)  NOT NULL CHECK (source IN (N'MANUAL', N'BEACON_BLE'))
);

CREATE TABLE dbo.feedbacks (
    id          BIGINT IDENTITY(1,1) PRIMARY KEY,
    user_id     BIGINT          NOT NULL REFERENCES dbo.users(id),
    artifact_id BIGINT          NOT NULL REFERENCES dbo.artifacts(id),
    rating      INT             NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment     NVARCHAR(1000)  NOT NULL,
    created_at  NVARCHAR(40)    NOT NULL
);

CREATE TABLE dbo.artifact_cache_local (
    artifact_id   BIGINT PRIMARY KEY,
    beacon_id     NVARCHAR(30)  NULL,
    artifact_json NVARCHAR(MAX) NOT NULL,
    cached_at     NVARCHAR(40)  NOT NULL
);

-- ============================================================================
-- 4. NHOM BANG TV3: BeaconSignalEvent
-- ============================================================================
CREATE TABLE dbo.beacon_signal_events (
    id              BIGINT IDENTITY(1,1) PRIMARY KEY,
    beacon_id       NVARCHAR(30) NOT NULL,
    uuid            NVARCHAR(64) NOT NULL,
    major           INT          NOT NULL,
    minor           INT          NOT NULL,
    rssi            INT          NOT NULL,
    event_type      NVARCHAR(20) NOT NULL CHECK (event_type IN (N'ENTER', N'EXIT', N'SWITCH')),
    event_timestamp BIGINT       NOT NULL
);
GO

-- ============================================================================
-- 5. NAP DU LIEU MAU DA NGON NGU (VI / EN)
-- ============================================================================
INSERT INTO dbo.roles (id, name, description) VALUES
(1, N'ADMIN',   N'Quản trị hệ thống'),
(2, N'STAFF',   N'Nhân viên bảo tàng / khu di sản'),
(3, N'VISITOR', N'Khách tham quan');

INSERT INTO dbo.languages (id, code, name, active, is_default) VALUES
(1, N'vi', N'Tiếng Việt', 1, 1),
(2, N'en', N'English',    1, 0);

INSERT INTO dbo.users (id, email, password_hash, full_name, phone, role_id, preferred_language, created_at) VALUES
(1, N'visitor@heritage.vn', N'123456', N'Nguyễn Văn An', N'0901 234 567', 3, N'vi', N'2026-10-01T08:00:00Z'),
(2, N'tourist@heritage.vn', N'123456', N'John Smith',    N'+1-555-0199',  3, N'en', N'2026-11-01T08:00:00Z');

INSERT INTO dbo.heritage_sites (id, code, category, region, name, description, address, latitude, longitude, opening_hours, thumbnail_url, artifact_count) VALUES
(1, N'HTTL',   N'CITADEL', N'Quận Ba Đình, Hà Nội',   N'Hoàng thành Thăng Long',       N'Quần thể di tích gắn với lịch sử kinh thành Thăng Long – Hà Nội, Di sản Văn hóa Thế giới UNESCO (2010).', N'19C Hoàng Diệu, Ba Đình, Hà Nội',  21.0352, 105.8403, N'08:00 - 17:00',               N'https://cdn.heritage.local/sites/1/cover.jpg', 2),
(2, N'VMQTG',  N'TEMPLE',  N'Quận Đống Đa, Hà Nội',   N'Văn Miếu – Quốc Tử Giám',      N'Trường đại học đầu tiên của Việt Nam, xây dựng năm 1070 thời Lý Thánh Tông.',                             N'58 Quốc Tử Giám, Đống Đa, Hà Nội', 21.0294, 105.8355, N'08:00 - 17:00',               N'https://cdn.heritage.local/sites/2/cover.jpg', 2),
(3, N'BTLSQG', N'MUSEUM',  N'Quận Hoàn Kiếm, Hà Nội', N'Bảo tàng Lịch sử Quốc gia',    N'Lưu giữ hơn 200.000 hiện vật từ thời tiền sử đến triều Nguyễn.',                                           N'1 Tràng Tiền, Hoàn Kiếm, Hà Nội',  21.0245, 105.8592, N'08:00 - 12:00, 13:30 - 17:00', N'https://cdn.heritage.local/sites/3/cover.jpg', 2);

INSERT INTO dbo.artifacts (id, site_id, code, beacon_id, name, short_description, period, thumbnail_url) VALUES
(101, 3, N'AR-101', N'B-101', N'Trống đồng Ngọc Lũ',            N'Bảo vật quốc gia tiêu biểu của văn hóa Đông Sơn.',              N'Văn hóa Đông Sơn (~2.500 năm trước)', N'https://cdn.heritage.local/artifacts/101/thumb.jpg'),
(102, 1, N'AR-102', N'B-102', N'Rồng đá điện Kính Thiên',       N'Đôi rồng đá chầu thềm điện Kính Thiên.',                        N'Thời Lê sơ (thế kỷ XV - 1467)',       N'https://cdn.heritage.local/artifacts/102/thumb.jpg'),
(103, 2, N'AR-103', N'B-103', N'Bia Tiến sĩ Văn Miếu',          N'82 tấm bia đá đặt trên lưng rùa ghi danh tiến sĩ.',             N'Triều Lê - Mạc (1484 - 1780)',        N'https://cdn.heritage.local/artifacts/103/thumb.jpg'),
(104, 3, N'AR-104', N'B-104', N'Ấn vàng "Hoàng đế chi bảo"',    N'Quốc bảo triều Nguyễn, đúc năm Minh Mạng thứ 4 (1823).',        N'Triều Nguyễn (1823)',                 N'https://cdn.heritage.local/artifacts/104/thumb.jpg'),
(105, 2, N'AR-105', N'B-105', N'Khuê Văn Các',                  N'Biểu tượng kiến trúc của thủ đô Hà Nội tại Văn Miếu.',          N'Triều Nguyễn (1805)',                 N'https://cdn.heritage.local/artifacts/105/thumb.jpg'),
(106, 1, N'AR-106', N'B-106', N'Cổng Đoan Môn',                 N'Cổng chính dẫn vào Cấm thành Thăng Long.',                      N'Thời Lê - Nguyễn',                    N'https://cdn.heritage.local/artifacts/106/thumb.jpg');

INSERT INTO dbo.contents (id, artifact_id) VALUES
(1010, 101), (1020, 102), (1030, 103), (1040, 104), (1050, 105), (1060, 106);

INSERT INTO dbo.content_translations (id, content_id, language_code, title, body_text) VALUES
(1011, 1010, N'vi', N'Trống đồng Ngọc Lũ',                N'Trống đồng Ngọc Lũ được phát hiện năm 1893 tại Lý Nhân, Hà Nam. Mặt trống trang trí ngôi sao 14 cánh, chim Lạc bay và cảnh sinh hoạt của cư dân Việt cổ.'),
(1012, 1010, N'en', N'Ngoc Lu Bronze Drum',               N'The Ngoc Lu drum was discovered in 1893 in Ly Nhan, Ha Nam. Its tympanum features a 14-pointed star, flying Lac birds and scenes of ancient Viet daily life.'),
(1021, 1020, N'vi', N'Rồng đá điện Kính Thiên',           N'Đôi rồng đá dài 5,3 m chạm khắc năm 1467 thời vua Lê Thánh Tông là dấu tích nguyên bản còn lại của điện Kính Thiên.'),
(1022, 1020, N'en', N'Stone Dragons of Kinh Thien Palace', N'Carved in 1467 under Emperor Le Thanh Tong, these 5.3 m stone dragons are the remaining trace of Kinh Thien Palace.'),
(1031, 1030, N'vi', N'Bia Tiến sĩ Văn Miếu',              N'82 bia Tiến sĩ đặt trên lưng rùa đá, ghi tên 1.304 vị tiến sĩ đỗ đạt qua 82 khoa thi; được UNESCO công nhận là Di sản Tư liệu Thế giới.'),
(1032, 1030, N'en', N'Doctoral Steles of Temple of Literature', N'82 steles mounted on stone turtles record 1,304 laureates of 82 imperial exams; inscribed by UNESCO as a Memory of the World.'),
(1041, 1040, N'vi', N'Ấn vàng "Hoàng đế chi bảo"',        N'Ấn vàng nặng gần 10,8 kg, núm hình rồng cuộn 5 móng, được dùng đóng trên các sắc phong và văn bản ngoại giao quan trọng của triều Nguyễn.'),
(1042, 1040, N'en', N'"Hoang De Chi Bao" Golden Seal',    N'Weighing nearly 10.8 kg with a five-clawed coiled dragon knob, it sealed royal decrees and key diplomatic documents of the Nguyen court.'),
(1051, 1050, N'vi', N'Khuê Văn Các',                      N'Khuê Văn Các dựng năm 1805 gồm hai tầng tám mái, tầng trên có bốn cửa sổ tròn tượng trưng cho sao Khuê tỏa sáng bầu trời văn học đất Việt.'),
(1061, 1060, N'vi', N'Cổng Đoan Môn',                     N'Đoan Môn xây theo lối tường thành 5 vòm cổng bằng đá thanh và gạch vồ, cửa giữa dành riêng cho nhà vua.'),
(1062, 1060, N'en', N'Doan Mon (Main South Gate)',        N'Doan Mon features five arched stone-and-brick gateways; the central arch was reserved exclusively for the Emperor.');

INSERT INTO dbo.media (id, content_id, media_type, url, duration, language_code) VALUES
(10101, 1010, N'IMAGE', N'https://cdn.heritage.local/artifacts/101/photo-front.jpg',  NULL, NULL),
(10102, 1010, N'AUDIO', N'https://cdn.heritage.local/artifacts/101/audio-vi.mp3',     185,  N'vi'),
(10103, 1010, N'AUDIO', N'https://cdn.heritage.local/artifacts/101/audio-en.mp3',     172,  N'en'),
(10104, 1010, N'VIDEO', N'https://cdn.heritage.local/artifacts/101/intro-360.mp4',    95,   NULL),
(10201, 1020, N'IMAGE', N'https://cdn.heritage.local/artifacts/102/photo-front.jpg',  NULL, NULL),
(10202, 1020, N'AUDIO', N'https://cdn.heritage.local/artifacts/102/audio-vi.mp3',     140,  N'vi'),
(10301, 1030, N'IMAGE', N'https://cdn.heritage.local/artifacts/103/photo-front.jpg',  NULL, NULL),
(10302, 1030, N'AUDIO', N'https://cdn.heritage.local/artifacts/103/audio-vi.mp3',     160,  N'vi');

INSERT INTO dbo.favorites (id, user_id, artifact_id, created_at) VALUES
(5001, 1, 101, N'2026-11-15T09:35:00Z'),
(5002, 1, 103, N'2026-11-16T14:10:00Z');

INSERT INTO dbo.visit_history (id, user_id, site_id, artifact_id, artifact_name, site_name, visited_at, duration_seconds, source) VALUES
(9001, 1, 1, 102, N'Rồng đá điện Kính Thiên', N'Hoàng thành Thăng Long',    N'2026-11-17T10:12:00Z', 95,  N'BEACON_BLE'),
(9002, 1, 2, 103, N'Bia Tiến sĩ Văn Miếu',    N'Văn Miếu – Quốc Tử Giám',   N'2026-11-16T14:05:00Z', 240, N'MANUAL'),
(9003, 1, 3, 101, N'Trống đồng Ngọc Lũ',      N'Bảo tàng Lịch sử Quốc gia', N'2026-11-15T09:30:00Z', 180, N'BEACON_BLE');

INSERT INTO dbo.feedbacks (user_id, artifact_id, rating, comment, created_at) VALUES
(1, 101, 5, N'Thuyết minh âm thanh Trống đồng Ngọc Lũ rất rõ ràng và hấp dẫn!', N'2026-11-18T11:20:00Z'),
(1, 102, 5, N'Đôi rồng đá điện Kính Thiên rất uy nghiêm.',                      N'2026-11-19T09:15:00Z');

INSERT INTO dbo.beacon_signal_events (beacon_id, uuid, major, minor, rssi, event_type, event_timestamp) VALUES
(N'B-101', N'FDA50693-A4E2-4FB1-AFCF-C6EB07647825', 1, 101, -58, N'ENTER',  1763546400000),
(N'B-102', N'FDA50693-A4E2-4FB1-AFCF-C6EB07647825', 1, 102, -62, N'SWITCH', 1763546460000),
(N'B-102', N'FDA50693-A4E2-4FB1-AFCF-C6EB07647825', 1, 102, -95, N'EXIT',   1763546520000);
GO

-- Hien thi danh sach cac bang da tao trong HeritageTV2DB
SELECT
    t.name AS [Table_Name],
    p.rows AS [Row_Count]
FROM sys.tables t
INNER JOIN sys.partitions p ON t.object_id = p.object_id AND p.index_id IN (0, 1)
ORDER BY t.name;
GO
